"""
VeloBridge - Configuration Manager
Handles persistence of dual controller choices, button mappings, and shifter options
to a local portable VeloBridge_config.json file.
"""

import json
import os
import sys
from typing import Dict, Any

# Map user-friendly action names to internal identifiers and descriptions
AVAILABLE_ACTIONS = {
    "SHIFT_UP": "Zmień bieg W GÓRĘ (+1) [Klawisz K]",
    "SHIFT_DOWN": "Zmień bieg W DÓŁ (-1) [Klawisz I]",
    "SHIFT_UP_2": "Wielokrotna zmiana: +2 biegi [2x K]",
    "SHIFT_DOWN_2": "Wielokrotna zmiana: -2 biegi [2x I]",
    "EMOTE_1": "Emotka 1 [Klawisz 1]",
    "EMOTE_2": "Emotka 2 [Klawisz 2]",
    "EMOTE_3": "Emotka 3 [Klawisz 3]",
    "EMOTE_4": "Emotka 4 [Klawisz 4]",
    "EMOTE_5": "Emotka 5 [Klawisz 5]",
    "CAMERA": "Zmiana kamery [Klawisz C]",
    "UTURN": "Nawrót / U-Turn [Klawisz U]",
    "MENU": "Menu / Pauza [Menu MyWhoosh + Esc]",
    "PAUSE_WORKOUT": "Pauza treningu [Klawisz Spacja]",
    "MENU_AND_PAUSE": "Menu + Pauza treningu [Menu + Esc + Spacja]",
    "ESC": "Tylko klawisz Escape [Esc]",
    "SPACE": "Akcja / Powerup [Klawisz Spacja]",
    "ENTER": "Zatwierdź [Klawisz Enter]",
    "TAB": "Przełącz widok [Klawisz Tab]",
    "ARROW_UP": "Strzałka w górę [Up]",
    "ARROW_DOWN": "Strzałka w dół [Down]",
    "ARROW_LEFT": "Strzałka w lewo [Left]",
    "ARROW_RIGHT": "Strzałka w prawo [Right]",
    "NONE": "Brak akcji (Wyłączony)",
}

DEFAULT_PLAY_RIGHT_MAPPING = {
    "shifter": "SHIFT_UP",
    "y_up": "SHIFT_UP",         # Przycisk Y / Strzałka w górę (▲) -> Bieg w górę (+1)
    "b_down": "SHIFT_DOWN",     # Przycisk B / Strzałka w dół (▼) -> Bieg w dół (-1)
    "a_right": "ENTER",         # Przycisk A / Strzałka w prawo (►) -> Zatwierdź / Prawo
    "z_left": "MENU",           # Przycisk Z / Strzałka w lewo (◄) -> Menu / Esc
    "power": "SPACE",
    "joystick_left": "ARROW_LEFT",
    "joystick_right": "ARROW_RIGHT",
    "brake": "NONE",
}

DEFAULT_PLAY_LEFT_MAPPING = {
    "shifter": "SHIFT_DOWN",    # Łopatka / Dolny przycisk -> Bieg w dół (-1)
    "y_up": "SHIFT_UP",         # Strzałka w górę (▲) -> Bieg w górę (+1)
    "b_down": "SHIFT_DOWN",     # Strzałka w dół (▼) -> Bieg w dół (-1)
    "z_left": "ARROW_LEFT",     # Strzałka w lewo (◄) -> W lewo
    "a_right": "ARROW_RIGHT",   # Strzałka w prawo (►) -> W prawo
    "power": "UTURN",
    "joystick_left": "ARROW_LEFT",
    "joystick_right": "ARROW_RIGHT",
    "brake": "NONE",
}

DEFAULT_CLICK_RIGHT_MAPPING = {
    "shifter": "SHIFT_UP",      # Plus (+) -> Bieg w górę (+1)
    "y_up": "SHIFT_UP",         # Y -> Bieg w górę (+1)
    "b_down": "SHIFT_DOWN",     # B -> Bieg w dół (-1)
    "a_right": "ENTER",         # A -> Enter / Zatwierdź
    "z_left": "MENU",           # Z -> Menu / Pauza
}

DEFAULT_CLICK_LEFT_MAPPING = {
    "shifter": "SHIFT_DOWN",    # Minus (−) -> Bieg w dół (-1)
    "b_down": "SHIFT_DOWN",     # Dół (▼) -> Bieg w dół (-1)
    "y_up": "SHIFT_UP",         # Góra (▲) -> Bieg w górę (+1)
    "z_left": "ARROW_LEFT",     # Strzałka w lewo (◀) -> W lewo
    "a_right": "ARROW_RIGHT",   # Strzałka w prawo (▶) -> W prawo
}

DEFAULT_CLICK_MAPPING = {
    "shifter": "SHIFT_UP",
    "y_up": "SHIFT_UP",
    "b_down": "SHIFT_DOWN",
    "a_right": "ENTER",
    "z_left": "MENU",
}


def get_base_dir() -> str:
    """Returns directory where executable or script resides (portable location)."""
    if getattr(sys, 'frozen', False):
        exe_dir = os.path.dirname(os.path.abspath(sys.executable))
        # On macOS, if running inside VeloBridge.app/Contents/MacOS, look beside the .app bundle first
        if sys.platform == "darwin" and ".app/Contents/MacOS" in exe_dir.replace("\\", "/"):
            bundle_parent = os.path.abspath(os.path.join(exe_dir, "..", "..", ".."))
            if os.access(bundle_parent, os.W_OK):
                return bundle_parent
        return exe_dir
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def get_user_config_dir() -> str:
    """Returns OS-appropriate user application support directory (%APPDATA% on Windows, ~/Library/Application Support on macOS)."""
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/Application Support")
    return os.environ.get("APPDATA", "") or os.path.expanduser("~/.config")


class ConfigManager:
    def __init__(self, filename: str = "VeloBridge_config.json"):
        base_dir = get_base_dir()
        base_path = os.path.join(base_dir, filename)
        legacy_base_path = os.path.join(base_dir, "config.json")
        appdata_base = get_user_config_dir()
        appdata_path = os.path.join(appdata_base, "VeloBridge", filename)
        legacy_appdata1 = os.path.join(appdata_base, "VeloBridge", "config.json")

        if sys.platform == "darwin":
            # On macOS, user config in ~/Library/Application Support is permanent across .app rebuilds
            if os.path.exists(appdata_path):
                self.filepath = appdata_path
            elif os.path.exists(base_path) and os.access(base_dir, os.W_OK) and ".app" not in base_dir:
                self.filepath = base_path
            else:
                os.makedirs(os.path.join(appdata_base, "VeloBridge"), exist_ok=True)
                if os.path.exists(base_path) and not os.path.exists(appdata_path):
                    try:
                        import shutil
                        shutil.copy2(base_path, appdata_path)
                    except Exception:
                        pass
                self.filepath = appdata_path
        else:
            if os.path.exists(base_path):
                self.filepath = base_path
            elif os.path.exists(legacy_base_path):
                self.filepath = base_path
                try:
                    import shutil
                    shutil.copy2(legacy_base_path, base_path)
                except Exception:
                    pass
            elif os.path.exists(appdata_path):
                self.filepath = appdata_path
            elif os.path.exists(legacy_appdata1):
                self.filepath = appdata_path
                try:
                    import shutil
                    shutil.copy2(legacy_appdata1, appdata_path)
                except Exception:
                    pass
            else:
                self.filepath = base_path

        self.filename = filename
        self.data: Dict[str, Any] = self._get_default_config()
        self.load()

    def _get_default_config(self) -> Dict[str, Any]:
        return {
            "device_mode": "Zestaw Zwift Click (Lewa + Prawa)",
            "hardware_model": "click",
            "model_right": "click",
            "model_left": "",
            "mac_right": "F5:9D:F1:42:AA:92",
            "mac_left": "",
            "mac_primary": "F5:9D:F1:42:AA:92",
            "min_gear": 1,
            "max_gear": 30,
            "initial_gear": 15,
            "sound_enabled": True,
            "haptic_enabled": True,
            "auto_focus_mywhoosh": False,
            "always_on_top": False,
            "mywhoosh_path": "",
            "mappings": {
                "play_right": dict(DEFAULT_PLAY_RIGHT_MAPPING),
                "play_left": dict(DEFAULT_PLAY_LEFT_MAPPING),
                "click_right": dict(DEFAULT_CLICK_RIGHT_MAPPING),
                "click_left": dict(DEFAULT_CLICK_LEFT_MAPPING),
                "click": dict(DEFAULT_CLICK_MAPPING),
            }
        }

    def load(self):
        if os.path.exists(self.filepath):
            try:
                with open(self.filepath, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    for k, v in loaded.items():
                        if k == "mappings" and isinstance(v, dict):
                            for sub_k, sub_v in v.items():
                                if sub_k in self.data["mappings"]:
                                    self.data["mappings"][sub_k].update(sub_v)
                        else:
                            self.data[k] = v

                    # Backwards compatibility migration
                    if "mac_primary" in self.data and not self.data.get("mac_right"):
                        self.data["mac_right"] = self.data["mac_primary"]

                    # Automatically fix legacy inverted/swapped up-right button mappings
                    mappings = self.data.get("mappings", {})
                    if "play_right" in mappings:
                        pr = mappings["play_right"]
                        if pr.get("a_right") == "SHIFT_UP" and pr.get("y_up") == "CAMERA":
                            pr["y_up"] = "SHIFT_UP"
                            pr["a_right"] = "ENTER"
                    if "click_left" in mappings:
                        cl = mappings["click_left"]
                        if cl.get("y_up") == "ARROW_UP" and cl.get("b_down") == "ARROW_DOWN":
                            cl["y_up"] = "SHIFT_UP"
                            cl["b_down"] = "SHIFT_DOWN"
                    if "click_right" in mappings:
                        cr = mappings["click_right"]
                        if cr.get("a_right") == "SHIFT_DOWN" and cr.get("z_left") == "SHIFT_DOWN":
                            cr["a_right"] = "ENTER"
                            cr["z_left"] = "ESC"
            except Exception as e:
                print(f"[Config] Error loading {self.filepath}: {e}")

    def save(self):
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"[Config] Error saving {self.filepath}: {e}")
            try:
                appdata = get_user_config_dir()
                if appdata:
                    app_dir = os.path.join(appdata, "VeloBridge")
                    os.makedirs(app_dir, exist_ok=True)
                    self.filepath = os.path.join(app_dir, getattr(self, "filename", "VeloBridge_config.json"))
                    with open(self.filepath, "w", encoding="utf-8") as f:
                        json.dump(self.data, f, indent=4, ensure_ascii=False)
                    print(f"[Config] Saved to fallback location: {self.filepath}")
            except Exception as e_fb:
                print(f"[Config] Fallback save failed: {e_fb}")
