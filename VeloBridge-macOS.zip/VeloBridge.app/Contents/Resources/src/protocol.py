"""
VeloBridge - Zwift Protocol Definitions & Packet Parser
Handles BLE UUIDs, manufacturer data parsing, button state decoding,
and haptic command construction.
"""

from typing import Dict, Any, Optional, Tuple

# Primary 128-bit RC1 Service & Characteristics (User's log & default Zwift Play)
ZWIFT_RC1_SERVICE_UUID = "00000001-19ca-4651-86e5-fa29dcdd09d1"
ZWIFT_RC1_CHAR_MEASUREMENT = "00000002-19ca-4651-86e5-fa29dcdd09d1"
ZWIFT_RC1_CHAR_CONTROL_POINT = "00000003-19ca-4651-86e5-fa29dcdd09d1"
ZWIFT_RC1_CHAR_COMMAND_RESP = "00000004-19ca-4651-86e5-fa29dcdd09d1"
ZWIFT_RC1_CHAR_EXTRA = "00000006-19ca-4651-86e5-fa29dcdd09d1"

# Zwift Click / FC82 Service (confirmed from user's BLE service dump XML)
ZWIFT_FC82_SERVICE_UUID = "0000fc82-0000-1000-8000-00805f9b34fb"
ZWIFT_FC82_CHAR_MEASUREMENT = "00000002-19ca-4651-86e5-fa29dcdd09d1"
ZWIFT_FC82_CHAR_CONTROL_POINT = "00000003-19ca-4651-86e5-fa29dcdd09d1"
ZWIFT_FC82_CHAR_COMMAND_RESP = "00000004-19ca-4651-86e5-fa29dcdd09d1"

# Legacy / alternative UUIDs
ZWIFT_ALT_CHAR_MEASUREMENT = "0000fc83-0000-1000-8000-00805f9b34fb"
ZWIFT_ALT_CHAR_CONTROL_POINT = "0000fc84-0000-1000-8000-00805f9b34fb"
ZWIFT_ALT_CHAR_COMMAND_RESP = "0000fc85-0000-1000-8000-00805f9b34fb"

# Additional Zwift Click characteristics (from dump)
ZWIFT_CLICK_CHAR_100 = "00000100-19ca-4651-86e5-fa29dcdd09d1"
ZWIFT_CLICK_CHAR_101 = "00000101-19ca-4651-86e5-fa29dcdd09d1"
ZWIFT_CLICK_CHAR_102 = "00000102-19ca-4651-86e5-fa29dcdd09d1"

# Standard Bluetooth Services
BATTERY_SERVICE_UUID = "0000180f-0000-1000-8000-00805f9b34fb"
BATTERY_LEVEL_CHAR_UUID = "00002a19-0000-1000-8000-00805f9b34fb"
DEVICE_INFO_SERVICE_UUID = "0000180a-0000-1000-8000-00805f9b34fb"
FIRMWARE_REVISION_CHAR_UUID = "00002a26-0000-1000-8000-00805f9b34fb"

ZWIFT_MANUFACTURER_ID = 0x094A


def parse_manufacturer_data(data: bytes) -> Dict[str, Any]:
    """
    Parses Zwift manufacturer data:
    If raw AD packet (starts with 0x094A / 0x4A09):
      Byte 0-1: Company ID (0x094A)
      Byte 2: Controller side (2=Right, 3=Left, 9=Click)
    If Bleak dict value (Company ID key stripped by Bleak):
      Byte 0: Controller side (2=Right, 3=Left, 9=Click)
    """
    if not data:
        return {"side_code": 0, "device_type": "Zwift Unknown", "suggested_side": "unknown"}

    side_code = 0
    if len(data) >= 3 and (data[0:2] == b"\x4a\x09" or data[0:2] == b"\x09\x4a"):
        side_code = data[2]
    elif len(data) >= 1:
        side_code = data[0]

    device_type = "Zwift Controller"
    suggested_side = "unknown"
    if side_code == 2:
        device_type = "Zwift Play (Right)"
        suggested_side = "right"
    elif side_code == 3:
        device_type = "Zwift Play (Left)"
        suggested_side = "left"
    elif side_code == 9:
        device_type = "Zwift Click"
        suggested_side = "click"
    elif side_code == 10:
        device_type = "Zwift Click (Left)"
        suggested_side = "left"
    else:
        device_type = f"Zwift Device ({side_code})"

    return {"side_code": side_code, "device_type": device_type, "suggested_side": suggested_side}


def decode_varint(data: bytes, offset: int) -> Tuple[int, int]:
    """
    Decodes a protobuf-style base128 varint from bytes at the given offset.
    Returns (value, new_offset).
    """
    res = 0
    shift = 0
    while offset < len(data):
        b = data[offset]
        offset += 1
        res |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return res, offset


def decode_zigzag(n: int) -> int:
    """
    Decodes a protobuf zigzag encoded signed integer.
    """
    return (n >> 1) ^ (-(n & 1))


class ZwiftButtonState:
    """
    Represents the decoded state of buttons on a Zwift Play or Click controller.
    """

    def __init__(self, pad_name: str = "Right"):
        self.pad_name = pad_name  # "Left", "Right", or "Click"
        
        # Primary digital buttons (True = Pressed, False = Released)
        self.shifter = False     # Shifter paddle (Play) or Main button (Click)
        self.y_up = False        # Right: 'Y' | Left: Up arrow | Click: '+'
        self.z_left = False      # Right: 'Z' | Left: Left arrow
        self.a_right = False     # Right: 'A' | Left: Right arrow
        self.b_down = False      # Right: 'B' | Left: Down arrow | Click: '-'
        self.power = False       # Side button / Power button
        
        # Analogs
        self.joystick_x = 0      # -100 (full left) to +100 (full right)
        self.brake = 0.0         # 0.0 to 100.0 %

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pad": self.pad_name,
            "shifter": self.shifter,
            "y_up": self.y_up,
            "z_left": self.z_left,
            "a_right": self.a_right,
            "b_down": self.b_down,
            "power": self.power,
            "joystick_x": self.joystick_x,
            "brake": self.brake,
        }

    def __repr__(self) -> str:
        pressed = []
        if self.shifter: pressed.append("Shifter")
        if self.y_up: pressed.append("Y/Up/Plus")
        if self.z_left: pressed.append("Z/Left")
        if self.a_right: pressed.append("A/Right")
        if self.b_down: pressed.append("B/Down/Minus")
        if self.power: pressed.append("Power")
        if abs(self.joystick_x) > 20: pressed.append(f"Joy:{self.joystick_x}")
        if self.brake > 10: pressed.append(f"Brake:{self.brake:.0f}%")
        return f"<[{self.pad_name}] Pressed: {', '.join(pressed) if pressed else 'None'}>"


def parse_decrypted_packet(payload: bytes, forced_device_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    Parses a decrypted packet from the Zwift controller.
    Returns a dict with:
      - 'type': 'heartbeat' or 'buttons'
      - 'state': ZwiftButtonState object (for 'buttons')
    """
    if not payload:
        return None

    # Idle heartbeat (0x15 for Play, 0x19 for Click/Ride)
    if payload[0] in (0x15, 0x19):
        return {"type": "heartbeat"}

    is_click = bool(forced_device_type and "click" in forced_device_type.lower())

    # Opcode 0x07: Protobuf button packet (Zwift Play & Zwift Click)
    if payload[0] == 0x07:
        offset = 1
        fields: Dict[int, int] = {}

        while offset < len(payload):
            tag, offset = decode_varint(payload, offset)
            wire_type = tag & 0x07
            field_num = tag >> 3

            if wire_type == 0:  # varint
                val, offset = decode_varint(payload, offset)
                fields[field_num] = val
            elif wire_type == 2:  # length-delimited string/bytes
                length, offset = decode_varint(payload, offset)
                offset += length
            else:
                # Unsupported wire type in buttons message
                break

        pad_id = fields.get(1, 0)
        pad_name = "Left" if pad_id == 1 else "Right"

        state = ZwiftButtonState(pad_name=pad_name)
        # 0 = pressed, 1 = not pressed
        state.y_up = fields.get(2, 1) == 0
        state.z_left = fields.get(3, 1) == 0
        state.a_right = fields.get(4, 1) == 0
        state.b_down = fields.get(5, 1) == 0
        state.power = fields.get(6, 1) == 0
        state.shifter = fields.get(7, 1) == 0

        # Joystick analog (zigzag encoded)
        raw_joy = fields.get(8, 0)
        state.joystick_x = decode_zigzag(raw_joy)

        # Brake analog (0 to 200 raw -> 0 to 100%)
        raw_brake = fields.get(9, 0)
        state.brake = min(100.0, raw_brake / 2.0)

        return {"type": "buttons", "states": [state], "state": state}

    # Opcode 0x23: 32-bit Keypad Bitmap packet (Zwift Click & Zwift Ride)
    # Payload is either a Protobuf message (tag 0x08 for field 1 varint)
    # or raw 32-bit little-endian integer.
    if payload[0] == 0x23 and len(payload) >= 2:
        bitmap = 0xFFFFFFFF
        if payload[1] == 0x08:
            # Protobuf varint: tag 0x08 followed by base128 varint
            val, _ = decode_varint(payload, 2)
            bitmap = val & 0xFFFFFFFF
        elif len(payload) >= 5:
            # Raw 32-bit little-endian fallback
            bitmap = int.from_bytes(payload[1:5], byteorder="little")

        state_r = ZwiftButtonState(pad_name="Right")
        state_l = ZwiftButtonState(pad_name="Left")

        # Inverted active-low logic: bit == 0 means pressed, 1 means idle/released.
        # 0xFFFFFFFF means idle (all buttons released).
        # If bitmap == 0 (uninitialized / all zeroes), treat as idle.
        if bitmap in (0, 0xFFFFFFFF):
            return {"type": "buttons", "states": [state_r, state_l], "state": state_r}

        pressed_mask = 0xFFFFFFFF ^ bitmap

        # --- LEWA MANETKA (Left Pad: D-Pad + Minus Shifter) ---
        # Bit 0: Left arrow (Lewo ◀)
        # Bit 1: Up arrow (Góra ▲)
        # Bit 2: Right arrow (Prawo ▶)
        # Bit 3: Down arrow (Dół ▼)
        # Bit 8: Minus Shifter (−)
        state_l.z_left = bool(pressed_mask & (1 << 0))
        state_l.y_up = bool(pressed_mask & (1 << 1))
        state_l.a_right = bool(pressed_mask & (1 << 2))
        state_l.b_down = bool(pressed_mask & (1 << 3))
        state_l.shifter = bool(pressed_mask & (1 << 8))

        # --- PRAWA MANETKA (Right Pad: A/B/Y/Z + Plus Shifter) ---
        # Bit 4: A button
        # Bit 5: B button
        # Bit 6: Y button
        # Bit 7: Z button
        # Bit 12: Plus Shifter (+)
        state_r.a_right = bool(pressed_mask & (1 << 4))
        state_r.b_down = bool(pressed_mask & (1 << 5))
        state_r.y_up = bool(pressed_mask & (1 << 6))
        state_r.z_left = bool(pressed_mask & (1 << 7))
        state_r.shifter = bool(pressed_mask & (1 << 12))

        return {"type": "buttons", "states": [state_r, state_l], "state": state_r}

    return {"type": "unknown", "raw": payload.hex()}


def build_haptic_command(pattern: int = 1) -> bytes:
    """
    Builds the vibration command payload for Zwift Play:
    Pattern: 1 (short shift click), 2 (double pulse), etc.
    Opcode 0x12, length 0x08, protobuf fields: 0x0A, 0x06, 0x08, 0x02, 0x10, 0x00, 0x18, [pattern]
    """
    return bytes([0x12, 0x08, 0x0A, 0x06, 0x08, 0x02, 0x10, 0x00, 0x18, pattern & 0x7F])
