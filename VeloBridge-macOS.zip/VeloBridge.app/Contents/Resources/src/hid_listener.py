"""
VeloBridge - Universal Bluetooth HID / Media Remote Listener
Captures global key presses from Bluetooth HID remotes (media/volume remotes,
selfie/TikTok rings, mini keyboards) without requiring GATT pairing.
On Windows, uses a low-level keyboard hook (WH_KEYBOARD_LL) that ignores
injected synthetic keys (preventing feedback loops) and optionally suppresses
original OS actions (e.g. prevents Volume Up/Down from changing system volume).
"""

import sys
import threading
import time
from typing import Callable, Dict, Optional

IS_WINDOWS = (sys.platform == "win32")

# Friendly labels for common Bluetooth HID / Media Remote Virtual Key codes (Windows VK)
VK_FRIENDLY_NAMES: Dict[int, str] = {
    0xAF: "Volume Up (Głośniej)",
    0xAE: "Volume Down (Ciszej)",
    0xAD: "Volume Mute (Wycisz)",
    0xB0: "Media Next (Następny)",
    0xB1: "Media Prev (Poprzedni)",
    0xB2: "Media Stop",
    0xB3: "Media Play/Pause",
    0x0D: "Enter",
    0x20: "Spacja",
    0x1B: "Escape",
    0x21: "Page Up",
    0x22: "Page Down",
    0x23: "End",
    0x24: "Home",
    0x25: "Strzałka Lewo (◀)",
    0x26: "Strzałka Góra (▲)",
    0x27: "Strzałka Prawo (▶)",
    0x28: "Strzałka Dół (▼)",
    0x09: "Tab",
    0x08: "Backspace",
    0xBB: "Plus (+)",
    0xBD: "Minus (−)",
    0x6B: "Numpad +",
    0x6D: "Numpad −",
    0xA6: "Browser Back",
    0xA7: "Browser Forward",
    0xAC: "Browser Home",
    0xB5: "Launch Media",
}


def vk_to_label(vk: int) -> str:
    """Returns a human-readable label for a Windows Virtual Key code."""
    if vk in VK_FRIENDLY_NAMES:
        return VK_FRIENDLY_NAMES[vk]
    if 0x30 <= vk <= 0x39:
        return f"Klawisz '{chr(vk)}'"
    if 0x41 <= vk <= 0x5A:
        return f"Klawisz '{chr(vk)}'"
    if 0x70 <= vk <= 0x87:
        return f"F{vk - 0x6F}"
    return f"Klawisz HID (VK 0x{vk:02X})"


class UniversalHidListener:
    """
    Global low-level keyboard / BT HID remote listener.
    - Supports Learn Mode: captures the next physical key press and returns (vk, label).
    - Supports Active Mode: maps configured VK codes to button IDs (e.g. 'btn_plus', 'btn_minus')
      and optionally suppresses the key so Windows doesn't change volume or scroll.
    """

    def __init__(self, on_button_callback: Optional[Callable[[str, bool], None]] = None):
        self.on_button_callback = on_button_callback
        self._lock = threading.Lock()
        self._vk_to_button: Dict[int, str] = {}
        self._enabled = False
        self._suppress = True
        self._learn_callback: Optional[Callable[[int, str], None]] = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._thread_id: Optional[int] = None
        self._hook_handle = None
        self._hook_proc_ref = None  # prevent GC of ctypes callback
        self._last_trigger_times: Dict[int, float] = {}

    def set_bindings(self, hid_bindings: Dict[str, Dict]):
        """
        Updates VK -> button_id map from config format:
        {'btn_plus': {'vk': 175, 'label': 'Volume Up (Głośniej)'}, ...}
        """
        new_map: Dict[int, str] = {}
        if isinstance(hid_bindings, dict):
            for btn_id, info in hid_bindings.items():
                if isinstance(info, dict) and info.get("vk") is not None:
                    try:
                        new_map[int(info["vk"])] = btn_id
                    except (ValueError, TypeError):
                        pass
                elif isinstance(info, int):
                    new_map[info] = btn_id
        with self._lock:
            self._vk_to_button = new_map

    def set_enabled(self, enabled: bool):
        with self._lock:
            self._enabled = bool(enabled)
        if enabled and not self._running:
            self.start()

    def set_suppress(self, suppress: bool):
        with self._lock:
            self._suppress = bool(suppress)

    def start_learning(self, on_learned: Callable[[int, str], None]):
        """Enters Learn Mode: the very next physical key/remote press invokes on_learned(vk, label)."""
        with self._lock:
            self._learn_callback = on_learned
        if not self._running:
            self.start()

    def cancel_learning(self):
        with self._lock:
            self._learn_callback = None

    def is_learning(self) -> bool:
        with self._lock:
            return self._learn_callback is not None

    def handle_key_event(self, vk: int, is_key_down: bool, is_injected: bool = False) -> bool:
        """
        Core key event dispatcher (platform-independent & unit-testable).
        Returns True if the OS event should be suppressed (swallowed), False otherwise.
        """
        # Never react to synthetic/injected keys (e.g. VeloBridge's own SendInput K/I)
        if is_injected:
            return False

        with self._lock:
            learn_cb = self._learn_callback
            enabled = self._enabled
            suppress = self._suppress
            btn_id = self._vk_to_button.get(vk)

        # 1. Learn Mode takes priority
        if learn_cb is not None:
            if is_key_down:
                with self._lock:
                    self._learn_callback = None
                label = vk_to_label(vk)
                try:
                    learn_cb(vk, label)
                except Exception:
                    pass
                return True  # Suppress the learned key press so it doesn't trigger OS actions
            return False

        # 2. Normal Active Mode
        if not enabled or not btn_id:
            return False

        if is_key_down:
            now = time.monotonic()
            # Filter OS key-repeat while holding button (180ms guard)
            if (now - self._last_trigger_times.get(vk, 0.0)) >= 0.18:
                self._last_trigger_times[vk] = now
                if self.on_button_callback:
                    try:
                        self.on_button_callback(btn_id, True)
                    except Exception:
                        pass
        else:
            if self.on_button_callback:
                try:
                    self.on_button_callback(btn_id, False)
                except Exception:
                    pass

        return suppress

    def start(self):
        if self._running or not IS_WINDOWS:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run_windows_hook, daemon=True, name="UniversalHidHookThread")
        self._thread.start()

    def stop(self):
        self._running = False
        if IS_WINDOWS and self._thread_id:
            try:
                import ctypes
                WM_QUIT = 0x0012
                ctypes.windll.user32.PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)
            except Exception:
                pass
        self._thread_id = None

    def _run_windows_hook(self):
        try:
            import ctypes
            from ctypes import wintypes

            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32

            WH_KEYBOARD_LL = 13
            WM_KEYDOWN = 0x0100
            WM_KEYUP = 0x0101
            WM_SYSKEYDOWN = 0x0104
            WM_SYSKEYUP = 0x0105
            LLKHF_INJECTED = 0x10

            class KBDLLHOOKSTRUCT(ctypes.Structure):
                _fields_ = [
                    ("vkCode", wintypes.DWORD),
                    ("scanCode", wintypes.DWORD),
                    ("flags", wintypes.DWORD),
                    ("time", wintypes.DWORD),
                    ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
                ]

            HOOKPROC = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)

            user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
            user32.SetWindowsHookExW.restype = wintypes.HHOOK
            user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
            user32.CallNextHookEx.restype = ctypes.c_long
            user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
            user32.UnhookWindowsHookEx.restype = wintypes.BOOL

            self._thread_id = kernel32.GetCurrentThreadId()

            def low_level_keyboard_proc(nCode, wParam, lParam):
                if nCode >= 0 and lParam:
                    kb = ctypes.cast(lParam, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                    vk = int(kb.vkCode)
                    is_injected = bool(kb.flags & LLKHF_INJECTED)
                    if wParam in (WM_KEYDOWN, WM_SYSKEYDOWN):
                        if self.handle_key_event(vk, is_key_down=True, is_injected=is_injected):
                            return 1
                    elif wParam in (WM_KEYUP, WM_SYSKEYUP):
                        if self.handle_key_event(vk, is_key_down=False, is_injected=is_injected):
                            return 1
                return user32.CallNextHookEx(self._hook_handle, nCode, wParam, lParam)

            self._hook_proc_ref = HOOKPROC(low_level_keyboard_proc)
            self._hook_handle = user32.SetWindowsHookExW(WH_KEYBOARD_LL, self._hook_proc_ref, None, 0)
            if not self._hook_handle:
                self._running = False
                return

            msg = wintypes.MSG()
            while self._running and user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))

            if self._hook_handle:
                user32.UnhookWindowsHookEx(self._hook_handle)
                self._hook_handle = None
        except Exception:
            self._running = False
