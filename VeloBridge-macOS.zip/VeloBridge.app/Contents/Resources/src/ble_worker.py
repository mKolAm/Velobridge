"""
VeloBridge - Background BLE Worker
Runs an asynchronous Bleak event loop in a dedicated background thread,
managing simultaneous BLE connections for Dual Zwift Play (Left + Right)
or single Zwift Click controllers.
"""

import asyncio
import threading
import queue
import time
from typing import Optional, Dict, Any, List

from .crypto import ZwiftCryptoSession
from .protocol import (
    ZWIFT_RC1_SERVICE_UUID,
    ZWIFT_RC1_CHAR_MEASUREMENT,
    ZWIFT_RC1_CHAR_CONTROL_POINT,
    ZWIFT_RC1_CHAR_COMMAND_RESP,
    ZWIFT_FC82_SERVICE_UUID,
    ZWIFT_FC82_CHAR_MEASUREMENT,
    ZWIFT_FC82_CHAR_CONTROL_POINT,
    ZWIFT_FC82_CHAR_COMMAND_RESP,
    BATTERY_SERVICE_UUID,
    BATTERY_LEVEL_CHAR_UUID,
    ZWIFT_MANUFACTURER_ID,
    parse_manufacturer_data,
    parse_decrypted_packet,
    build_haptic_command,
    ZwiftButtonState
)


class BleSession:
    """Manages the lifecycle of a single connected Zwift controller."""

    def __init__(self, role: str):
        self.role = role  # "left" or "right"
        self.address: str = ""
        self.device_type: str = ""
        self.is_click: bool = False
        self.client: Optional[Any] = None
        self.crypto: Optional[ZwiftCryptoSession] = None
        self.is_connected = False
        self.handshake_done = False
        self.is_encrypted = True
        self.battery_level = -1
        self.last_button_states: Dict[str, ZwiftButtonState] = {
            "left": ZwiftButtonState(pad_name="Left"),
            "right": ZwiftButtonState(pad_name="Right"),
        }
        self.char_measurement = ZWIFT_RC1_CHAR_MEASUREMENT
        self.char_control_point = ZWIFT_RC1_CHAR_CONTROL_POINT
        self.char_command_resp = ZWIFT_RC1_CHAR_COMMAND_RESP
        self.handshake_event: Optional[asyncio.Event] = None
        self.handshake_data: Optional[bytes] = None
        self._write_lock: Optional[asyncio.Lock] = None
        self._write_lock_loop: Optional[asyncio.AbstractEventLoop] = None
        self.manual_disconnect = False
        self.is_reconnecting = False
        self.reconnect_task: Optional[asyncio.Task] = None
        self.last_haptic_time = 0.0

    def get_write_lock(self) -> asyncio.Lock:
        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None
        if self._write_lock is None or self._write_lock_loop is not running_loop:
            self._write_lock = asyncio.Lock()
            self._write_lock_loop = running_loop
        return self._write_lock

    @property
    def last_button_state(self) -> ZwiftButtonState:
        return self.last_button_states.get(self.role, self.last_button_states["right"])

    @last_button_state.setter
    def last_button_state(self, val: ZwiftButtonState):
        self.last_button_states[self.role] = val


class BleWorker:
    def __init__(self, ui_event_queue: queue.Queue):
        self.ui_queue = ui_event_queue
        self.cmd_queue: queue.Queue = queue.Queue()
        self.thread: Optional[threading.Thread] = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.running = False
        self.sessions: Dict[str, BleSession] = {
            "left": BleSession("left"),
            "right": BleSession("right"),
        }
        self.discovered_names: Dict[str, str] = {}

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._run_thread, daemon=True, name="BleWorkerThread")
        self.thread.start()

    def stop(self):
        self.running = False
        if self.loop and self.loop.is_running():
            self.post_command("QUIT")

    def post_command(self, cmd_type: str, **kwargs):
        self.cmd_queue.put({"type": cmd_type, **kwargs})

    def _emit(self, event_type: str, **kwargs):
        self.ui_queue.put({"event": event_type, **kwargs})

    def _log(self, text: str, level: str = "INFO"):
        self._emit("LOG", message=text, level=level)

    def _run_thread(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._main_async_loop())
        self.loop.close()

    async def _main_async_loop(self):
        self._log("Uruchomiono silnik Dual Bluetooth Low Energy")
        keepalive_task = asyncio.create_task(self._keepalive_loop())
        try:
            while self.running:
                try:
                    while not self.cmd_queue.empty():
                        cmd = self.cmd_queue.get_nowait()
                        cmd_type = cmd.get("type")
                        if cmd_type == "QUIT":
                            for sess in self.sessions.values():
                                sess.manual_disconnect = True
                                await self._disconnect_session(sess)
                            return
                        elif cmd_type == "SCAN":
                            timeout = cmd.get("timeout", 4.0)
                            asyncio.create_task(self._do_scan(timeout))
                        elif cmd_type == "CONNECT":
                            role = cmd.get("role", "right")
                            if role == "primary": role = "right"
                            address = cmd.get("address", "")
                            dev_type = cmd.get("device_type", "Zwift Play")
                            sess = self.sessions.get(role)
                            if sess:
                                sess.manual_disconnect = False
                            asyncio.create_task(self._do_connect(role, address, dev_type))
                        elif cmd_type == "CONNECT_BOTH":
                            mac_l = cmd.get("mac_left", "")
                            mac_r = cmd.get("mac_right", "")
                            asyncio.create_task(self._connect_both_staggered(mac_l, mac_r))
                        elif cmd_type == "DISCONNECT":
                            role = cmd.get("role", "right")
                            if role == "primary": role = "right"
                            sess = self.sessions.get(role)
                            if sess:
                                sess.manual_disconnect = True
                                asyncio.create_task(self._disconnect_session(sess))
                        elif cmd_type == "DISCONNECT_ALL":
                            for sess in self.sessions.values():
                                sess.manual_disconnect = True
                                asyncio.create_task(self._disconnect_session(sess))
                        elif cmd_type == "HAPTIC":
                            role = cmd.get("role", "all")
                            pattern = cmd.get("pattern", 1)
                            if role in self.sessions:
                                asyncio.create_task(self._send_haptic(role, pattern))
                            else:
                                for r in ("left", "right"):
                                    asyncio.create_task(self._send_haptic(r, pattern))
                except Exception as e:
                    self._log(f"Błąd pętli poleceń BLE: {e}", "ERROR")

                await asyncio.sleep(0.04)
        finally:
            keepalive_task.cancel()

    async def _connect_both_staggered(self, mac_l: str, mac_r: str):
        """
        Connects Right and Left controllers sequentially with a small stagger
        to avoid single-radio Bluetooth contention during GATT discovery and ECDH handshake.
        """
        if mac_r:
            self.sessions["right"].manual_disconnect = False
            asyncio.create_task(self._do_connect("right", mac_r, "Zwift Play (Right)"))
            if mac_l:
                await asyncio.sleep(1.2)
        if mac_l:
            self.sessions["left"].manual_disconnect = False
            asyncio.create_task(self._do_connect("left", mac_l, "Zwift Play (Left)"))

    async def _keepalive_loop(self):
        """
        Periodic GATT keepalive (every 45s) to prevent Windows BLE link supervision
        timeout from disconnecting idle controllers during steady riding.
        """
        while self.running:
            await asyncio.sleep(45.0)
            if not self.running:
                break
            for role, sess in self.sessions.items():
                if sess.is_connected and sess.client and sess.handshake_done:
                    try:
                        async with sess.get_write_lock():
                            if sess.client and sess.client.is_connected:
                                bat_bytes = await sess.client.read_gatt_char(BATTERY_LEVEL_CHAR_UUID)
                                if bat_bytes:
                                    level = int(bat_bytes[0])
                                    if level != sess.battery_level:
                                        sess.battery_level = level
                                        self._emit("BATTERY", role=role, level=level)
                    except Exception:
                        pass

    async def _auto_reconnect(self, sess: BleSession):
        """
        Automatically attempts to restore a dropped controller connection in the background
        with smart backoff so riding in MyWhoosh is uninterrupted.
        """
        if sess.manual_disconnect or not sess.address or sess.is_reconnecting:
            return

        sess.is_reconnecting = True
        role = sess.role
        address = sess.address
        dev_type = sess.device_type or ("Zwift Play (Left)" if role == "left" else "Zwift Play (Right)")
        role_pl = "LEWA" if role == "left" else "PRAWA"

        try:
            self._log(f"[{role_pl}] Wykryto utratę połączenia BLE. Automatyczne wznawianie połączenia (Auto-Reconnect)...", "WARN")
            self._emit("STATUS", role=role, status="UTRACONO POŁĄCZENIE — WZNAWIANIE...", connected=False, address=address)

            # Give Windows BLE stack time to release stale GATT handle
            await asyncio.sleep(1.2)

            attempt = 1
            while self.running and not sess.is_connected and not sess.manual_disconnect:
                self._log(f"[{role_pl}] Auto-Reconnect: próba #{attempt} ({address})...")
                await self._do_connect(role, address, dev_type, is_reconnect=True)
                if sess.is_connected:
                    self._log(f"[{role_pl}] Połączenie pomyślnie wznowione po próbie #{attempt}!", "INFO")
                    return

                attempt += 1
                delay = 1.5 if attempt <= 4 else 4.0
                await asyncio.sleep(delay)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self._log(f"[{role_pl}] Błąd pętli Auto-Reconnect: {e}", "WARN")
        finally:
            sess.is_reconnecting = False

    async def _do_scan(self, timeout: float = 4.0):
        from bleak import BleakScanner
        self._log(f"Rozpoczynam skanowanie urządzeń BLE ({timeout}s)...")
        self._emit("SCAN_START")
        try:
            discovered = await BleakScanner.discover(timeout=timeout, return_adv=True)
            results: List[Dict[str, Any]] = []

            for addr, (dev, adv) in discovered.items():
                name = dev.name or adv.local_name or "Nieznane urządzenie"
                uuids = [u.lower() for u in (adv.service_uuids or [])]

                is_zwift = False
                detected_type = "Urządzenie BLE"
                suggested_side = "unknown"

                if "click" in name.lower():
                    is_zwift = True
                    detected_type = "Zwift Click"
                    suggested_side = "click"
                elif "play" in name.lower() or "zwift" in name.lower():
                    is_zwift = True
                    detected_type = name

                for u in uuids:
                    if "fc82" in u:
                        is_zwift = True
                        detected_type = "Zwift Click"
                        suggested_side = "click"
                    elif ZWIFT_RC1_SERVICE_UUID.lower() in u:
                        is_zwift = True
                        if detected_type == "Urządzenie BLE":
                            detected_type = "Zwift Play"

                # Check manufacturer data
                if adv.manufacturer_data:
                    for m_id, m_data in adv.manufacturer_data.items():
                        if m_id in (ZWIFT_MANUFACTURER_ID, 0x4A09, 2378, 18953):
                            is_zwift = True
                            parsed = parse_manufacturer_data(m_data)
                            detected_type = parsed["device_type"]
                            if parsed.get("suggested_side") != "unknown":
                                suggested_side = parsed["suggested_side"]

                if "right" in name.lower():
                    suggested_side = "right"
                elif "left" in name.lower():
                    suggested_side = "left"

                results.append({
                    "address": addr,
                    "name": name,
                    "rssi": adv.rssi,
                    "is_zwift": is_zwift,
                    "type": detected_type,
                    "side": suggested_side
                })
                self.discovered_names[addr] = name
                self.discovered_names[addr.upper()] = name
                if "click" in detected_type.lower() or suggested_side == "click":
                    self.discovered_names[addr.upper()] = "Zwift Click"

            results.sort(key=lambda x: (not x["is_zwift"], -x["rssi"]))
            self._log(f"Znaleziono {len(results)} urządzeń BLE (w tym {sum(1 for r in results if r['is_zwift'])} Zwift)")
            self._emit("SCAN_RESULT", devices=results)

        except Exception as e:
            self._log(f"Błąd podczas skanowania BLE: {e}", "ERROR")
            self._emit("SCAN_RESULT", devices=[])

    async def _do_connect(self, role: str, address: str, device_type: str, is_reconnect: bool = False):
        if not address:
            return

        sess = self.sessions[role]
        if sess.is_connected:
            await self._disconnect_session(sess, emit_status=False)

        sess.address = address
        sess.crypto = ZwiftCryptoSession()
        sess.handshake_done = False
        sess.handshake_event = asyncio.Event()
        sess.handshake_data = None

        role_pl = "LEWA" if role == "left" else "PRAWA"
        if not is_reconnect:
            sess.manual_disconnect = False
            self._log(f"[{role_pl}] Łączenie z {address} ({device_type})...")
            self._emit("STATUS", role=role, status="ŁĄCZENIE...", connected=False)
        else:
            self._emit("STATUS", role=role, status="WZNAWIANIE POŁĄCZENIA...", connected=False, address=address)

        def on_disconnect_callback(client):
            self._log(f"[{role_pl}] Manetka {address} została rozłączona.", "WARN")
            sess.is_connected = False
            sess.handshake_done = False
            self._release_all_pressed_buttons(sess)
            if not sess.manual_disconnect and self.running:
                self._emit("STATUS", role=role, status="UTRACONO POŁĄCZENIE — WZNAWIANIE...", connected=False, address=address)
                if self.loop and self.loop.is_running():
                    sess.reconnect_task = asyncio.run_coroutine_threadsafe(self._auto_reconnect(sess), self.loop)
            else:
                self._emit("STATUS", role=role, status="ROZŁĄCZONO", connected=False, address=address)

        try:
            from bleak import BleakClient
            client = BleakClient(address, disconnected_callback=on_disconnect_callback, timeout=15.0)
            await client.connect()
            sess.client = client
            sess.is_connected = True
            self._log(f"[{role_pl}] Połączono z GATT {address}!")

            # Try reading standard GATT Device Name characteristic (0x2A00)
            dev_name = ""
            try:
                name_bytes = await client.read_gatt_char("00002a00-0000-1000-8000-00805f9b34fb")
                if name_bytes:
                    dev_name = name_bytes.decode("utf-8", errors="ignore").strip()
            except Exception:
                pass

            if not dev_name:
                dev_name = self.discovered_names.get(address.upper(), "") or self.discovered_names.get(address, "")
            if not dev_name or "zwift" in dev_name.lower():
                disc = self.discovered_names.get(address.upper(), "") or self.discovered_names.get(address, "")
                if "click" in disc.lower():
                    dev_name = disc
            if not dev_name:
                dev_name = device_type

            # Dynamic GATT Characteristic Resolution & Hardware Model Inspection
            # Zwift Click uses primary service 0000fc82 with characteristics 00000002, 00000003, 00000004, 00000100..00000102
            # Zwift Play uses primary service 00000001 with characteristics 00000002, 00000003, 00000004
            char_meas = None
            char_ctrl = None
            char_resp = None

            has_fc82 = False
            has_click_chars = False
            has_rc1 = False

            for s in client.services:
                s_low = str(s.uuid).lower()
                if "fc82" in s_low:
                    has_fc82 = True
                if "00000001-19ca" in s_low:
                    has_rc1 = True
                for c in s.characteristics:
                    c_low = str(c.uuid).lower()
                    if any(x in c_low for x in ("00000100-19ca", "00000101-19ca", "00000102-19ca")):
                        has_click_chars = True

            for c_uuid in [ZWIFT_RC1_CHAR_MEASUREMENT, "00000002-19ca-4651-86e5-fa29dcdd09d1", "0000fc83-0000-1000-8000-00805f9b34fb"]:
                if client.services.get_characteristic(c_uuid):
                    char_meas = c_uuid
                    break

            for c_uuid in [ZWIFT_RC1_CHAR_CONTROL_POINT, "00000003-19ca-4651-86e5-fa29dcdd09d1", "0000fc84-0000-1000-8000-00805f9b34fb"]:
                if client.services.get_characteristic(c_uuid):
                    char_ctrl = c_uuid
                    break

            for c_uuid in [ZWIFT_RC1_CHAR_COMMAND_RESP, "00000004-19ca-4651-86e5-fa29dcdd09d1", "0000fc85-0000-1000-8000-00805f9b34fb"]:
                if client.services.get_characteristic(c_uuid):
                    char_resp = c_uuid
                    break

            # Fallback scan across all characteristics if any missing
            if not (char_meas and char_ctrl and char_resp):
                for s in client.services:
                    s_low = str(s.uuid).lower()
                    if "fc82" in s_low or "00000001-19ca" in s_low:
                        for c in s.characteristics:
                            props = c.properties
                            if ("notify" in props or "indicate" in props) and not char_meas:
                                char_meas = c.uuid
                            elif ("write" in props or "write-without-response" in props) and not char_ctrl:
                                char_ctrl = c.uuid
                            elif ("indicate" in props or "read" in props) and not char_resp:
                                char_resp = c.uuid

            sess.char_measurement = char_meas or ZWIFT_RC1_CHAR_MEASUREMENT
            sess.char_control_point = char_ctrl or ZWIFT_RC1_CHAR_CONTROL_POINT
            sess.char_command_resp = char_resp or ZWIFT_RC1_CHAR_COMMAND_RESP

            # Definitive Hardware Model Resolution:
            # Zwift Click's Nordic firmware often returns "Zwift Play" in standard GATT 0x2A00 Device Name.
            # GATT service 0000fc82 and characteristics 0x100..0x102 are 100% conclusive proof of Zwift Click.
            if has_fc82 or has_click_chars:
                is_click = True
                dev_name = "Zwift Click"
            elif "click" in (dev_name or "").lower():
                is_click = True
                dev_name = "Zwift Click"
            elif "click" in (device_type or "").lower() and not has_rc1:
                is_click = True
                dev_name = "Zwift Click"
            elif has_rc1 and not (has_fc82 or has_click_chars):
                is_click = False
                dev_name = "Zwift Play"
            else:
                is_click = "click" in (device_type or "").lower()
                dev_name = "Zwift Click" if is_click else (dev_name or device_type or "Zwift Play")

            sess.is_click = is_click
            sess.device_type = dev_name
            if is_click:
                self._log(f"[{role_pl}] Wykryto protokół Zwift Click (FC82/RC1). Meas={sess.char_measurement[:8]}..., Ctrl={sess.char_control_point[:8]}..., Resp={sess.char_command_resp[:8]}...")
            else:
                self._log(f"[{role_pl}] Wykryto protokół Zwift Play (RC1). Meas={sess.char_measurement[:8]}..., Ctrl={sess.char_control_point[:8]}..., Resp={sess.char_command_resp[:8]}...")

            self._emit("STATUS", role=role, status="NEGOCJACJA PROTOKOŁU (HANDSHAKE)...", connected=False)

            def on_command_resp(char, data: bytearray):
                sess.handshake_data = bytes(data)
                sess.handshake_event.set()

            # Subscribe to command response (Indicate / Notify)
            try:
                await client.start_notify(sess.char_command_resp, on_command_resp)
            except Exception as e:
                self._log(f"[{role_pl}] start_notify na {sess.char_command_resp}: {e} (użycie trybu odczytu bezpośredniego)", "WARN")

            # Send local ECDH public key (72 bytes: RideOn\x01\x02 + 64 bytes)
            req_packet = sess.crypto.get_handshake_request()
            self._log(f"[{role_pl}] Wysyłanie inicjalizacji handshake (72B)...")
            try:
                async with sess.get_write_lock():
                    await client.write_gatt_char(sess.char_control_point, req_packet, response=False)
            except Exception as e:
                self._log(f"[{role_pl}] Błąd wysyłania pakietu do {sess.char_control_point}: {e}", "WARN")

            # Wait for device response
            try:
                await asyncio.wait_for(sess.handshake_event.wait(), timeout=2.2)
            except asyncio.TimeoutError:
                self._log(f"[{role_pl}] Próba bezpośredniego odczytu odpowiedzi z {sess.char_command_resp}...")
                try:
                    resp = await client.read_gatt_char(sess.char_command_resp)
                    if resp:
                        sess.handshake_data = bytes(resp)
                except Exception:
                    pass

            # Evaluate handshake response
            if sess.handshake_data and len(sess.handshake_data) >= 64:
                success = sess.crypto.complete_handshake(sess.handshake_data)
                if success:
                    sess.handshake_done = True
                    sess.is_encrypted = True
                    self._log(f"[{role_pl}] Handshake ECDH zakończony sukcesem! Szyfrowanie AES-256-CCM aktywne.")
                else:
                    self._log(f"[{role_pl}] Niepowodzenie obliczania sekretu ECDH, próba trybu plain...", "WARN")

            if not sess.handshake_done:
                # Fallback: Plain / Unencrypted Handshake ("RideOn")
                self._log(f"[{role_pl}] Próba handshake w trybie bezpośrednim (RideOn)...")
                try:
                    async with sess.get_write_lock():
                        await client.write_gatt_char(sess.char_control_point, b"RideOn", response=False)
                    await asyncio.sleep(0.3)
                    resp = await client.read_gatt_char(sess.char_command_resp)
                    if resp and b"RideOn" in resp:
                        sess.handshake_data = bytes(resp)
                except Exception:
                    pass
                sess.handshake_done = True
                sess.is_encrypted = False
                self._log(f"[{role_pl}] Aktywny tryb bezpośredni (unencrypted).")

            def on_measurement_packet(char, data: bytearray):
                self._handle_incoming_packet(sess, bytes(data), device_type)

            await client.start_notify(sess.char_measurement, on_measurement_packet)

            # Read Battery Level
            try:
                bat_bytes = await client.read_gatt_char(BATTERY_LEVEL_CHAR_UUID)
                if bat_bytes:
                    sess.battery_level = int(bat_bytes[0])
                    self._emit("BATTERY", role=role, level=sess.battery_level)
                    self._log(f"[{role_pl}] Bateria: {sess.battery_level}%")
            except Exception:
                pass

            self._emit("STATUS", role=role, status="POŁĄCZONO", connected=True, device_name=dev_name, address=address)

            # Short haptic buzz confirming handshake (only for Zwift Play - Click has no vibration motor)
            if not is_click:
                await self._send_haptic(role, pattern=1)

        except Exception as e:
            self._log(f"[{role_pl}] Błąd łączenia z {address}: {e}", "ERROR")
            await self._disconnect_session(sess, emit_status=False)
            if not is_reconnect and not sess.manual_disconnect:
                self._emit("STATUS", role=role, status="UTRACONO POŁĄCZENIE — WZNAWIANIE...", connected=False, address=address)
                asyncio.create_task(self._auto_reconnect(sess))
            elif not is_reconnect:
                self._emit("STATUS", role=role, status=f"BŁĄD: {e}", connected=False, address=address)

    def _handle_incoming_packet(self, sess: BleSession, raw_data: bytes, dev_type: str):
        if not sess.handshake_done:
            return

        payload = None
        # 1. If session is encrypted, try decrypting first
        if sess.is_encrypted and sess.crypto:
            decrypted = sess.crypto.decrypt_packet(raw_data)
            if decrypted is not None:
                payload = decrypted[1]

        # 2. If decryption returned None or session is unencrypted, check if raw_data is already plaintext
        if payload is None:
            if raw_data and raw_data[0] in (0x07, 0x15, 0x19, 0x23):
                payload = raw_data
            elif not sess.is_encrypted:
                payload = raw_data

        if not payload:
            return

        parsed = parse_decrypted_packet(payload, forced_device_type=dev_type)
        if not parsed:
            return

        # Emit raw sniffer event for diagnostic tools
        self._emit(
            "BLE_PACKET_SNIFF",
            role=sess.role,
            raw_hex=raw_data.hex(),
            payload_hex=payload.hex() if payload else "",
            parsed_type=parsed.get("type", "unknown") if parsed else "none"
        )

        if parsed["type"] == "heartbeat":
            self._emit("HEARTBEAT", role=sess.role)
            if getattr(sess, "is_click", False):
                self._release_all_pressed_buttons(sess)
            return

        if parsed["type"] == "buttons":
            states = parsed.get("states")
            if not states:
                states = [parsed["state"]]

            for state in states:
                pad_low = getattr(state, "pad_name", "").lower()
                if pad_low in ("left", "right"):
                    role = pad_low
                else:
                    role = sess.role

                old_state = sess.last_button_states.get(role, ZwiftButtonState(pad_name=role.capitalize()))
                self._check_and_emit_buttons(
                    role,
                    old_state,
                    state,
                    is_click=getattr(sess, "is_click", False),
                    raw_hex=raw_data.hex(),
                    payload_hex=payload.hex() if payload else ""
                )
                sess.last_button_states[role] = state

    def _check_and_emit_buttons(self, role: str, old: ZwiftButtonState, new: ZwiftButtonState, is_click: bool = False, raw_hex: str = "", payload_hex: str = ""):
        buttons_to_check = [
            ("shifter", old.shifter, new.shifter),
            ("y_up", old.y_up, new.y_up),
            ("z_left", old.z_left, new.z_left),
            ("a_right", old.a_right, new.a_right),
            ("b_down", old.b_down, new.b_down),
            ("power", old.power, new.power),
        ]

        for name, was_pressed, is_pressed in buttons_to_check:
            if was_pressed != is_pressed:
                self._emit(
                    "BUTTON_CHANGE",
                    role=role,
                    pad=role.capitalize(),
                    button=name,
                    pressed=is_pressed,
                    full_state=new.to_dict(),
                    raw_hex=raw_hex,
                    payload_hex=payload_hex
                )

        # Joystick analog transitions (>40% threshold)
        old_joy_r = old.joystick_x > 40
        new_joy_r = new.joystick_x > 40
        if old_joy_r != new_joy_r:
            self._emit("BUTTON_CHANGE", role=role, pad=new.pad_name, button="joystick_right", pressed=new_joy_r, full_state=new.to_dict())

        old_joy_l = old.joystick_x < -40
        new_joy_l = new.joystick_x < -40
        if old_joy_l != new_joy_l:
            self._emit("BUTTON_CHANGE", role=role, pad=new.pad_name, button="joystick_left", pressed=new_joy_l, full_state=new.to_dict())

        # Brake analog transition (>25% threshold)
        old_brake = old.brake > 25.0
        new_brake = new.brake > 25.0
        if old_brake != new_brake:
            self._emit("BUTTON_CHANGE", role=role, pad=new.pad_name, button="brake", pressed=new_brake, full_state=new.to_dict())

    def _release_all_pressed_buttons(self, sess: BleSession):
        for role, st in sess.last_button_states.items():
            for btn_name in ("shifter", "y_up", "z_left", "a_right", "b_down", "power"):
                if getattr(st, btn_name, False):
                    setattr(st, btn_name, False)
                    self._emit(
                        "BUTTON_CHANGE",
                        role=role,
                        pad=role.capitalize(),
                        button=btn_name,
                        pressed=False,
                        full_state=st.to_dict()
                    )

    async def _send_haptic(self, role: str, pattern: int = 1):
        sess = self.sessions.get(role)
        if not sess or not sess.is_connected or not sess.crypto or not sess.handshake_done or not sess.client:
            return
        if getattr(sess, "is_click", False):
            return  # Zwift Click has no haptic motor; writing haptic opcode crashes Click firmware

        now = time.monotonic()
        if now - sess.last_haptic_time < 0.14:
            return
        sess.last_haptic_time = now

        try:
            cmd_plain = build_haptic_command(pattern)
            cmd_encrypted = sess.crypto.encrypt_command(cmd_plain)
            async with sess.get_write_lock():
                if sess.client and getattr(sess.client, "is_connected", True):
                    await sess.client.write_gatt_char(sess.char_control_point, cmd_encrypted, response=False)
        except Exception as e:
            self._log(f"[{role.upper()}] Błąd wysyłania haptic feedback: {e}", "WARN")

    async def _disconnect_session(self, sess: BleSession, emit_status: bool = True):
        sess.is_connected = False
        sess.handshake_done = False
        self._release_all_pressed_buttons(sess)
        if sess.client:
            try:
                await sess.client.disconnect()
            except Exception:
                pass
            sess.client = None
        if emit_status:
            self._emit("STATUS", role=sess.role, status="ROZŁĄCZONO", connected=False)
