"""
VeloBridge - Background BLE Worker
Runs an asynchronous Bleak event loop in a dedicated background thread,
managing simultaneous BLE connections for Dual Zwift Play (Left + Right)
or single Zwift Click controllers.
"""

import asyncio
import threading
import queue
import time
from typing import Optional, Dict, Any, List

from .crypto import ZwiftCryptoSession
from .protocol import (
    ZWIFT_RC1_SERVICE_UUID,
    ZWIFT_RC1_CHAR_MEASUREMENT,
    ZWIFT_RC1_CHAR_CONTROL_POINT,
    ZWIFT_RC1_CHAR_COMMAND_RESP,
    ZWIFT_FC82_SERVICE_UUID,
    ZWIFT_FC82_CHAR_MEASUREMENT,
    ZWIFT_FC82_CHAR_CONTROL_POINT,
    ZWIFT_FC82_CHAR_COMMAND_RESP,
    BATTERY_SERVICE_UUID,
    BATTERY_LEVEL_CHAR_UUID,
    OPENBIKECONTROL_SERVICE_UUID,
    OPENBIKECONTROL_CHAR_BUTTONS,
    GENERIC_BLE_SHIFTER_KEYWORDS,
    ZWIFT_MANUFACTURER_ID,
    parse_manufacturer_data,
    parse_decrypted_packet,
    parse_openbikecontrol_packet,
    match_generic_ble_packet,
    build_haptic_command,
    ZwiftButtonState
)


class BleSession:
    """Manages the lifecycle of a single connected Zwift controller."""

    def __init__(self, role: str):
        self.role = role  # "left" or "right"
        self.address: str = ""
        self.device_type: str = ""
        self.is_click: bool = False
        self.click_version: int = 0  # 0 = unknown/not click, 1 = Click v1 (+ / -), 2 = Click v2 (dual pod)
        self.can_read_command_resp: bool = True
        self.client: Optional[Any] = None
        self.crypto: Optional[ZwiftCryptoSession] = None
        self.is_connected = False
        self.handshake_done = False
        self.is_encrypted = True
        self.battery_level = -1
        self.last_button_states: Dict[str, ZwiftButtonState] = {
            "left": ZwiftButtonState(pad_name="Left"),
            "right": ZwiftButtonState(pad_name="Right"),
        }
        self.char_measurement = ZWIFT_RC1_CHAR_MEASUREMENT
        self.char_control_point = ZWIFT_RC1_CHAR_CONTROL_POINT
        self.char_command_resp = ZWIFT_RC1_CHAR_COMMAND_RESP
        self.handshake_event: Optional[asyncio.Event] = None
        self.handshake_data: Optional[bytes] = None
        self._write_lock: Optional[asyncio.Lock] = None
        self._write_lock_loop: Optional[asyncio.AbstractEventLoop] = None
        self.manual_disconnect = False
        self.is_reconnecting = False
        self.reconnect_task: Optional[asyncio.Task] = None
        self.last_haptic_time = 0.0

        # Diagnostic telemetry fields
        self.connect_count: int = 0
        self.disconnect_count: int = 0
        self.reconnect_count: int = 0
        self.last_connected_at: Optional[float] = None
        self.last_disconnected_at: Optional[float] = None
        self.last_packet_at: Optional[float] = None
        self.total_packets_rx: int = 0
        self.decrypt_fail_count: int = 0
        self.keepalive_ok_count: int = 0
        self.keepalive_fail_count: int = 0
        self.gatt_services: List[Dict[str, Any]] = []
        self.last_error: str = ""

    def to_diag_dict(self) -> Dict[str, Any]:
        now = time.monotonic()
        return {
            "role": self.role,
            "address": self.address,
            "device_type": self.device_type,
            "is_click": self.is_click,
            "click_version": self.click_version,
            "is_connected": self.is_connected,
            "handshake_done": self.handshake_done,
            "is_encrypted": self.is_encrypted,
            "battery_level": self.battery_level,
            "manual_disconnect": self.manual_disconnect,
            "is_reconnecting": self.is_reconnecting,
            "char_measurement": self.char_measurement,
            "char_control_point": self.char_control_point,
            "char_command_resp": self.char_command_resp,
            "can_read_command_resp": self.can_read_command_resp,
            "connect_count": self.connect_count,
            "disconnect_count": self.disconnect_count,
            "reconnect_count": self.reconnect_count,
            "connected_duration_s": round(now - self.last_connected_at, 1) if (self.is_connected and self.last_connected_at) else None,
            "last_packet_age_s": round(now - self.last_packet_at, 2) if self.last_packet_at else None,
            "total_packets_rx": self.total_packets_rx,
            "decrypt_fail_count": self.decrypt_fail_count,
            "keepalive_ok_count": self.keepalive_ok_count,
            "keepalive_fail_count": self.keepalive_fail_count,
            "last_error": self.last_error,
            "gatt_services": self.gatt_services,
        }

    def get_write_lock(self) -> asyncio.Lock:
        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None
        if self._write_lock is None or self._write_lock_loop is not running_loop:
            self._write_lock = asyncio.Lock()
            self._write_lock_loop = running_loop
        return self._write_lock

    @property
    def last_button_state(self) -> ZwiftButtonState:
        return self.last_button_states.get(self.role, self.last_button_states["right"])

    @last_button_state.setter
    def last_button_state(self, val: ZwiftButtonState):
        self.last_button_states[self.role] = val


class BleWorker:
    def __init__(self, ui_event_queue: queue.Queue, diag_logger: Optional[Any] = None):
        self.ui_queue = ui_event_queue
        self.diag_logger = diag_logger
        self.cmd_queue: queue.Queue = queue.Queue()
        self.thread: Optional[threading.Thread] = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.running = False
        self.sessions: Dict[str, BleSession] = {
            "left": BleSession("left"),
            "right": BleSession("right"),
        }
        self.generic_client: Optional[Any] = None
        self.generic_address: str = ""
        self.generic_name: str = ""
        self.generic_connected: bool = False
        self.generic_bindings: Dict[str, Dict[str, str]] = {}
        self.generic_last_trigger: Dict[str, float] = {}
        self.discovered_names: Dict[str, str] = {}
        self.discovered_side_codes: Dict[str, int] = {}

    def start(self):
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._run_thread, daemon=True, name="BleWorkerThread")
        self.thread.start()

    def stop(self):
        self.running = False
        if self.loop and self.loop.is_running():
            self.post_command("QUIT")

    def post_command(self, cmd_type: str, **kwargs):
        self.cmd_queue.put({"type": cmd_type, **kwargs})

    def _emit(self, event_type: str, **kwargs):
        self.ui_queue.put({"event": event_type, **kwargs})

    def _log(self, text: str, level: str = "INFO"):
        self._emit("LOG", message=text, level=level)
        if self.diag_logger is not None:
            self.diag_logger.record("BLE_LOG", text, level=level, role="ble")

    def _diag(self, category: str, message: str, level: str = "INFO", role: str = "system", **details):
        if self.diag_logger is not None:
            self.diag_logger.record(category, message, level=level, role=role, details=details or None)

    def get_diag_snapshot(self) -> Dict[str, Any]:
        snap = {role: sess.to_diag_dict() for role, sess in self.sessions.items()}
        snap["generic"] = {
            "address": self.generic_address,
            "name": self.generic_name,
            "connected": self.generic_connected,
        }
        return snap

    def _run_thread(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._main_async_loop())
        self.loop.close()

    async def _main_async_loop(self):
        self._log("Uruchomiono silnik Dual Bluetooth Low Energy")
        keepalive_task = asyncio.create_task(self._keepalive_loop())
        try:
            while self.running:
                try:
                    while not self.cmd_queue.empty():
                        cmd = self.cmd_queue.get_nowait()
                        cmd_type = cmd.get("type")
                        if cmd_type == "QUIT":
                            for sess in self.sessions.values():
                                sess.manual_disconnect = True
                                await self._disconnect_session(sess)
                            await self._disconnect_generic(emit_status=False)
                            return
                        elif cmd_type == "SCAN":
                            timeout = cmd.get("timeout", 4.0)
                            asyncio.create_task(self._do_scan(timeout))
                        elif cmd_type == "CONNECT":
                            role = cmd.get("role", "right")
                            if role == "primary": role = "right"
                            address = cmd.get("address", "")
                            dev_type = cmd.get("device_type", "Zwift Play")
                            sess = self.sessions.get(role)
                            if sess:
                                sess.manual_disconnect = False
                            asyncio.create_task(self._do_connect(role, address, dev_type))
                        elif cmd_type == "CONNECT_BOTH":
                            mac_l = cmd.get("mac_left", "")
                            mac_r = cmd.get("mac_right", "")
                            asyncio.create_task(self._connect_both_staggered(mac_l, mac_r))
                        elif cmd_type == "DISCONNECT":
                            role = cmd.get("role", "right")
                            if role == "primary": role = "right"
                            sess = self.sessions.get(role)
                            if sess:
                                sess.manual_disconnect = True
                                if sess.reconnect_task and not sess.reconnect_task.done():
                                    sess.reconnect_task.cancel()
                                    sess.reconnect_task = None
                                asyncio.create_task(self._disconnect_session(sess))
                        elif cmd_type == "DISCONNECT_ALL":
                            for sess in self.sessions.values():
                                sess.manual_disconnect = True
                                if sess.reconnect_task and not sess.reconnect_task.done():
                                    sess.reconnect_task.cancel()
                                    sess.reconnect_task = None
                                asyncio.create_task(self._disconnect_session(sess))
                            asyncio.create_task(self._disconnect_generic(emit_status=True))
                        elif cmd_type == "CONNECT_GENERIC":
                            address = cmd.get("address", "")
                            dev_name = cmd.get("device_name", "Kontroler BLE")
                            bindings = cmd.get("learned_bindings", {})
                            self.generic_bindings = dict(bindings) if isinstance(bindings, dict) else {}
                            asyncio.create_task(self._do_connect_generic(address, dev_name))
                        elif cmd_type == "DISCONNECT_GENERIC":
                            asyncio.create_task(self._disconnect_generic(emit_status=True))
                        elif cmd_type == "UPDATE_GENERIC_BINDINGS":
                            bindings = cmd.get("learned_bindings", {})
                            self.generic_bindings = dict(bindings) if isinstance(bindings, dict) else {}
                        elif cmd_type == "HAPTIC":
                            role = cmd.get("role", "all")
                            pattern = cmd.get("pattern", 1)
                            if role in self.sessions:
                                asyncio.create_task(self._send_haptic(role, pattern))
                            else:
                                for r in ("left", "right"):
                                    asyncio.create_task(self._send_haptic(r, pattern))
                except Exception as e:
                    self._log(f"Błąd pętli poleceń BLE: {e}", "ERROR")

                await asyncio.sleep(0.04)
        finally:
            keepalive_task.cancel()

    async def _connect_both_staggered(self, mac_l: str, mac_r: str):
        """
        Connects Right and Left controllers sequentially (waiting up to 5s for the first
        GATT/ECDH handshake to finish) to avoid single-radio Bluetooth contention.
        """
        if mac_r:
            self.sessions["right"].manual_disconnect = False
            task_r = asyncio.create_task(self._do_connect("right", mac_r, "Zwift Play (Right)"))
            if mac_l:
                try:
                    await asyncio.wait_for(asyncio.shield(task_r), timeout=5.0)
                except Exception:
                    pass
        if mac_l:
            self.sessions["left"].manual_disconnect = False
            asyncio.create_task(self._do_connect("left", mac_l, "Zwift Play (Left)"))

    async def _keepalive_loop(self):
        """
        Periodic GATT keepalive (every 8s) to reset Nordic firmware inactivity timer
        and maintain active link supervision across Windows and macOS.
        """
        while self.running:
            await asyncio.sleep(8.0)
            if not self.running:
                break
            for role, sess in self.sessions.items():
                if sess.is_connected and sess.client and sess.handshake_done:
                    try:
                        async with sess.get_write_lock():
                            if sess.client and getattr(sess.client, "is_connected", False):
                                # 1. Read Zwift Command Response characteristic to reset firmware inactivity sleep timer
                                if sess.char_command_resp and getattr(sess, "can_read_command_resp", True):
                                    try:
                                        await sess.client.read_gatt_char(sess.char_command_resp)
                                        sess.keepalive_ok_count += 1
                                    except Exception as ka_err:
                                        sess.keepalive_fail_count += 1
                                        if sess.keepalive_fail_count <= 3 or sess.keepalive_fail_count % 5 == 0:
                                            self._diag(
                                                "KEEPALIVE",
                                                f"[{role}] Keepalive read_gatt_char failed (#{sess.keepalive_fail_count}): {ka_err}",
                                                level="WARN",
                                                role=role,
                                                address=sess.address,
                                                device_type=sess.device_type,
                                            )

                                # 2. Refresh Battery Level to maintain standard GATT service
                                try:
                                    bat_bytes = await sess.client.read_gatt_char(BATTERY_LEVEL_CHAR_UUID)
                                    if bat_bytes:
                                        level = int(bat_bytes[0])
                                        if level != sess.battery_level:
                                            sess.battery_level = level
                                            self._emit("BATTERY", role=role, level=level)
                                            self._diag("BATTERY", f"[{role}] Battery updated: {level}%", role=role, level=level, address=sess.address)
                                except Exception:
                                    pass
                    except Exception as outer_ka_err:
                        sess.keepalive_fail_count += 1
                        self._diag(
                            "KEEPALIVE",
                            f"[{role}] Keepalive lock/outer error: {outer_ka_err}",
                            level="WARN",
                            role=role,
                            address=sess.address,
                        )

    async def _auto_reconnect(self, sess: BleSession):
        """
        Automatically attempts to restore a dropped controller connection in the background
        by directly connecting via the OS BLE stack so that pressing any button on the controller
        immediately triggers an instant reconnection without race conditions or scanner blind spots.
        """
        if sess.manual_disconnect or not sess.address or sess.is_reconnecting:
            return

        sess.is_reconnecting = True
        role = sess.role
        address = sess.address
        dev_type = sess.device_type or ("Zwift Play (Left)" if role == "left" else "Zwift Play (Right)")
        role_pl = "LEWA" if role == "left" else "PRAWA"

        try:
            self._log(f"[{role_pl}] Wykryto utratę połączenia BLE. Automatyczne wznawianie połączenia (Auto-Reconnect)...", "WARN")
            self._emit("STATUS", role=role, status="UTRACONO POŁĄCZENIE — WZNAWIANIE...", connected=False, address=address)

            # Properly clean up stale client to prevent OS adapter handle locking
            if sess.client:
                try:
                    await sess.client.disconnect()
                except Exception:
                    pass
                sess.client = None

            # Give OS Bluetooth stack a brief moment to clear the peripheral handle
            await asyncio.sleep(1.0)

            attempt = 1
            while self.running and not sess.is_connected and not sess.manual_disconnect:
                if attempt > 3:
                    self._emit("STATUS", role=role, status="OCZEKIWANIE NA WYBUDZENIE (KLIKNIJ PRZYCISK)...", connected=False, address=address)
                else:
                    self._emit("STATUS", role=role, status="WZNAWIANIE POŁĄCZENIA...", connected=False, address=address)

                try:
                    await self._do_connect(role, address, dev_type, is_reconnect=True)
                    if sess.is_connected:
                        sess.reconnect_count += 1
                        self._log(f"[{role_pl}] Połączenie pomyślnie wznowione!", "INFO")
                        self._diag(
                            "RECONN",
                            f"[{role}] Auto-reconnect succeeded on attempt #{attempt}",
                            level="INFO",
                            role=role,
                            address=address,
                            device_type=sess.device_type,
                            attempt=attempt,
                        )
                        return
                except Exception as rec_err:
                    if attempt <= 3 or attempt % 10 == 0:
                        self._diag(
                            "RECONN",
                            f"[{role}] Auto-reconnect attempt #{attempt} failed: {rec_err}",
                            level="WARN",
                            role=role,
                            address=address,
                            attempt=attempt,
                        )

                attempt += 1
                await asyncio.sleep(0.6)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            self._log(f"[{role_pl}] Błąd pętli Auto-Reconnect: {e}", "WARN")
        finally:
            sess.is_reconnecting = False

    async def _do_scan(self, timeout: float = 4.0):
        from bleak import BleakScanner
        self._log(f"Rozpoczynam skanowanie urządzeń BLE ({timeout}s)...")
        self._emit("SCAN_START")
        try:
            discovered = await BleakScanner.discover(timeout=timeout, return_adv=True)
            results: List[Dict[str, Any]] = []

            for addr, (dev, adv) in discovered.items():
                name = dev.name or adv.local_name or "Nieznane urządzenie"
                uuids = [u.lower() for u in (adv.service_uuids or [])]

                is_zwift = False
                is_generic_shifter = False
                detected_type = "Urządzenie BLE"
                suggested_side = "unknown"

                name_low = name.lower()
                if "click" in name_low:
                    is_zwift = True
                    detected_type = "Zwift Click"
                    suggested_side = "click"
                elif "play" in name_low or "zwift" in name_low:
                    is_zwift = True
                    detected_type = name
                elif any(kw in name_low for kw in GENERIC_BLE_SHIFTER_KEYWORDS):
                    is_generic_shifter = True
                    detected_type = f"Shifter BLE ({name})"
                    suggested_side = "generic"

                for u in uuids:
                    if "fc82" in u:
                        is_zwift = True
                        detected_type = "Zwift Click"
                        suggested_side = "click"
                    elif ZWIFT_RC1_SERVICE_UUID.lower() in u:
                        is_zwift = True
                        if detected_type == "Urządzenie BLE":
                            detected_type = "Zwift Play"
                    elif OPENBIKECONTROL_SERVICE_UUID.lower() in u:
                        is_generic_shifter = True
                        detected_type = "OpenBikeControl BLE"
                        suggested_side = "generic"

                # Check manufacturer data
                detected_side_code = 0
                if adv.manufacturer_data:
                    for m_id, m_data in adv.manufacturer_data.items():
                        if m_id in (ZWIFT_MANUFACTURER_ID, 0x4A09, 2378, 18953):
                            is_zwift = True
                            parsed = parse_manufacturer_data(m_data)
                            detected_side_code = parsed.get("side_code", 0)
                            if detected_type != "Zwift Click" or "click" in parsed["device_type"].lower():
                                detected_type = parsed["device_type"]
                            if parsed.get("suggested_side") != "unknown":
                                suggested_side = parsed["suggested_side"]

                if "right" in name.lower():
                    suggested_side = "right"
                elif "left" in name.lower():
                    suggested_side = "left"

                results.append({
                    "address": addr,
                    "name": name,
                    "rssi": adv.rssi,
                    "is_zwift": is_zwift,
                    "is_generic_shifter": is_generic_shifter,
                    "type": detected_type,
                    "side": suggested_side
                })
                self.discovered_names[addr] = name
                self.discovered_names[addr.upper()] = name
                if detected_side_code:
                    self.discovered_side_codes[addr] = detected_side_code
                    self.discovered_side_codes[addr.upper()] = detected_side_code
                if "click" in detected_type.lower() or suggested_side == "click":
                    self.discovered_names[addr.upper()] = "Zwift Click"

            results.sort(key=lambda x: (not x["is_zwift"], not x.get("is_generic_shifter", False), -x["rssi"]))
            self._log(f"Znaleziono {len(results)} urządzeń BLE (w tym {sum(1 for r in results if r['is_zwift'])} Zwift)")
            if self.diag_logger is not None:
                self.diag_logger.set_scan_snapshot(results)
                self._diag(
                    "SCAN",
                    f"BLE scan completed: {len(results)} total, {sum(1 for r in results if r['is_zwift'])} Zwift",
                    role="ble",
                    total=len(results),
                    zwift_count=sum(1 for r in results if r["is_zwift"]),
                )
            self._emit("SCAN_RESULT", devices=results)

        except Exception as e:
            self._log(f"Błąd podczas skanowania BLE: {e}", "ERROR")
            self._emit("SCAN_RESULT", devices=[])

    async def _do_connect(self, role: str, address: str, device_type: str, is_reconnect: bool = False):
        if not address:
            return

        sess = self.sessions[role]
        if sess.is_connected:
            await self._disconnect_session(sess, emit_status=False, cancel_reconnect=not is_reconnect)

        sess.address = address
        sess.crypto = ZwiftCryptoSession()
        sess.handshake_done = False
        sess.handshake_event = asyncio.Event()
        sess.handshake_data = None

        role_pl = "LEWA" if role == "left" else "PRAWA"
        if not is_reconnect:
            sess.manual_disconnect = False
            self._log(f"[{role_pl}] Łączenie z {address} ({device_type})...")
            self._emit("STATUS", role=role, status="ŁĄCZENIE...", connected=False)
        else:
            self._emit("STATUS", role=role, status="WZNAWIANIE POŁĄCZENIA...", connected=False, address=address)

        def on_disconnect_callback(client):
            now_mono = time.monotonic()
            duration_s = round(now_mono - sess.last_connected_at, 2) if sess.last_connected_at else None
            pkt_age_s = round(now_mono - sess.last_packet_at, 2) if sess.last_packet_at else None
            sess.disconnect_count += 1
            sess.last_disconnected_at = now_mono

            self._log(f"[{role_pl}] Manetka {address} została rozłączona.", "WARN")
            self._diag(
                "DISCONN",
                f"[{role}] Controller {address} disconnected (manual={sess.manual_disconnect}, duration={duration_s}s)",
                level="INFO" if sess.manual_disconnect else "WARN",
                role=role,
                address=address,
                device_type=sess.device_type or device_type,
                is_click=sess.is_click,
                click_version=sess.click_version,
                is_encrypted=sess.is_encrypted,
                battery_level=sess.battery_level,
                manual_disconnect=sess.manual_disconnect,
                duration_connected_s=duration_s,
                last_packet_age_s=pkt_age_s,
                total_packets_rx=sess.total_packets_rx,
                keepalive_ok_count=sess.keepalive_ok_count,
                keepalive_fail_count=sess.keepalive_fail_count,
                decrypt_fail_count=sess.decrypt_fail_count,
            )
            is_click_v2 = (getattr(sess, "is_click", False) or "click" in (device_type or "").lower()) and getattr(sess, "click_version", 2) != 1
            if is_click_v2:
                self._log(f"[{role_pl}] Wskazówka Zwift Click: Jeśli manetka rozłącza się regularnie po 1-2 minutach, odblokuj ją na 15s w oficjalnym Zwift (24h Unlock).", "INFO")
            sess.is_connected = False
            sess.handshake_done = False
            self._release_all_pressed_buttons(sess)
            if not sess.manual_disconnect and self.running:
                self._emit("STATUS", role=role, status="UTRACONO POŁĄCZENIE — WZNAWIANIE...", connected=False, address=address)
                if self.loop and self.loop.is_running():
                    sess.reconnect_task = asyncio.run_coroutine_threadsafe(self._auto_reconnect(sess), self.loop)
            else:
                self._emit("STATUS", role=role, status="ROZŁĄCZONO", connected=False, address=address)

        try:
            from bleak import BleakClient
            conn_timeout = 4.0 if is_reconnect else 15.0
            client = BleakClient(address, disconnected_callback=on_disconnect_callback, timeout=conn_timeout)
            await client.connect()
            sess.client = client
            sess.is_connected = True
            sess.connect_count += 1
            sess.last_connected_at = time.monotonic()
            sess.last_error = ""
            self._log(f"[{role_pl}] Połączono z GATT {address}!")

            # Try reading standard GATT Device Name characteristic (0x2A00)
            dev_name = ""
            try:
                name_bytes = await client.read_gatt_char("00002a00-0000-1000-8000-00805f9b34fb")
                if name_bytes:
                    dev_name = name_bytes.decode("utf-8", errors="ignore").strip()
            except Exception:
                pass

            if not dev_name:
                dev_name = self.discovered_names.get(address.upper(), "") or self.discovered_names.get(address, "")
            if not dev_name or "zwift" in dev_name.lower():
                disc = self.discovered_names.get(address.upper(), "") or self.discovered_names.get(address, "")
                if "click" in disc.lower():
                    dev_name = disc
            if not dev_name:
                dev_name = device_type

            # Dynamic GATT Characteristic Resolution & Hardware Model Inspection
            # Zwift Click uses primary service 0000fc82 with characteristics 00000002, 00000003, 00000004, 00000100..00000102
            # Zwift Play uses primary service 00000001 with characteristics 00000002, 00000003, 00000004
            char_meas = None
            char_ctrl = None
            char_resp = None

            has_fc82 = False
            has_click_chars = False
            has_rc1 = False
            gatt_summary: List[Dict[str, Any]] = []

            for s in client.services:
                s_low = str(s.uuid).lower()
                if "fc82" in s_low:
                    has_fc82 = True
                if "00000001-19ca" in s_low:
                    has_rc1 = True
                chars_info = []
                for c in s.characteristics:
                    c_low = str(c.uuid).lower()
                    if any(x in c_low for x in ("00000100-19ca", "00000101-19ca", "00000102-19ca")):
                        has_click_chars = True
                    chars_info.append({
                        "uuid": str(c.uuid),
                        "props": list(c.properties or []),
                    })
                gatt_summary.append({
                    "uuid": str(s.uuid),
                    "chars": chars_info,
                })
            sess.gatt_services = gatt_summary

            for c_uuid in [ZWIFT_RC1_CHAR_MEASUREMENT, "00000002-19ca-4651-86e5-fa29dcdd09d1", "0000fc83-0000-1000-8000-00805f9b34fb"]:
                if client.services.get_characteristic(c_uuid):
                    char_meas = c_uuid
                    break

            for c_uuid in [ZWIFT_RC1_CHAR_CONTROL_POINT, "00000003-19ca-4651-86e5-fa29dcdd09d1", "0000fc84-0000-1000-8000-00805f9b34fb"]:
                if client.services.get_characteristic(c_uuid):
                    char_ctrl = c_uuid
                    break

            for c_uuid in [ZWIFT_RC1_CHAR_COMMAND_RESP, "00000004-19ca-4651-86e5-fa29dcdd09d1", "0000fc85-0000-1000-8000-00805f9b34fb"]:
                if client.services.get_characteristic(c_uuid):
                    char_resp = c_uuid
                    break

            # Fallback scan across all characteristics if any missing
            if not (char_meas and char_ctrl and char_resp):
                for s in client.services:
                    s_low = str(s.uuid).lower()
                    if "fc82" in s_low or "00000001-19ca" in s_low:
                        for c in s.characteristics:
                            props = c.properties
                            if ("notify" in props or "indicate" in props) and not char_meas:
                                char_meas = c.uuid
                            elif ("write" in props or "write-without-response" in props) and not char_ctrl:
                                char_ctrl = c.uuid
                            elif ("indicate" in props or "read" in props) and not char_resp:
                                char_resp = c.uuid

            sess.char_measurement = char_meas or ZWIFT_RC1_CHAR_MEASUREMENT
            sess.char_control_point = char_ctrl or ZWIFT_RC1_CHAR_CONTROL_POINT
            sess.char_command_resp = char_resp or ZWIFT_RC1_CHAR_COMMAND_RESP

            # Inspect GATT characteristic properties for safe write/read handling (important for Click v1)
            ctrl_char_obj = client.services.get_characteristic(sess.char_control_point)
            ctrl_props = set(ctrl_char_obj.properties) if ctrl_char_obj else set()
            prefer_write_response = ("write-without-response" not in ctrl_props) and ("write" in ctrl_props)

            resp_char_obj = client.services.get_characteristic(sess.char_command_resp)
            resp_props = set(resp_char_obj.properties) if resp_char_obj else set()
            sess.can_read_command_resp = ("read" in resp_props) if resp_props else True

            discovered_side_code = (
                self.discovered_side_codes.get(address.upper(), 0)
                or self.discovered_side_codes.get(address, 0)
            )

            # Definitive Hardware Model & Click Generation (v1 vs v2) Resolution:
            # - Zwift Click v2 exposes GATT service 0000fc82 AND extra characteristics 0x100..0x102.
            # - Zwift Click v1 exposes RC1 (00000001) or FC82 WITHOUT 0x100..0x102, advertises "Zwift Click" / side_code 9,
            #   uses plain "RideOn" handshake, and sends 2-button (+ / -) opcode 0x37 packets.
            click_version = 0
            if has_click_chars:
                is_click = True
                click_version = 2
                dev_name = "Zwift Click"
            elif has_fc82:
                is_click = True
                # FC82 without 0x100..0x102 is typically Click v1 (firmware 1.1+); will auto-correct if 0x23 arrives
                click_version = 1
                dev_name = "Zwift Click v1"
            elif "click" in (dev_name or "").lower() or discovered_side_code == 9:
                is_click = True
                click_version = 1
                dev_name = "Zwift Click v1"
            elif "click" in (device_type or "").lower() and not has_rc1:
                is_click = True
                click_version = 1
                dev_name = "Zwift Click v1"
            elif has_rc1 and not (has_fc82 or has_click_chars):
                is_click = False
                dev_name = "Zwift Play"
            else:
                is_click = "click" in (device_type or "").lower()
                if is_click:
                    click_version = 2
                dev_name = "Zwift Click" if is_click else (dev_name or device_type or "Zwift Play")

            sess.is_click = is_click
            sess.click_version = click_version
            sess.device_type = dev_name
            if is_click and click_version == 1:
                self._log(f"[{role_pl}] Wykryto protokół Zwift Click v1 (2 przyciski: + / −). Meas={sess.char_measurement[:8]}..., Ctrl={sess.char_control_point[:8]}..., Resp={sess.char_command_resp[:8]}...")
            elif is_click:
                self._log(f"[{role_pl}] Wykryto protokół Zwift Click (FC82/RC1). Meas={sess.char_measurement[:8]}..., Ctrl={sess.char_control_point[:8]}..., Resp={sess.char_command_resp[:8]}...")
            else:
                self._log(f"[{role_pl}] Wykryto protokół Zwift Play (RC1). Meas={sess.char_measurement[:8]}..., Ctrl={sess.char_control_point[:8]}..., Resp={sess.char_command_resp[:8]}...")

            self._emit("STATUS", role=role, status="NEGOCJACJA PROTOKOŁU (HANDSHAKE)...", connected=False)

            async def _write_control_point(payload_bytes: bytes):
                try:
                    async with sess.get_write_lock():
                        await client.write_gatt_char(sess.char_control_point, payload_bytes, response=prefer_write_response)
                except Exception:
                    async with sess.get_write_lock():
                        await client.write_gatt_char(sess.char_control_point, payload_bytes, response=not prefer_write_response)

            def on_command_resp(char, data: bytearray):
                sess.handshake_data = bytes(data)
                sess.handshake_event.set()

            # Subscribe to command response (Indicate / Notify)
            try:
                await client.start_notify(sess.char_command_resp, on_command_resp)
            except Exception as e:
                self._log(f"[{role_pl}] start_notify na {sess.char_command_resp}: {e} (użycie trybu odczytu bezpośredniego)", "WARN")

            if is_click and click_version == 1:
                # Zwift Click v1 uses plain unencrypted "RideOn" handshake directly (no 72B ECDH)
                self._log(f"[{role_pl}] Wysyłanie handshake Zwift Click v1 (RideOn)...")
                try:
                    await _write_control_point(b"RideOn")
                except Exception as e:
                    self._log(f"[{role_pl}] Błąd wysyłania RideOn do {sess.char_control_point}: {e}", "WARN")

                try:
                    await asyncio.wait_for(sess.handshake_event.wait(), timeout=1.6)
                except asyncio.TimeoutError:
                    if sess.can_read_command_resp:
                        try:
                            resp = await client.read_gatt_char(sess.char_command_resp)
                            if resp:
                                sess.handshake_data = bytes(resp)
                        except Exception:
                            pass

                if sess.handshake_data and len(sess.handshake_data) >= 64:
                    # Unexpected 64+B ECDH response (e.g. Click v2 without 0x100): complete ECDH
                    if sess.crypto.complete_handshake(sess.handshake_data):
                        sess.handshake_done = True
                        sess.is_encrypted = True
                        sess.click_version = 2
                        dev_name = "Zwift Click"
                        sess.device_type = dev_name
                        self._log(f"[{role_pl}] Handshake ECDH zakończony sukcesem (przełączono na Click v2).")
                elif sess.handshake_data and b"RideOn" in sess.handshake_data:
                    sess.handshake_done = True
                    sess.is_encrypted = False
                    self._log(f"[{role_pl}] Handshake Zwift Click v1 (RideOn) potwierdzony!")
                else:
                    # Still proceed in plain unencrypted mode (some Click v1 firmwares don't echo RideOn via read)
                    sess.handshake_done = True
                    sess.is_encrypted = False
                    self._log(f"[{role_pl}] Aktywny tryb bezpośredni Zwift Click v1 (unencrypted).")
            else:
                # Send local ECDH public key (72 bytes: RideOn\x01\x02 + 64 bytes)
                req_packet = sess.crypto.get_handshake_request()
                self._log(f"[{role_pl}] Wysyłanie inicjalizacji handshake (72B)...")
                try:
                    await _write_control_point(req_packet)
                except Exception as e:
                    self._log(f"[{role_pl}] Błąd wysyłania pakietu do {sess.char_control_point}: {e}", "WARN")

                # Wait for device response
                try:
                    await asyncio.wait_for(sess.handshake_event.wait(), timeout=2.2)
                except asyncio.TimeoutError:
                    self._log(f"[{role_pl}] Próba bezpośredniego odczytu odpowiedzi z {sess.char_command_resp}...")
                    if sess.can_read_command_resp:
                        try:
                            resp = await client.read_gatt_char(sess.char_command_resp)
                            if resp:
                                sess.handshake_data = bytes(resp)
                        except Exception:
                            pass

                # Evaluate handshake response
                if sess.handshake_data and len(sess.handshake_data) >= 64:
                    success = sess.crypto.complete_handshake(sess.handshake_data)
                    if success:
                        sess.handshake_done = True
                        sess.is_encrypted = True
                        self._log(f"[{role_pl}] Handshake ECDH zakończony sukcesem! Szyfrowanie AES-256-CCM aktywne.")
                    else:
                        self._log(f"[{role_pl}] Niepowodzenie obliczania sekretu ECDH, próba trybu plain...", "WARN")
                elif sess.handshake_data and b"RideOn" in sess.handshake_data:
                    sess.handshake_done = True
                    sess.is_encrypted = False
                    self._log(f"[{role_pl}] Otrzymano odpowiedź plain RideOn — aktywny tryb bezpośredni (unencrypted).")

                if not sess.handshake_done:
                    # Fallback: Plain / Unencrypted Handshake ("RideOn")
                    self._log(f"[{role_pl}] Próba handshake w trybie bezpośrednim (RideOn)...")
                    try:
                        await _write_control_point(b"RideOn")
                        await asyncio.sleep(0.3)
                        if sess.can_read_command_resp:
                            resp = await client.read_gatt_char(sess.char_command_resp)
                            if resp and b"RideOn" in resp:
                                sess.handshake_data = bytes(resp)
                    except Exception:
                        pass
                    sess.handshake_done = True
                    sess.is_encrypted = False
                    self._log(f"[{role_pl}] Aktywny tryb bezpośredni (unencrypted).")

            def on_measurement_packet(char, data: bytearray):
                self._handle_incoming_packet(sess, bytes(data), sess.device_type or device_type)

            await client.start_notify(sess.char_measurement, on_measurement_packet)

            # Read Battery Level
            try:
                bat_bytes = await client.read_gatt_char(BATTERY_LEVEL_CHAR_UUID)
                if bat_bytes:
                    sess.battery_level = int(bat_bytes[0])
                    self._emit("BATTERY", role=role, level=sess.battery_level)
                    self._log(f"[{role_pl}] Bateria: {sess.battery_level}%")
            except Exception:
                pass

            self._emit("STATUS", role=role, status="POŁĄCZONO", connected=True, device_name=dev_name, address=address, click_version=sess.click_version)
            self._diag(
                "CONN",
                f"[{role}] Controller ready: {dev_name} ({address}), encrypted={sess.is_encrypted}, click_v={sess.click_version}",
                role=role,
                address=address,
                device_type=dev_name,
                is_click=sess.is_click,
                click_version=sess.click_version,
                is_encrypted=sess.is_encrypted,
                battery_level=sess.battery_level,
                is_reconnect=is_reconnect,
                char_measurement=sess.char_measurement,
                char_control_point=sess.char_control_point,
                char_command_resp=sess.char_command_resp,
                can_read_command_resp=sess.can_read_command_resp,
            )

            # Short haptic buzz confirming handshake (only for Zwift Play - Click has no vibration motor)
            if not is_click:
                await self._send_haptic(role, pattern=1)

        except Exception as e:
            sess.last_error = str(e)
            self._log(f"[{role_pl}] Błąd łączenia z {address}: {e}", "ERROR")
            self._diag(
                "CONN_ERR",
                f"[{role}] Connect error for {address} (reconnect={is_reconnect}): {e}",
                level="ERROR",
                role=role,
                address=address,
                device_type=device_type,
                is_reconnect=is_reconnect,
                exception=repr(e),
            )
            await self._disconnect_session(sess, emit_status=False, cancel_reconnect=not is_reconnect)
            if not is_reconnect and not sess.manual_disconnect:
                self._emit("STATUS", role=role, status="UTRACONO POŁĄCZENIE — WZNAWIANIE...", connected=False, address=address)
                asyncio.create_task(self._auto_reconnect(sess))
            elif not is_reconnect:
                self._emit("STATUS", role=role, status=f"BŁĄD: {e}", connected=False, address=address)

    def _handle_incoming_packet(self, sess: BleSession, raw_data: bytes, dev_type: str):
        if not sess.handshake_done:
            return

        sess.total_packets_rx += 1
        sess.last_packet_at = time.monotonic()

        payload = None
        # 1. If session is encrypted, try decrypting first
        if sess.is_encrypted and sess.crypto:
            decrypted = sess.crypto.decrypt_packet(raw_data)
            if decrypted is not None:
                payload = decrypted[1]

        # 2. If decryption returned None or session is unencrypted, check if raw_data is already plaintext
        if payload is None:
            if raw_data and raw_data[0] in (0x07, 0x15, 0x19, 0x23, 0x37):
                payload = raw_data
            elif not sess.is_encrypted:
                payload = raw_data
            else:
                sess.decrypt_fail_count += 1
                if sess.decrypt_fail_count <= 5 or sess.decrypt_fail_count % 50 == 0:
                    self._diag(
                        "PACKET_ERR",
                        f"[{sess.role}] Decrypt failed (#{sess.decrypt_fail_count}), raw_len={len(raw_data)}, head={raw_data[:6].hex()}",
                        level="WARN",
                        role=sess.role,
                        address=sess.address,
                        decrypt_fail_count=sess.decrypt_fail_count,
                    )

        if not payload:
            return

        parsed = parse_decrypted_packet(payload, forced_device_type=dev_type)
        if not parsed:
            return

        # Dynamic packet-level Click v1 / v2 auto-detection and self-correction
        pkt_click_ver = parsed.get("click_version")
        if pkt_click_ver == 1 and sess.click_version != 1:
            sess.click_version = 1
            sess.is_click = True
            sess.device_type = "Zwift Click v1"
            role_pl = "LEWA" if sess.role == "left" else "PRAWA"
            self._log(f"[{role_pl}] Automatycznie rozpoznano Zwift Click v1 (opcode 0x37, przyciski + / −).")
            self._emit("STATUS", role=sess.role, status="POŁĄCZONO", connected=True, device_name="Zwift Click v1", address=sess.address, click_version=1)
        elif payload[0] == 0x23 and sess.is_click and sess.click_version == 1:
            sess.click_version = 2
            sess.device_type = "Zwift Click"
            role_pl = "LEWA" if sess.role == "left" else "PRAWA"
            self._log(f"[{role_pl}] Automatycznie przełączono profil na Zwift Click v2 (opcode 0x23).")
            self._emit("STATUS", role=sess.role, status="POŁĄCZONO", connected=True, device_name="Zwift Click", address=sess.address, click_version=2)

        # Emit raw sniffer event for diagnostic tools
        self._emit(
            "BLE_PACKET_SNIFF",
            role=sess.role,
            raw_hex=raw_data.hex(),
            payload_hex=payload.hex() if payload else "",
            parsed_type=parsed.get("type", "unknown") if parsed else "none"
        )

        if parsed["type"] == "heartbeat":
            self._emit("HEARTBEAT", role=sess.role)
            return

        if parsed["type"] == "buttons":
            states = parsed.get("states")
            if not states:
                states = [parsed["state"]]

            if pkt_click_ver == 1:
                # Zwift Click v1 is a single pod with '+' (Right Shifter -> UP) and '-' (Left Shifter -> DOWN).
                # Always dispatch Right and Left states directly regardless of which slot the pod was paired to.
                for state in states:
                    pad_low = getattr(state, "pad_name", "").lower()
                    role = pad_low if pad_low in ("left", "right") else sess.role
                    old_state = sess.last_button_states.get(role, ZwiftButtonState(pad_name=role.capitalize()))
                    self._check_and_emit_buttons(
                        role,
                        old_state,
                        state,
                        is_click=True,
                        raw_hex=raw_data.hex(),
                        payload_hex=payload.hex() if payload else ""
                    )
                    sess.last_button_states[role] = state
            elif len(states) == 1:
                state = states[0]
                if sess.role == "left":
                    role = "left"
                else:
                    pad_low = getattr(state, "pad_name", "").lower()
                    role = pad_low if pad_low in ("left", "right") else sess.role
                old_state = sess.last_button_states.get(role, ZwiftButtonState(pad_name=role.capitalize()))
                self._check_and_emit_buttons(
                    role,
                    old_state,
                    state,
                    is_click=getattr(sess, "is_click", False),
                    raw_hex=raw_data.hex(),
                    payload_hex=payload.hex() if payload else ""
                )
                sess.last_button_states[role] = state
            else:
                if sess.role == "left":
                    merged = ZwiftButtonState(pad_name="Left")
                    for st in states:
                        merged.shifter = merged.shifter or st.shifter
                        merged.y_up = merged.y_up or st.y_up
                        merged.z_left = merged.z_left or st.z_left
                        merged.a_right = merged.a_right or st.a_right
                        merged.b_down = merged.b_down or st.b_down
                        merged.power = merged.power or st.power
                    old_state = sess.last_button_states.get("left", ZwiftButtonState(pad_name="Left"))
                    self._check_and_emit_buttons(
                        "left",
                        old_state,
                        merged,
                        is_click=getattr(sess, "is_click", False),
                        raw_hex=raw_data.hex(),
                        payload_hex=payload.hex() if payload else ""
                    )
                    sess.last_button_states["left"] = merged
                else:
                    for state in states:
                        pad_low = getattr(state, "pad_name", "").lower()
                        if pad_low in ("left", "right"):
                            role = pad_low
                        else:
                            role = sess.role

                        if role == "left" and self.sessions["left"].is_connected:
                            has_any_btn = any([state.shifter, state.y_up, state.z_left, state.a_right, state.b_down, state.power])
                            old_l = sess.last_button_states.get("left", ZwiftButtonState(pad_name="Left"))
                            was_any_btn = any([old_l.shifter, old_l.y_up, old_l.z_left, old_l.a_right, old_l.b_down, old_l.power])
                            if not has_any_btn and not was_any_btn:
                                continue

                        old_state = sess.last_button_states.get(role, ZwiftButtonState(pad_name=role.capitalize()))
                        self._check_and_emit_buttons(
                            role,
                            old_state,
                            state,
                            is_click=getattr(sess, "is_click", False),
                            raw_hex=raw_data.hex(),
                            payload_hex=payload.hex() if payload else ""
                        )
                        sess.last_button_states[role] = state

    def _check_and_emit_buttons(self, role: str, old: ZwiftButtonState, new: ZwiftButtonState, is_click: bool = False, raw_hex: str = "", payload_hex: str = ""):
        buttons_to_check = [
            ("shifter", old.shifter, new.shifter),
            ("y_up", old.y_up, new.y_up),
            ("z_left", old.z_left, new.z_left),
            ("a_right", old.a_right, new.a_right),
            ("b_down", old.b_down, new.b_down),
            ("power", old.power, new.power),
        ]

        for name, was_pressed, is_pressed in buttons_to_check:
            if was_pressed != is_pressed:
                self._emit(
                    "BUTTON_CHANGE",
                    role=role,
                    pad=role.capitalize(),
                    button=name,
                    pressed=is_pressed,
                    full_state=new.to_dict(),
                    raw_hex=raw_hex,
                    payload_hex=payload_hex
                )

        # Joystick analog transitions (>40% threshold)
        old_joy_r = old.joystick_x > 40
        new_joy_r = new.joystick_x > 40
        if old_joy_r != new_joy_r:
            self._emit("BUTTON_CHANGE", role=role, pad=new.pad_name, button="joystick_right", pressed=new_joy_r, full_state=new.to_dict())

        old_joy_l = old.joystick_x < -40
        new_joy_l = new.joystick_x < -40
        if old_joy_l != new_joy_l:
            self._emit("BUTTON_CHANGE", role=role, pad=new.pad_name, button="joystick_left", pressed=new_joy_l, full_state=new.to_dict())

        # Brake analog transition (>25% threshold)
        old_brake = old.brake > 25.0
        new_brake = new.brake > 25.0
        if old_brake != new_brake:
            self._emit("BUTTON_CHANGE", role=role, pad=new.pad_name, button="brake", pressed=new_brake, full_state=new.to_dict())

    def _release_all_pressed_buttons(self, sess: BleSession):
        for role, st in sess.last_button_states.items():
            for btn_name in ("shifter", "y_up", "z_left", "a_right", "b_down", "power"):
                if getattr(st, btn_name, False):
                    setattr(st, btn_name, False)
                    self._emit(
                        "BUTTON_CHANGE",
                        role=role,
                        pad=role.capitalize(),
                        button=btn_name,
                        pressed=False,
                        full_state=st.to_dict()
                    )

    async def _send_haptic(self, role: str, pattern: int = 1):
        sess = self.sessions.get(role)
        if not sess or not sess.is_connected or not sess.crypto or not sess.handshake_done or not sess.client:
            return
        if getattr(sess, "is_click", False):
            return  # Zwift Click has no haptic motor; writing haptic opcode crashes Click firmware

        now = time.monotonic()
        if now - sess.last_haptic_time < 0.14:
            return
        sess.last_haptic_time = now

        try:
            cmd_plain = build_haptic_command(pattern)
            cmd_encrypted = sess.crypto.encrypt_command(cmd_plain)
            async with sess.get_write_lock():
                if sess.client and getattr(sess.client, "is_connected", True):
                    await sess.client.write_gatt_char(sess.char_control_point, cmd_encrypted, response=False)
        except Exception as e:
            self._log(f"[{role.upper()}] Błąd wysyłania haptic feedback: {e}", "WARN")

    async def _disconnect_session(self, sess: BleSession, emit_status: bool = True, cancel_reconnect: bool = True):
        sess.is_connected = False
        sess.handshake_done = False
        self._release_all_pressed_buttons(sess)
        if cancel_reconnect and sess.reconnect_task and not sess.reconnect_task.done():
            sess.reconnect_task.cancel()
            sess.reconnect_task = None
        if sess.client:
            try:
                await sess.client.disconnect()
            except Exception:
                pass
            sess.client = None
        if emit_status:
            self._emit("STATUS", role=sess.role, status="ROZŁĄCZONO", connected=False)

    # ----------------------------------------------------
    # Universal Generic BLE GATT Controller (Cycplus BC2, ThinkRider VS200, OpenBikeControl, BLE Learn Mode)
    async def _do_connect_generic(self, address: str, device_name: str = "Kontroler BLE"):
        if not address:
            return
        await self._disconnect_generic(emit_status=False)

        self.generic_address = address
        self.generic_name = device_name or address
        self._log(f"[UNIWERSALNY BLE] Łączenie z {self.generic_name} ({address})...")
        self._emit("GENERIC_STATUS", status="ŁĄCZENIE...", connected=False, address=address, device_name=self.generic_name)

        def on_generic_disconnect(client):
            self.generic_connected = False
            self._log(f"[UNIWERSALNY BLE] Rozłączono {self.generic_name} ({address}).", "WARN")
            self._emit("GENERIC_STATUS", status="ROZŁĄCZONO", connected=False, address=address, device_name=self.generic_name)

        try:
            from bleak import BleakClient
            client = BleakClient(address, disconnected_callback=on_generic_disconnect, timeout=15.0)
            await client.connect()
            self.generic_client = client
            self.generic_connected = True

            # Try reading standard GATT Device Name (0x2A00)
            try:
                name_bytes = await client.read_gatt_char("00002a00-0000-1000-8000-00805f9b34fb")
                if name_bytes:
                    decoded_name = name_bytes.decode("utf-8", errors="ignore").strip()
                    if decoded_name:
                        self.generic_name = decoded_name
            except Exception:
                pass

            # Subscribe to all notifiable / indicatable custom characteristics
            ignored_std_services = ("00001800-", "00001801-", "0000180a-", "0000180f-")
            subscribed_chars: List[str] = []
            fallback_chars: List[str] = []

            for s in client.services:
                s_low = str(s.uuid).lower()
                is_std = any(s_low.startswith(pref) for pref in ignored_std_services)
                for c in s.characteristics:
                    props = set(c.properties or [])
                    if "notify" in props or "indicate" in props:
                        if is_std:
                            fallback_chars.append(str(c.uuid))
                        else:
                            subscribed_chars.append(str(c.uuid))

            target_chars = subscribed_chars if subscribed_chars else fallback_chars
            active_subs = 0
            for c_uuid in target_chars:
                try:
                    def _make_cb(uuid_str):
                        def _cb(char, data: bytearray):
                            self._handle_generic_ble_packet(uuid_str, bytes(data))
                        return _cb
                    await client.start_notify(c_uuid, _make_cb(c_uuid))
                    active_subs += 1
                except Exception as e_sub:
                    self._log(f"[UNIWERSALNY BLE] Pominięto subskrypcję {c_uuid[:8]}...: {e_sub}", "WARN")

            # Optional Battery Level read
            bat_level = -1
            try:
                bat_bytes = await client.read_gatt_char(BATTERY_LEVEL_CHAR_UUID)
                if bat_bytes:
                    bat_level = int(bat_bytes[0])
            except Exception:
                pass

            self._log(f"[UNIWERSALNY BLE] Połączono z {self.generic_name}! Aktywne kanały Notify/Indicate: {active_subs}.")
            self._emit(
                "GENERIC_STATUS",
                status=f"POŁĄCZONO ({active_subs} kanałów BLE)",
                connected=True,
                address=address,
                device_name=self.generic_name,
                battery=bat_level,
                subscribed_count=active_subs
            )
        except Exception as e:
            self._log(f"[UNIWERSALNY BLE] Błąd łączenia z {address}: {e}", "ERROR")
            await self._disconnect_generic(emit_status=False)
            self._emit("GENERIC_STATUS", status=f"BŁĄD: {e}", connected=False, address=address, device_name=self.generic_name)

    def _handle_generic_ble_packet(self, char_uuid: str, data: bytes):
        if not data:
            return
        c_low = (char_uuid or "").lower()
        p_hex = data.hex()

        # Always emit raw packet for BLE Learn Mode / Live Monitor
        self._emit(
            "GENERIC_BLE_PACKET",
            char_uuid=c_low,
            payload_hex=p_hex,
            device_name=self.generic_name
        )

        # 1. Check user-learned BLE bindings first (Cycplus BC2, ThinkRider VS200, any BLE shifter)
        matched_btn = match_generic_ble_packet(c_low, data, self.generic_bindings)
        if matched_btn:
            now = time.monotonic()
            if (now - self.generic_last_trigger.get(matched_btn, 0.0)) >= 0.16:
                self.generic_last_trigger[matched_btn] = now
                self._emit(
                    "BUTTON_CHANGE",
                    role="generic",
                    pad="Generic",
                    button=matched_btn,
                    pressed=True,
                    raw_hex=p_hex,
                    payload_hex=p_hex,
                    full_state={matched_btn: True}
                )
            return

        # 2. Built-in OpenBikeControl standard support (zero-config if device uses OpenBikeControl UUID)
        if c_low == OPENBIKECONTROL_CHAR_BUTTONS.lower():
            obc = parse_openbikecontrol_packet(data)
            if obc and obc.get("events"):
                for btn_name, is_pressed in obc["events"]:
                    self._emit(
                        "BUTTON_CHANGE",
                        role="generic",
                        pad="Generic",
                        button=btn_name,
                        pressed=is_pressed,
                        raw_hex=p_hex,
                        payload_hex=p_hex,
                        full_state={btn_name: is_pressed}
                    )

    async def _disconnect_generic(self, emit_status: bool = True):
        self.generic_connected = False
        if self.generic_client:
            try:
                await self.generic_client.disconnect()
            except Exception:
                pass
            self.generic_client = None
        if emit_status:
            self._emit("GENERIC_STATUS", status="ROZŁĄCZONO", connected=False, address=self.generic_address, device_name=self.generic_name)
