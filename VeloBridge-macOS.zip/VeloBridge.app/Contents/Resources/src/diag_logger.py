"""
VeloBridge - Encrypted Diagnostic Logger
Continuously buffers structured BLE, controller, and application events in memory
and exports zlib-compressed, AES-256-GCM encrypted .vblog diagnostic packages.
"""

import collections
import hashlib
import json
import os
import platform
import sys
import threading
import time
import zlib
from datetime import datetime, timezone
from typing import Any, Deque, Dict, List, Optional

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

VBLOG_MAGIC = b"VBLOG1\x00\x01"
VBLOG_AAD = b"VeloBridgeDiagV1"

# Split key material so casual string inspection does not reveal a plaintext passphrase
_KEY_PARTS = (
    b"VB-2026-DualBLE-",
    b"ZwiftPlayClick-",
    b"DiagVault-9f4c2a",
    b"81e7b3d50a6c4e12",
)


def _derive_vblog_key() -> bytes:
    """Derives the 256-bit AES-GCM key for .vblog diagnostic archives."""
    h = hashlib.sha256()
    for part in _KEY_PARTS:
        h.update(part)
    return h.digest()


def get_bleak_version() -> str:
    try:
        import bleak
        return getattr(bleak, "__version__", "unknown")
    except Exception:
        return "not-installed"


class DiagEventLogger:
    """Thread-safe in-memory ring-buffer diagnostic logger with AES-256-GCM export."""

    def __init__(self, max_events: int = 4000):
        self._lock = threading.Lock()
        self._events: Deque[Dict[str, Any]] = collections.deque(maxlen=max_events)
        self._started_monotonic = time.monotonic()
        self._started_iso = datetime.now(timezone.utc).isoformat()
        self._last_scan_devices: List[Dict[str, Any]] = []
        self._total_events_recorded = 0

    def record(
        self,
        category: str,
        message: str,
        level: str = "INFO",
        role: str = "system",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Records a structured diagnostic event into the thread-safe ring buffer."""
        now_local = datetime.now()
        elapsed_s = round(time.monotonic() - self._started_monotonic, 3)
        entry: Dict[str, Any] = {
            "ts": now_local.strftime("%Y-%m-%d %H:%M:%S.") + f"{now_local.microsecond // 1000:03d}",
            "elapsed_s": elapsed_s,
            "category": category,
            "level": level,
            "role": role,
            "message": message,
        }
        if details:
            entry["details"] = details

        with self._lock:
            self._events.append(entry)
            self._total_events_recorded += 1

    def set_scan_snapshot(self, devices: List[Dict[str, Any]]) -> None:
        """Stores the most recent BLE scan results for inclusion in diagnostic reports."""
        compact = []
        for d in devices[:40]:
            compact.append({
                "address": d.get("address", ""),
                "name": d.get("name", ""),
                "rssi": d.get("rssi"),
                "type": d.get("type", ""),
                "side": d.get("side", ""),
                "is_zwift": bool(d.get("is_zwift", False)),
                "is_generic_shifter": bool(d.get("is_generic_shifter", False)),
            })
        with self._lock:
            self._last_scan_devices = compact

    def get_stats(self) -> Dict[str, Any]:
        """Returns lightweight summary counts for UI display."""
        with self._lock:
            buffered = len(self._events)
            total = self._total_events_recorded
            disconnects = sum(1 for e in self._events if e.get("category") == "DISCONN")
            errors = sum(1 for e in self._events if e.get("level") == "ERROR")
        return {
            "buffered_events": buffered,
            "total_events": total,
            "disconnects": disconnects,
            "errors": errors,
            "uptime_s": round(time.monotonic() - self._started_monotonic, 1),
        }

    def build_payload(
        self,
        app_version: str,
        config_data: Dict[str, Any],
        sessions_snapshot: Dict[str, Any],
        user_note: str = "",
        extra_meta: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Builds the complete diagnostic payload dictionary."""
        with self._lock:
            events_copy = list(self._events)
            scan_copy = list(self._last_scan_devices)
            total_recorded = self._total_events_recorded

        safe_cfg_keys = (
            "device_mode",
            "hardware_model",
            "mac_left",
            "mac_right",
            "model_left",
            "model_right",
            "generic_ble_enabled",
            "generic_ble_address",
            "generic_ble_name",
            "hid_enabled",
            "sound_enabled",
            "haptic_enabled",
            "auto_focus_mywhoosh",
            "min_gear",
            "max_gear",
            "initial_gear",
        )
        config_snapshot = {k: config_data.get(k) for k in safe_cfg_keys if k in config_data}

        env_info = {
            "app_version": app_version,
            "platform": sys.platform,
            "platform_detail": platform.platform(),
            "machine": platform.machine(),
            "python_version": platform.python_version(),
            "bleak_version": get_bleak_version(),
            "frozen": bool(getattr(sys, "frozen", False)),
            "session_started_utc": self._started_iso,
            "report_created_utc": datetime.now(timezone.utc).isoformat(),
            "report_created_local": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "uptime_s": round(time.monotonic() - self._started_monotonic, 2),
            "total_events_recorded": total_recorded,
            "events_included": len(events_copy),
        }
        if extra_meta:
            env_info.update(extra_meta)

        return {
            "format": "velobridge-diag-v1",
            "environment": env_info,
            "user_note": (user_note or "").strip(),
            "config": config_snapshot,
            "sessions": sessions_snapshot,
            "last_scan_devices": scan_copy,
            "events": events_copy,
        }

    @staticmethod
    def encrypt_payload(payload: Dict[str, Any]) -> bytes:
        """Compresses and encrypts a diagnostic payload into .vblog binary format."""
        raw_json = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        compressed = zlib.compress(raw_json, level=9)
        nonce = os.urandom(12)
        aesgcm = AESGCM(_derive_vblog_key())
        ciphertext = aesgcm.encrypt(nonce, compressed, VBLOG_AAD)
        return VBLOG_MAGIC + nonce + ciphertext

    def save_encrypted_report(
        self,
        filepath: str,
        app_version: str,
        config_data: Dict[str, Any],
        sessions_snapshot: Dict[str, Any],
        user_note: str = "",
        extra_meta: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Builds, encrypts, and writes a .vblog diagnostic report to disk."""
        payload = self.build_payload(
            app_version=app_version,
            config_data=config_data,
            sessions_snapshot=sessions_snapshot,
            user_note=user_note,
            extra_meta=extra_meta,
        )
        blob = self.encrypt_payload(payload)
        parent = os.path.dirname(os.path.abspath(filepath))
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(filepath, "wb") as f:
            f.write(blob)
        return os.path.abspath(filepath)
