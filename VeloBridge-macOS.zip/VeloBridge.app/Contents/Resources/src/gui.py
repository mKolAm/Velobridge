"""
VeloBridge Pro - Graphical User Interface
Modern UI Dark Cockpit with photorealistic interactive Zwift Click visualization,
vector Zwift Play support, direct MyWhoosh DirectInput integration, dual BLE telemetry,
and real-time glowing button hotspot feedback.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import queue
import time
import os
import sys
import ctypes
import math
import webbrowser
from typing import Dict, Any, Optional, Tuple

try:
    from PIL import Image, ImageTk, ImageDraw, ImageFont, ImageFilter
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

from . import APP_VERSION, APP_BADGE
from .config import ConfigManager, AVAILABLE_ACTIONS
from .ble_worker import BleWorker
from .input_sender import (
    VirtualShifter,
    send_hardware_key,
    SCANCODES,
    VK_CODES,
    play_shift_sound,
    find_mywhoosh_window,
    focus_mywhoosh,
    launch_or_focus_mywhoosh,
    detect_mywhoosh,
    trigger_mywhoosh_pause_or_menu,
    click_mywhoosh_menu_button,
    check_macos_accessibility_permission,
    IS_WINDOWS,
    IS_MACOS,
)

if IS_MACOS:
    class MacFlatButton(tk.Label):
        """
        macOS Aqua overrides native tk.Button background colors with light/grey system bezels.
        This Label-based drop-in replacement preserves VeloBridge's dark cockpit styling on macOS.
        """

        def __init__(self, master=None, cnf={}, **kw):
            kw = dict(cnf, **kw)
            self._command = kw.pop("command", None)
            self._active_bg = kw.pop("activebackground", None)
            self._active_fg = kw.pop("activeforeground", None)
            self._btn_state = kw.pop("state", tk.NORMAL)
            kw.pop("default", None)
            kw.pop("overrelief", None)
            super().__init__(master, **kw)
            self._orig_bg = kw.get("bg", kw.get("background", "#131D2B"))
            self._orig_fg = kw.get("fg", kw.get("foreground", "#F8FAFC"))
            self.bind("<ButtonRelease-1>", self._on_release, add="+")

        def _on_release(self, event=None):
            if self._btn_state != tk.DISABLED and callable(self._command):
                self._command()

        def configure(self, cnf=None, **kw):
            if isinstance(cnf, dict):
                kw = dict(cnf, **kw)
            elif cnf is not None:
                return super().configure(cnf)
            if "command" in kw:
                self._command = kw.pop("command")
            if "activebackground" in kw:
                self._active_bg = kw.pop("activebackground")
            if "activeforeground" in kw:
                self._active_fg = kw.pop("activeforeground")
            if "state" in kw:
                self._btn_state = kw.pop("state")
            if "bg" in kw or "background" in kw:
                self._orig_bg = kw.get("bg", kw.get("background", self._orig_bg))
            if "fg" in kw or "foreground" in kw:
                self._orig_fg = kw.get("fg", kw.get("foreground", self._orig_fg))
            if kw:
                return super().configure(**kw)

        config = configure

        def cget(self, key):
            if key == "command":
                return self._command
            if key == "state":
                return self._btn_state
            if key == "activebackground":
                return self._active_bg or self._orig_bg
            if key == "activeforeground":
                return self._active_fg or self._orig_fg
            return super().cget(key)

        __getitem__ = cget

        def invoke(self):
            if self._btn_state != tk.DISABLED and callable(self._command):
                return self._command()

    tk.Button = MacFlatButton

# ----------------------------------------------------
# Modern UI Fluent / Dark Cockpit Color Palette
# ----------------------------------------------------
BG_DARK = "#0B1019"        # Ultra-deep cockpit canvas
BG_PANEL = "#0E1420"       # Top header / navigation surface
BG_CARD = "#0C1420"        # Card background (dark glass)
BG_CARD_INNER = "#070E18"  # Sub-card / Elevated container / recessed well
BG_INPUT = "#0A0E17"       # Form inputs & dark wells

TEXT_WHITE = "#F8FAFC"     # Primary text (crisp white)
TEXT_MUTED = "#94A3B8"     # Secondary text (slate-400)
TEXT_DIM = "#64748B"       # Tertiary / subtle text (slate-500)

ACCENT_EMERALD = "#00E676" # Zwift / Connected / Primary action neon green
ACCENT_CYAN = "#00E5FF"    # MyWhoosh / Active focus electric cyan
ACCENT_AMBER = "#F59E0B"   # Scanning / Standby warm amber
ACCENT_PINK = "#F43F5E"    # Downshift / Highlight rose
ACCENT_RED = "#EF4444"     # Disconnected / Stop red
ACCENT_PURPLE = "#8B5CF6"  # Secondary accent

BORDER_COLOR = "#1B273A"   # Subtle modern card border
BORDER_FOCUS = "#00E5FF"   # Glowing focus border
BORDER_TILE = "#162133"    # Inner tile border


class GradientPillButton(tk.Canvas):
    """Modern Pill Button rendered with Pillow anti-aliased gradient, rounded corners, vector icons, and dynamic width."""

    def __init__(
        self,
        parent,
        text: str,
        command,
        width: int = 400,
        height: int = 40,
        icon: str = "lightning",
        c_left: Tuple[int, int, int] = (5, 150, 105),       # Emerald #059669
        c_mid: Tuple[int, int, int] = (0, 230, 118),        # Neon Green #00E676
        c_right: Tuple[int, int, int] = (0, 229, 255),      # Electric Cyan #00E5FF
        hover_left: Tuple[int, int, int] = (16, 185, 129),  # Bright Emerald
        hover_mid: Tuple[int, int, int] = (52, 245, 140),
        hover_right: Tuple[int, int, int] = (56, 240, 255),
        bg_parent: str = BG_PANEL,
        font_size: int = 10,
        **kwargs
    ):
        self.btn_width = max(160, width)
        self.btn_height = height
        super().__init__(parent, width=self.btn_width, height=self.btn_height, bg=bg_parent, bd=0, highlightthickness=0, cursor="hand2", **kwargs)
        self.btn_text = text.replace("⚡", "").replace("✓", "").strip()
        self.btn_icon = icon
        self.command = command
        self.c_left = c_left
        self.c_mid = c_mid
        self.c_right = c_right
        self.hover_left = hover_left
        self.hover_mid = hover_mid
        self.hover_right = hover_right
        self.font_size = font_size
        self._is_hovered = False
        self._is_active = False

        self._normal_img = None
        self._hover_img = None
        self._img_item = None

        self._render_images()
        self._draw_current_image()

        self.bind("<Button-1>", self._on_click)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Configure>", self._on_configure)

    def _draw_current_image(self):
        self.delete("all")
        img = self._hover_img if self._is_hovered else self._normal_img
        if img:
            self._img_item = self.create_image(0, 0, anchor="nw", image=img)

    def _on_configure(self, event):
        if event.width > 120 and abs(event.width - self.btn_width) > 4:
            self.btn_width = event.width
            self._render_images()
            self._draw_current_image()

    def _render_pill_image(self, c1, c2, c3, text, icon=None, border_color=None) -> Optional[Any]:
        if not PIL_AVAILABLE:
            return None
        w, h = max(100, self.btn_width), self.btn_height
        grad = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        for x in range(w):
            f = x / max(1, w - 1)
            if f < 0.5:
                sub_f = f / 0.5
                r = int(c1[0] + (c2[0] - c1[0]) * sub_f)
                g = int(c1[1] + (c2[1] - c1[1]) * sub_f)
                b = int(c1[2] + (c2[2] - c1[2]) * sub_f)
            else:
                sub_f = (f - 0.5) / 0.5
                r = int(c2[0] + (c3[0] - c2[0]) * sub_f)
                g = int(c2[1] + (c3[1] - c2[1]) * sub_f)
                b = int(c2[2] + (c3[2] - c2[2]) * sub_f)
            for y in range(h):
                grad.putpixel((x, y), (r, g, b, 255))

        radius = 12
        mask = Image.new("L", (w, h), 0)
        m_draw = ImageDraw.Draw(mask)
        m_draw.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=radius, fill=255)

        img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        img.paste(grad, (0, 0), mask=mask)

        draw = ImageDraw.Draw(img)
        if border_color:
            draw.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=radius, outline=border_color, width=1)

        font = load_pil_font(self.font_size, prefer_chakra=False)

        clean_text = text.replace("⚡", "").replace("✓", "").strip()
        bbox = draw.textbbox((0, 0), clean_text, font=font)
        tw = bbox[2] - bbox[0]
        th = bbox[3] - bbox[1]

        active_icon = self.btn_icon if icon is None else icon
        icon_w = 14 if active_icon else 0
        gap = 8 if active_icon else 0
        total_w = icon_w + gap + tw
        start_x = max(8, (w - total_w) // 2)

        dark_ink = (5, 16, 26, 255)
        text_ink = (255, 255, 255, 255) if self._is_active else dark_ink

        if active_icon == "lightning":
            ix = start_x
            iy = (h - 16) // 2
            poly = [
                (ix + 9, iy),
                (ix + 2, iy + 8),
                (ix + 7, iy + 8),
                (ix + 5, iy + 16),
                (ix + 12, iy + 7),
                (ix + 7, iy + 7)
            ]
            draw.polygon(poly, fill=dark_ink)
        elif active_icon == "check":
            ix = start_x
            iy = (h - 14) // 2
            draw.line([(ix + 1, iy + 7), (ix + 5, iy + 11)], fill=text_ink, width=3)
            draw.line([(ix + 5, iy + 11), (ix + 13, iy + 3)], fill=text_ink, width=3)
        elif active_icon == "link":
            ix = start_x
            iy = (h - 6) // 2
            draw.ellipse([(ix, iy), (ix + 4, iy + 4)], fill=dark_ink)
            draw.ellipse([(ix + 6, iy), (ix + 10, iy + 4)], fill=dark_ink)

        tx = start_x + icon_w + gap
        ty = max(2, (h - th) // 2 - 1)
        draw.text((tx, ty), clean_text, fill=text_ink, font=font)
        return ImageTk.PhotoImage(img)

    def _render_images(self):
        self._normal_img = self._render_pill_image(self.c_left, self.c_mid, self.c_right, self.btn_text, icon=self.btn_icon)
        self._hover_img = self._render_pill_image(self.hover_left, self.hover_mid, self.hover_right, self.btn_text, icon=self.btn_icon, border_color=(255, 255, 255, 180))

    def set_text(self, new_text: str, is_active: bool = False, icon: Optional[str] = None):
        self.btn_text = new_text.replace("⚡", "").replace("✓", "").strip()
        self._is_active = is_active
        if icon is not None:
            self.btn_icon = icon
        if is_active:
            self.c_left = (6, 95, 70)
            self.c_mid = (5, 150, 105)
            self.c_right = (16, 185, 129)
            self.hover_left = (16, 185, 129)
            self.hover_mid = (52, 211, 153)
            self.hover_right = (0, 229, 255)
        else:
            self.c_left = (5, 150, 105)
            self.c_mid = (0, 230, 118)
            self.c_right = (0, 229, 255)
            self.hover_left = (16, 185, 129)
            self.hover_mid = (52, 245, 140)
            self.hover_right = (56, 240, 255)
        self._render_images()
        self._draw_current_image()

    def _on_enter(self, event):
        self._is_hovered = True
        self._draw_current_image()

    def _on_leave(self, event):
        self._is_hovered = False
        self._draw_current_image()

    def _on_click(self, event):
        if self.command:
            self.command()


def create_gradient_bar(parent, c_start_hex: str, c_mid_hex: str, height: int = 2):
    """Creates a sleek 2px horizontal gradient accent bar that fades gracefully to dark."""
    canv = tk.Canvas(parent, height=height, bg=BG_CARD, bd=0, highlightthickness=0)
    canv.pack(fill=tk.X, pady=(0, 8))

    def _draw_gradient(event):
        w = max(50, event.width)
        canv.delete("all")
        steps = 28
        sw = w / steps
        r1, g1, b1 = int(c_start_hex[1:3], 16), int(c_start_hex[3:5], 16), int(c_start_hex[5:7], 16)
        r2, g2, b2 = int(c_mid_hex[1:3], 16), int(c_mid_hex[3:5], 16), int(c_mid_hex[5:7], 16)
        bg_r, bg_g, bg_b = 10, 15, 24
        for i in range(steps):
            f = i / (steps - 1)
            if f < 0.45:
                rf = f / 0.45
                r = int(r1 + (r2 - r1) * rf)
                g = int(g1 + (g2 - g1) * rf)
                b = int(b1 + (b2 - b1) * rf)
            else:
                rf = (f - 0.45) / 0.55
                r = int(r2 + (bg_r - r2) * rf)
                g = int(g2 + (bg_g - g2) * rf)
                b = int(b2 + (bg_b - b2) * rf)
            canv.create_rectangle(int(i * sw), 0, int((i + 1) * sw) + 1, height, fill=f"#{r:02x}{g:02x}{b:02x}", outline="")

    canv.bind("<Configure>", _draw_gradient)
    return canv


class ModernCard(tk.Canvas):
    """Modern UI Card with rounded corners, glowing cyan gradient border, and dark cockpit background."""

    def __init__(
        self,
        parent,
        height: int = 200,
        radius: int = 12,
        pad_x: int = 12,
        pad_y: int = 12,
        bg_parent: str = BG_DARK,
        **kwargs
    ):
        super().__init__(parent, height=height, bg=bg_parent, bd=0, highlightthickness=0, **kwargs)
        self.radius = radius
        self.pad_x = pad_x
        self.pad_y = pad_y
        self.w = 100
        self.h = height
        self._bg_photo = None
        self._draw_job = None

        self.inner = tk.Frame(self, bg=BG_CARD)
        self.win = self.create_window(pad_x, pad_y, window=self.inner, anchor="nw")
        self.bind("<Configure>", self._on_conf)

    def _on_conf(self, e):
        if e.width < 50 or e.height < 50:
            return
        if abs(e.width - self.w) < 3 and abs(e.height - self.h) < 3:
            return
        self.w = e.width
        self.h = e.height
        inner_w = max(10, self.w - 2 * self.pad_x)
        inner_h = max(10, self.h - 2 * self.pad_y)
        self.itemconfigure(self.win, width=inner_w, height=inner_h)
        if self._draw_job is not None:
            try:
                self.after_cancel(self._draw_job)
            except Exception:
                pass
        self._draw_job = self.after(20, self._draw_bg)

    def _draw_bg(self):
        self._draw_job = None
        if not PIL_AVAILABLE:
            self.configure(bg=BG_CARD)
            return

        w, h = max(50, self.w), max(50, self.h)
        r = self.radius

        # Subtle dark cockpit background gradient (top-mid dark teal glow to deep midnight)
        bg_col = Image.new("RGBA", (1, h))
        for y in range(h):
            fy = y / max(1, h - 1)
            rc = int(14 * (1 - fy) + 10 * fy)
            gc = int(23 * (1 - fy) + 16 * fy)
            bc = int(38 * (1 - fy) + 26 * fy)
            bg_col.putpixel((0, y), (rc, gc, bc, 255))
        bg = bg_col.resize((w, h), Image.Resampling.BILINEAR)

        mask = Image.new("L", (w, h), 0)
        d = ImageDraw.Draw(mask)
        d.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=r, fill=255)
        bg.putalpha(mask)

        # Subtle uniform modern border matching CSS rgba(0, 229, 255, 0.18) with gentle top highlight
        border_col = Image.new("RGBA", (1, h))
        for y in range(h):
            fy = y / max(1, h - 1)
            br = int(28 * (1 - fy) + 18 * fy)
            bg_val = int(52 * (1 - fy) + 32 * fy)
            bb = int(78 * (1 - fy) + 50 * fy)
            border_col.putpixel((0, y), (br, bg_val, bb, 255))
        border_img = border_col.resize((w, h), Image.Resampling.BILINEAR)

        stroke_mask = Image.new("L", (w, h), 0)
        sd = ImageDraw.Draw(stroke_mask)
        sd.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=r, fill=255)
        sd.rounded_rectangle([(1, 1), (w - 2, h - 2)], radius=max(1, r - 1), fill=0)
        border_img.putalpha(stroke_mask)

        card_img = Image.alpha_composite(bg, border_img)
        self._bg_photo = ImageTk.PhotoImage(card_img)
        self.delete("card_bg")
        self.create_image(0, 0, anchor="nw", image=self._bg_photo, tags="card_bg")
        self.tag_lower("card_bg")


class ModernToggleTile(tk.Frame):
    """Sleek dark card toggle with left icon & text, and right emerald checkbox matching modern web UI."""

    def __init__(self, parent, text: str, variable: tk.BooleanVar, icon_type: str = "sound", command=None, bg="#080D15"):
        super().__init__(parent, bg=bg, padx=10, pady=5, highlightthickness=1, highlightbackground=BORDER_TILE, cursor="hand2")
        self.variable = variable
        self.command = command
        self._icon_img = None

        # Icon
        self._build_icon(icon_type)
        if self._icon_img:
            self.lbl_icon = tk.Label(self, image=self._icon_img, bg=bg, cursor="hand2")
            self.lbl_icon.pack(side=tk.LEFT, padx=(0, 8))

        # Text label
        self.lbl_text = tk.Label(
            self,
            text=text,
            font=("Segoe UI", 8, "bold"),
            fg="#E2E8F0",
            bg=bg,
            cursor="hand2"
        )
        self.lbl_text.pack(side=tk.LEFT)

        # Right Checkbox (Emerald checkmark box when True, dark box when False)
        self.box_check = tk.Label(
            self,
            text="✔",
            font=("Segoe UI", 8, "bold"),
            width=2,
            cursor="hand2",
            bd=1,
            relief=tk.SOLID
        )
        self.box_check.pack(side=tk.RIGHT)

        for w in (self, self.lbl_text, self.box_check):
            w.bind("<Button-1>", self._on_click)
        if hasattr(self, "lbl_icon") and self.lbl_icon:
            self.lbl_icon.bind("<Button-1>", self._on_click)

        self._update_state()

    def _build_icon(self, icon_type: str):
        if not PIL_AVAILABLE:
            return
        img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        if icon_type == "sound":
            d.polygon([(2, 5), (6, 5), (10, 2), (10, 13), (6, 10), (2, 10)], fill=(0, 229, 255, 255))
            d.arc([(8, 4), (13, 11)], start=-50, end=50, fill=(0, 229, 255, 255), width=2)
            d.arc([(9, 2), (15, 13)], start=-50, end=50, fill=(0, 229, 255, 200), width=1)
        else:
            d.rounded_rectangle([(5, 2), (11, 13)], radius=2, outline=(245, 158, 11, 255), width=1)
            d.arc([(0, 4), (5, 11)], start=130, end=230, fill=(245, 158, 11, 255), width=1)
            d.arc([(11, 4), (16, 11)], start=-50, end=50, fill=(245, 158, 11, 255), width=1)
        self._icon_img = ImageTk.PhotoImage(img)

    def _on_click(self, event=None):
        self.variable.set(not self.variable.get())
        self._update_state()
        if self.command:
            self.command()

    def _update_state(self):
        val = self.variable.get()
        if val:
            self.box_check.configure(
                text="✔",
                fg="#042F2E",
                bg="#00E676",
                highlightbackground="#00E676"
            )
        else:
            self.box_check.configure(
                text="",
                fg="#64748B",
                bg="#0D1522",
                highlightbackground="#1E2B3E"
            )


class FeaturedCoffeeButton(tk.Frame):
    """Featured, warm amber / espresso styled BuyCoffee button with interactive hover and Wesprzyj pill badge."""

    def __init__(self, parent, command=None, bg="#2D1A0E", border="#D97706"):
        super().__init__(parent, bg=bg, highlightthickness=1, highlightbackground=border, cursor="hand2", padx=8, pady=4)
        self.command = command

        self.lbl_icon = tk.Label(self, text="☕", font=("Segoe UI", 9), fg="#FEF3C7", bg=bg, cursor="hand2")
        self.lbl_icon.pack(side=tk.LEFT, padx=(0, 4))

        self.lbl_text = tk.Label(self, text="Postaw kawę", font=("Segoe UI", 8, "bold"), fg="#FEF3C7", bg=bg, cursor="hand2")
        self.lbl_text.pack(side=tk.LEFT, padx=(0, 5))

        self.lbl_badge = tk.Label(
            self,
            text="Wesprzyj",
            font=("Segoe UI", 7, "bold"),
            fg="#FDE68A",
            bg="#452410",
            highlightthickness=1,
            highlightbackground="#D97706",
            padx=4,
            pady=0,
            cursor="hand2"
        )
        self.lbl_badge.pack(side=tk.LEFT)

        for w in (self, self.lbl_icon, self.lbl_text, self.lbl_badge):
            w.bind("<Button-1>", lambda e: self.command() if self.command else None)
            w.bind("<Enter>", self._on_enter)
            w.bind("<Leave>", self._on_leave)

    def _on_enter(self, e):
        self.configure(bg="#3D2012", highlightbackground="#FBBF24")
        self.lbl_icon.configure(bg="#3D2012", fg="#FFFFFF")
        self.lbl_text.configure(bg="#3D2012", fg="#FFFFFF")
        self.lbl_badge.configure(bg="#5C2E14", fg="#FFFFFF", highlightbackground="#FBBF24")

    def _on_leave(self, e):
        self.configure(bg="#2D1A0E", highlightbackground="#D97706")
        self.lbl_icon.configure(bg="#2D1A0E", fg="#FEF3C7")
        self.lbl_text.configure(bg="#2D1A0E", fg="#FEF3C7")
        self.lbl_badge.configure(bg="#452410", fg="#FDE68A", highlightbackground="#D97706")


class FeaturedCoffeeCard(tk.Canvas):
    """
    Aesthetic warm espresso/amber styled interactive BuyCoffee Card for the bottom-right panel.
    Features rounded corners, warm amber gradient, glowing gold border on hover,
    and opens buycoffee.to/mkola on click.
    """
    def __init__(self, parent, height: int = 95, radius: int = 10, pad_x: int = 12, pad_y: int = 10, bg_parent: str = BG_DARK, **kwargs):
        super().__init__(parent, height=height, bg=bg_parent, bd=0, highlightthickness=0, cursor="hand2", **kwargs)
        self.radius = radius
        self.pad_x = pad_x
        self.pad_y = pad_y
        self.w = 100
        self.h = height
        self._is_hovered = False
        self._bg_photo = None
        self._draw_job = None

        self.inner = tk.Frame(self, bg="#20130A", cursor="hand2")
        self.win = self.create_window(pad_x, pad_y, window=self.inner, anchor="nw")

        # Top row: Icon + Title on left, Badge on right
        top_row = tk.Frame(self.inner, bg="#20130A", cursor="hand2")
        top_row.pack(fill=tk.X)

        self.lbl_title = tk.Label(
            top_row,
            text="☕ Postaw kawę",
            font=("Segoe UI", 9, "bold"),
            fg="#FBBF24",
            bg="#20130A",
            cursor="hand2"
        )
        self.lbl_title.pack(side=tk.LEFT)

        self.lbl_badge = tk.Label(
            top_row,
            text="buycoffee.to/mkola ↗",
            font=("Segoe UI", 7, "bold"),
            fg="#FEF3C7",
            bg="#452410",
            highlightthickness=1,
            highlightbackground="#D97706",
            padx=6,
            pady=1,
            cursor="hand2"
        )
        self.lbl_badge.pack(side=tk.RIGHT)

        self.lbl_desc = tk.Label(
            self.inner,
            text="  Podoba Ci się VeloBridge? Kliknij tutaj, aby postawić\n  wirtualną kawę i wesprzeć dalszy rozwój projektu!",
            font=("Segoe UI", 8),
            fg="#CBD5E1",
            bg="#20130A",
            justify=tk.LEFT,
            cursor="hand2"
        )
        self.lbl_desc.pack(anchor="w", pady=(4, 0))

        # Click handler
        for w in (self, self.inner, top_row, self.lbl_title, self.lbl_badge, self.lbl_desc):
            w.bind("<Button-1>", lambda e: webbrowser.open("https://buycoffee.to/mkola"))
            w.bind("<Enter>", self._on_enter)
            w.bind("<Leave>", self._on_leave)

        self.bind("<Configure>", self._on_conf)

    def _on_conf(self, e):
        if e.width < 50 or e.height < 50:
            return
        if abs(e.width - self.w) < 3 and abs(e.height - self.h) < 3:
            return
        self.w = e.width
        self.h = e.height
        inner_w = max(10, self.w - 2 * self.pad_x)
        inner_h = max(10, self.h - 2 * self.pad_y)
        self.itemconfigure(self.win, width=inner_w, height=inner_h)
        if self._draw_job is not None:
            try:
                self.after_cancel(self._draw_job)
            except Exception:
                pass
        self._draw_job = self.after(20, self._draw_bg)

    def _draw_bg(self):
        self._draw_job = None
        if not PIL_AVAILABLE:
            self.configure(bg="#20130A")
            return

        w, h = max(50, self.w), max(50, self.h)
        r = self.radius

        bg_col = Image.new("RGBA", (1, h))
        for y in range(h):
            fy = y / max(1, h - 1)
            if self._is_hovered:
                rc = int(52 * (1 - fy) + 32 * fy)
                gc = int(32 * (1 - fy) + 18 * fy)
                bc = int(18 * (1 - fy) + 10 * fy)
            else:
                rc = int(38 * (1 - fy) + 22 * fy)
                gc = int(24 * (1 - fy) + 14 * fy)
                bc = int(14 * (1 - fy) + 8 * fy)
            bg_col.putpixel((0, y), (rc, gc, bc, 255))
        bg = bg_col.resize((w, h), Image.Resampling.BILINEAR)

        mask = Image.new("L", (w, h), 0)
        d = ImageDraw.Draw(mask)
        d.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=r, fill=255)
        bg.putalpha(mask)

        # Border
        b_draw = ImageDraw.Draw(bg)
        border_rgba = (251, 191, 36, 240) if self._is_hovered else (217, 119, 6, 170)
        b_draw.rounded_rectangle([(0, 0), (w - 1, h - 1)], radius=r, outline=border_rgba, width=1)

        self._bg_photo = ImageTk.PhotoImage(bg)
        self.delete("card_bg")
        self.create_image(0, 0, image=self._bg_photo, anchor="nw", tags="card_bg")
        self.tag_lower("card_bg")

    def _on_enter(self, e):
        self._is_hovered = True
        bg_inner = "#2E1A0F"
        self.inner.configure(bg=bg_inner)
        for child in self.inner.winfo_children():
            if isinstance(child, tk.Frame):
                child.configure(bg=bg_inner)
        self.lbl_title.configure(bg=bg_inner, fg="#FDE68A")
        self.lbl_desc.configure(bg=bg_inner, fg="#FFFFFF")
        self.lbl_badge.configure(bg="#5C2E14", fg="#FFFFFF", highlightbackground="#F59E0B")
        self._draw_bg()

    def _on_leave(self, e):
        self._is_hovered = False
        bg_inner = "#20130A"
        self.inner.configure(bg=bg_inner)
        for child in self.inner.winfo_children():
            if isinstance(child, tk.Frame):
                child.configure(bg=bg_inner)
        self.lbl_title.configure(bg=bg_inner, fg="#FBBF24")
        self.lbl_desc.configure(bg=bg_inner, fg="#CBD5E1")
        self.lbl_badge.configure(bg="#452410", fg="#FEF3C7", highlightbackground="#D97706")
        self._draw_bg()


class FuturisticGearWidget(tk.Canvas):
    """Futuristic Cockpit Virtual Gear Telemetry HUD with glowing neon gear number and 30-segment LED cassette bar."""

    def __init__(self, parent, current_gear: int = 15, max_gear: int = 30, height: int = 120, bg: str = BG_CARD, **kwargs):
        super().__init__(parent, height=height, bg=bg, bd=0, highlightthickness=0, **kwargs)
        self.current_gear = current_gear
        self.max_gear = max_gear
        self.w = 380
        self.h = height
        self._photo = None
        self._render_job = None
        self.bind("<Configure>", self._on_conf)

    def update_gear(self, new_gear: int, max_gear: Optional[int] = None):
        self.current_gear = new_gear
        if max_gear is not None:
            self.max_gear = max_gear
        self._render()

    def _on_conf(self, e):
        if e.width < 100 or e.height < 50:
            return
        if abs(e.width - self.w) < 4:
            return
        self.w = e.width
        self.h = e.height
        if self._render_job is not None:
            try:
                self.after_cancel(self._render_job)
            except Exception:
                pass
        self._render_job = self.after(20, self._render)

    def _render(self):
        self._render_job = None
        if not PIL_AVAILABLE:
            return

        w, h = max(260, self.w), max(80, self.h)
        cur_gear = self.current_gear
        max_gear = self.max_gear

        img = Image.new("RGBA", (w, h), (12, 20, 32, 255))
        glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        d_glow = ImageDraw.Draw(glow)
        d = ImageDraw.Draw(img)

        font_big = load_pil_font(64, prefer_chakra=True)
        font_mid = load_pil_font(12, prefer_chakra=True)
        font_sm = load_pil_font(9, prefer_chakra=True)

        num_str = str(cur_gear)
        num_x = 16
        num_y = (h - 74) // 2

        # Glowing green number on the left (massive heroic gear digit with soft glow)
        for ox, oy in [(-2, 0), (2, 0), (0, -2), (0, 2), (-1, -1), (1, 1)]:
            d_glow.text((num_x + ox, num_y + oy), num_str, fill=(0, 230, 118, 140), font=font_big)
        d.text((num_x, num_y), num_str, fill=(0, 230, 118, 255), font=font_big)

        bbox = d.textbbox((num_x, num_y), num_str, font=font_big)
        num_w = bbox[2] - bbox[0]
        label_x = num_x + num_w + 10

        # BIEG / 30 stacked next to the number
        d.text((label_x, num_y + 16), "BIEG", fill=(148, 163, 184, 255), font=font_sm)
        d.text((label_x, num_y + 32), f"/ {max_gear}", fill=(226, 232, 240, 255), font=font_mid)

        # Cassette container box on the right
        box_x = label_x + 46
        box_y = 12
        box_w = max(180, w - box_x - 14)
        box_h = h - 24

        # Rounded container
        d.rounded_rectangle([(box_x, box_y), (box_x + box_w, box_y + box_h)], radius=12, fill=(9, 15, 24, 255), outline=(22, 36, 54, 255), width=1)

        # Header labels row
        d.text((box_x + 12, box_y + 8), "1 (Podjazdy)", fill=(251, 113, 133, 255), font=font_sm)
        mid_text = "Tryb MyShift LED HUD"
        m_bbox = d.textbbox((0, 0), mid_text, font=font_sm)
        d.text((box_x + (box_w - (m_bbox[2] - m_bbox[0])) // 2, box_y + 8), mid_text, fill=(0, 230, 118, 255), font=font_sm)
        d.text((box_x + box_w - 62, box_y + 8), f"{max_gear} (Sprint)", fill=(56, 189, 248, 255), font=font_sm)

        # Segments tray groove
        tray_x = box_x + 10
        tray_y = box_y + 26
        tray_w = box_w - 20
        tray_h = box_h - 36

        d.rounded_rectangle([(tray_x, tray_y), (tray_x + tray_w, tray_y + tray_h)], radius=8, fill=(6, 10, 16, 255), outline=(15, 23, 42, 255), width=1)

        # 30 capsule segments
        total_bars = min(30, max_gear)
        pad = 3
        usable_w = tray_w - 2 * pad
        seg_step = usable_w / total_bars
        seg_w = max(2, int(seg_step - 2))

        for i in range(1, total_bars + 1):
            sx = tray_x + pad + int((i - 1) * seg_step)
            is_lit = (i <= cur_gear)
            is_active = (i == cur_gear)

            if is_active:
                sy = tray_y + 3
                sh = tray_h - 6
                # Cyan highlight with bright glow
                d_glow.rounded_rectangle([(sx - 3, sy - 3), (sx + seg_w + 3, sy + sh + 3)], radius=4, fill=(0, 229, 255, 180))
                d.rounded_rectangle([(sx, sy), (sx + seg_w, sy + sh)], radius=3, fill=(0, 229, 255, 255))
            elif is_lit:
                sy = tray_y + 4
                sh = tray_h - 8
                d_glow.rounded_rectangle([(sx - 1, sy - 1), (sx + seg_w + 1, sy + sh + 1)], radius=3, fill=(0, 230, 118, 90))
                d.rounded_rectangle([(sx, sy), (sx + seg_w, sy + sh)], radius=2, fill=(0, 230, 118, 255))
            else:
                # Inactive: shorter segment aligned to bottom
                sh = int(tray_h * 0.65)
                sy = tray_y + tray_h - sh - 4
                d.rounded_rectangle([(sx, sy), (sx + seg_w, sy + sh)], radius=2, fill=(21, 34, 51, 255))

        blurred_glow = glow.filter(ImageFilter.GaussianBlur(3))
        composite = Image.alpha_composite(img, blurred_glow)
        final = Image.alpha_composite(composite, img)

        self._photo = ImageTk.PhotoImage(final)
        self.delete("hud_img")
        self.create_image(0, 0, anchor="nw", image=self._photo, tags="hud_img")


def apply_windows_dark_titlebar(window: tk.Tk | tk.Toplevel):
    """Enables Windows 10/11 immersive dark mode or macOS DarkAqua appearance on window title bar."""
    if IS_MACOS:
        try:
            window.tk.call("::tk::unsupported::MacWindowStyle", "appearance", window._w, "darkaqua")
        except Exception:
            pass
        return
    if not IS_WINDOWS:
        return
    try:
        window.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(window.winfo_id())
        if not hwnd:
            hwnd = window.winfo_id()
        for attr in (20, 19):  # 20 = Win11/Win10 20H1+, 19 = older Win10
            val = ctypes.c_int(1)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)
            )
    except Exception:
        pass


def get_asset_path(filename: str) -> str:
    """Finds asset path across development, portable PyInstaller (.exe / macOS .app), and working dir."""
    if hasattr(sys, "_MEIPASS"):
        p = os.path.join(sys._MEIPASS, "assets", filename)
        if os.path.exists(p):
            return p
        p_root = os.path.join(sys._MEIPASS, filename)
        if os.path.exists(p_root):
            return p_root
    exe_dir = os.path.dirname(os.path.abspath(sys.executable))
    p_exe = os.path.join(exe_dir, "assets", filename)
    if os.path.exists(p_exe):
        return p_exe
    # macOS .app bundle Contents/Resources/assets
    p_mac_res = os.path.abspath(os.path.join(exe_dir, "..", "Resources", "assets", filename))
    if os.path.exists(p_mac_res):
        return p_mac_res
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    p_dev = os.path.join(base_dir, "assets", filename)
    if os.path.exists(p_dev):
        return p_dev
    return filename


def load_pil_font(size: int, prefer_chakra: bool = False):
    """Loads an anti-aliased Pillow TrueType font supporting Polish diacritics across Windows & macOS."""
    if not PIL_AVAILABLE:
        return None
    candidates = []
    chakra_path = get_asset_path("ChakraPetch-Bold.ttf")
    if prefer_chakra and os.path.exists(chakra_path):
        candidates.append(chakra_path)
    if IS_WINDOWS:
        candidates.extend(["segoeuib.ttf", "segoeui.ttf", "arialbd.ttf"])
    elif IS_MACOS:
        candidates.extend([
            "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
            "/System/Library/Fonts/Helvetica.ttc",
            "/Library/Fonts/Arial Bold.ttf",
        ])
    if os.path.exists(chakra_path):
        candidates.append(chakra_path)

    for c in candidates:
        try:
            return ImageFont.truetype(c, size)
        except Exception:
            continue
    return ImageFont.load_default()


def register_custom_fonts():
    """Registers Chakra Petch custom fonts in Windows GDI or macOS CoreText for native Tkinter widget usage."""
    try:
        for font_file in ("ChakraPetch-Bold.ttf", "ChakraPetch-SemiBold.ttf"):
            p = get_asset_path(font_file)
            if not os.path.exists(p):
                continue
            abs_p = os.path.abspath(p)
            if IS_WINDOWS:
                ctypes.windll.gdi32.AddFontResourceExW(abs_p, 0x10, 0)
            elif IS_MACOS:
                try:
                    ct = ctypes.cdll.LoadLibrary(
                        "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices"
                    )
                    cf = ctypes.cdll.LoadLibrary(
                        "/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation"
                    )
                    cf.CFURLCreateFromFileSystemRepresentation.argtypes = [
                        ctypes.c_void_p, ctypes.c_char_p, ctypes.c_long, ctypes.c_bool
                    ]
                    cf.CFURLCreateFromFileSystemRepresentation.restype = ctypes.c_void_p
                    ct.CTFontManagerRegisterFontsForURL.argtypes = [
                        ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p
                    ]
                    ct.CTFontManagerRegisterFontsForURL.restype = ctypes.c_bool
                    cf.CFRelease.argtypes = [ctypes.c_void_p]
                    path_bytes = abs_p.encode("utf-8")
                    url = cf.CFURLCreateFromFileSystemRepresentation(None, path_bytes, len(path_bytes), False)
                    if url:
                        ct.CTFontManagerRegisterFontsForURL(url, 1, None)  # kCTFontManagerScopeProcess = 1
                        cf.CFRelease(url)
                except Exception:
                    pass
    except Exception as e:
        print(f"[Font Registration Warning] {e}")


class MiniOverlayWindow(tk.Toplevel):
    """Compact floating HUD window showing gear and battery during rides."""

    def __init__(self, parent, shifter: VirtualShifter):
        super().__init__(parent)
        self.shifter = shifter
        self.title("VeloBridge HUD")
        self.geometry("270x90+80+80")
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        if IS_MACOS:
            try:
                self.lift()
            except Exception:
                pass
        self.configure(bg=BG_DARK)

        self._offset_x = 0
        self._offset_y = 0
        self.bind("<Button-1>", self._start_drag)
        self.bind("<B1-Motion>", self._do_drag)

        container = tk.Frame(
            self,
            bg=BG_CARD,
            highlightthickness=1,
            highlightbackground=ACCENT_CYAN
        )
        container.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        container.bind("<Button-1>", self._start_drag)
        container.bind("<B1-Motion>", self._do_drag)

        # Header bar
        hbar = tk.Frame(container, bg=BG_CARD)
        hbar.pack(fill=tk.X, padx=8, pady=(4, 0))
        tk.Label(
            hbar,
            text="⚡ VELOBRIDGE HUD",
            font=("Segoe UI", 7, "bold"),
            fg=ACCENT_CYAN,
            bg=BG_CARD
        ).pack(side=tk.LEFT)

        btn_close = tk.Label(
            hbar,
            text="✕",
            font=("Segoe UI", 9, "bold"),
            fg=TEXT_MUTED,
            bg=BG_CARD,
            cursor="hand2"
        )
        btn_close.pack(side=tk.RIGHT)
        btn_close.bind("<Button-1>", lambda e: self.destroy())

        self.lbl_gear = tk.Label(
            container,
            text=f"BIEG {self.shifter.current_gear} / {self.shifter.max_gear}",
            font=("Segoe UI", 16, "bold"),
            fg=ACCENT_EMERALD,
            bg=BG_CARD
        )
        self.lbl_gear.pack(pady=2)

        self.lbl_sub = tk.Label(
            container,
            text="Lewa: 🔋 --%   |   Prawa: 🔋 --%",
            font=("Segoe UI", 8),
            fg=TEXT_MUTED,
            bg=BG_CARD
        )
        self.lbl_sub.pack(pady=(0, 4))

    def _start_drag(self, event):
        self._offset_x = event.x
        self._offset_y = event.y

    def _do_drag(self, event):
        x = self.winfo_pointerx() - self._offset_x
        y = self.winfo_pointery() - self._offset_y
        self.geometry(f"+{x}+{y}")

    def update_gear(self, gear: int):
        self.lbl_gear.configure(text=f"BIEG {gear} / {self.shifter.max_gear}")

    def update_battery(self, bat_l: int, bat_r: int):
        txt_l = f"{bat_l}%" if bat_l >= 0 else "--%"
        txt_r = f"{bat_r}%" if bat_r >= 0 else "--%"
        self.lbl_sub.configure(text=f"Lewa: 🔋 {txt_l}   |   Prawa: 🔋 {txt_r}")


class DeviceManagerDialog(tk.Toplevel):
    """Modal dialog for BLE scanning and MAC address configuration."""

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.app.active_device_dialog = self
        self.title("Konfiguracja Urządzeń BLE Zwift")
        self.geometry("660x540")
        self.configure(bg=BG_DARK)
        self.transient(parent)
        self.grab_set()

        apply_windows_dark_titlebar(self)

        icon_path = get_asset_path("app_icon.ico")
        if os.path.exists(icon_path):
            try:
                self.iconbitmap(icon_path)
            except Exception:
                pass

        # Center
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() // 2) - 330
        y = parent.winfo_rooty() + (parent.winfo_height() // 2) - 270
        self.geometry(f"+{x}+{y}")

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._build_ui()

    def _build_ui(self):
        header = tk.Frame(self, bg=BG_DARK, padx=18, pady=12)
        header.pack(fill=tk.X)
        tk.Label(
            header,
            text="Zarządzanie manetkami Bluetooth (Zwift Click & Play)",
            font=("Segoe UI", 12, "bold"),
            fg=TEXT_WHITE,
            bg=BG_DARK
        ).pack(anchor="w")
        tk.Label(
            header,
            text="Wykryj manetki za pomocą skanera BLE lub wpisz ich adresy MAC ręcznie.",
            font=("Segoe UI", 8),
            fg=TEXT_MUTED,
            bg=BG_DARK
        ).pack(anchor="w")

        # MAC entries card with Swap button
        mac_frame = tk.Frame(
            self,
            bg=BG_CARD,
            padx=14,
            pady=12,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR
        )
        mac_frame.pack(fill=tk.X, padx=16, pady=(0, 10))

        entries_box = tk.Frame(mac_frame, bg=BG_CARD)
        entries_box.pack(side=tk.LEFT, fill=tk.X, expand=True)

        row1 = tk.Frame(entries_box, bg=BG_CARD)
        row1.pack(fill=tk.X, pady=4)
        tk.Label(
            row1,
            text="👈 Lewa manetka (MAC):",
            width=22,
            anchor="w",
            font=("Segoe UI", 9, "bold"),
            fg=TEXT_WHITE,
            bg=BG_CARD
        ).pack(side=tk.LEFT)
        self.entry_mac_l = tk.Entry(
            row1,
            font=("Consolas", 10),
            bg=BG_INPUT,
            fg=TEXT_WHITE,
            insertbackground=ACCENT_CYAN,
            width=22,
            bd=1,
            relief=tk.SOLID
        )
        self.entry_mac_l.insert(0, self.app.cfg.get("mac_left", ""))
        self.entry_mac_l.pack(side=tk.LEFT, padx=6)

        row2 = tk.Frame(entries_box, bg=BG_CARD)
        row2.pack(fill=tk.X, pady=4)
        tk.Label(
            row2,
            text="👉 Prawa manetka (MAC):",
            width=22,
            anchor="w",
            font=("Segoe UI", 9, "bold"),
            fg=TEXT_WHITE,
            bg=BG_CARD
        ).pack(side=tk.LEFT)
        self.entry_mac_r = tk.Entry(
            row2,
            font=("Consolas", 10),
            bg=BG_INPUT,
            fg=TEXT_WHITE,
            insertbackground=ACCENT_CYAN,
            width=22,
            bd=1,
            relief=tk.SOLID
        )
        self.entry_mac_r.insert(0, self.app.cfg.get("mac_right", "F5:9D:F1:42:AA:92"))
        self.entry_mac_r.pack(side=tk.LEFT, padx=6)

        # Swap button beside entries
        swap_box = tk.Frame(mac_frame, bg=BG_CARD)
        swap_box.pack(side=tk.RIGHT, padx=(10, 0))

        btn_swap = tk.Button(
            swap_box,
            text="⇄ Zamień manetki\n(Lewa ⮂ Prawa)",
            font=("Segoe UI", 9, "bold"),
            bg=BG_CARD_INNER,
            fg=ACCENT_CYAN,
            activebackground="#2D3B55",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            padx=12,
            pady=8,
            cursor="hand2",
            command=self._swap_macs
        )
        btn_swap.pack(side=tk.RIGHT)

        # Scanner section
        scan_card = tk.Frame(
            self,
            bg=BG_CARD,
            padx=14,
            pady=10,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR
        )
        scan_card.pack(fill=tk.BOTH, expand=True, padx=16, pady=(0, 10))

        scan_top = tk.Frame(scan_card, bg=BG_CARD)
        scan_top.pack(fill=tk.X, pady=(0, 6))
        tk.Label(
            scan_top,
            text="Wykryte urządzenia Bluetooth w pobliżu:",
            font=("Segoe UI", 9, "bold"),
            fg=ACCENT_CYAN,
            bg=BG_CARD
        ).pack(side=tk.LEFT)

        self.btn_scan = tk.Button(
            scan_top,
            text="🔍 Skanuj BLE (4 sekundy)",
            font=("Segoe UI", 9, "bold"),
            bg=ACCENT_CYAN,
            fg=BG_DARK,
            activebackground="#33ECFF",
            activeforeground=BG_DARK,
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=self._do_scan
        )
        self.btn_scan.pack(side=tk.RIGHT)

        # Treeview styling for dark theme
        self.tree = ttk.Treeview(
            scan_card,
            columns=("name", "mac", "rssi", "side"),
            show="headings",
            height=7
        )
        self.tree.heading("name", text="Nazwa urządzenia")
        self.tree.heading("mac", text="Adres MAC")
        self.tree.heading("rssi", text="Sygnał (RSSI)")
        self.tree.heading("side", text="Rozpoznany typ / strona")
        self.tree.column("name", width=190)
        self.tree.column("mac", width=160)
        self.tree.column("rssi", width=90)
        self.tree.pack(fill=tk.BOTH, expand=True, pady=4)
        self.tree.bind("<Double-1>", self._on_tree_double_click)

        assign_bar = tk.Frame(scan_card, bg=BG_CARD)
        assign_bar.pack(fill=tk.X, pady=6)
        tk.Button(
            assign_bar,
            text="👈 Wstaw zaznaczone do LEWEJ",
            font=("Segoe UI", 8, "bold"),
            bg="#1E3A8A",
            fg=TEXT_WHITE,
            activebackground="#2563EB",
            activeforeground=TEXT_WHITE,
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=self._assign_left
        ).pack(side=tk.LEFT, padx=3)

        tk.Button(
            assign_bar,
            text="👉 Wstaw zaznaczone do PRAWEJ",
            font=("Segoe UI", 8, "bold"),
            bg="#065F46",
            fg=TEXT_WHITE,
            activebackground="#059669",
            activeforeground=TEXT_WHITE,
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=self._assign_right
        ).pack(side=tk.LEFT, padx=6)

        # Footer
        footer = tk.Frame(self, bg=BG_DARK, padx=16, pady=8)
        footer.pack(fill=tk.X)

        if getattr(self.app, "is_debug_mode", False):
            tk.Button(
                footer,
                text="🧪 Diagnostyka Zwift Click",
                font=("Segoe UI", 9, "bold"),
                bg="#1E1B4B",
                fg="#A5B4FC",
                activebackground="#312E81",
                activeforeground=TEXT_WHITE,
                bd=1,
                relief=tk.SOLID,
                highlightbackground="#4338CA",
                padx=12,
                pady=4,
                cursor="hand2",
                command=self.app._open_click_diagnostic
            ).pack(side=tk.LEFT)

        tk.Button(
            footer,
            text="✓ Zapisz i zastosuj",
            font=("Segoe UI", 9, "bold"),
            bg=ACCENT_EMERALD,
            fg=BG_DARK,
            activebackground="#059669",
            activeforeground=TEXT_WHITE,
            bd=0,
            padx=16,
            pady=5,
            cursor="hand2",
            command=self._save_and_close
        ).pack(side=tk.RIGHT)

        tk.Button(
            footer,
            text="Anuluj",
            font=("Segoe UI", 9),
            bg=BG_CARD,
            fg=TEXT_MUTED,
            bd=0,
            padx=12,
            pady=5,
            cursor="hand2",
            command=self._on_close
        ).pack(side=tk.RIGHT, padx=8)

        # Populate with known devices
        for d in self.app.scanned_devices:
            self.tree.insert("", tk.END, values=(d.get("name", "Nieznane"), d.get("address", ""), f"{d.get('rssi', '--')} dBm", d.get("side", "auto").upper()))

    def _do_scan(self):
        # 1. Clear treeview completely
        for item in self.tree.get_children():
            self.tree.delete(item)

        # 2. Clear app stored scanned devices
        self.app.scanned_devices = []

        # 3. Update scan button text and disable during active scan
        self.btn_scan.configure(
            text="⏳ Skanowanie BLE (4s)...",
            state=tk.DISABLED,
            bg="#132338",
            fg="#94A3B8"
        )

        # 4. Insert progress placeholder
        self.tree.insert("", tk.END, values=("⏳ Skanowanie urządzeń Bluetooth w toku...", "--", "--", "--"))

        # 5. Send command to BLE worker
        self.app.ble.post_command("SCAN", timeout=4.0)

        # 6. Safety timeout to re-enable button after 5.5s
        self.after(5500, self._ensure_scan_button_reset)

    def on_scan_completed(self, devices):
        self._ensure_scan_button_reset()
        for item in self.tree.get_children():
            self.tree.delete(item)

        if not devices:
            self.tree.insert("", tk.END, values=("(Nie wykryto urządzeń BLE w pobliżu)", "--", "--", "--"))
            return

        for d in devices:
            self.tree.insert(
                "",
                tk.END,
                values=(
                    d.get("name", "Nieznane urządzenie"),
                    d.get("address", ""),
                    f"{d.get('rssi', '--')} dBm",
                    d.get("side", "auto").upper()
                )
            )

    def _ensure_scan_button_reset(self):
        try:
            if hasattr(self, "btn_scan") and self.btn_scan.winfo_exists():
                self.btn_scan.configure(
                    text="🔍 Skanuj BLE (4 sekundy)",
                    state=tk.NORMAL,
                    bg=ACCENT_CYAN,
                    fg=BG_DARK
                )
        except Exception:
            pass

    def _on_tree_double_click(self, event=None):
        sel = self.tree.selection()
        if not sel:
            return
        item = self.tree.item(sel[0])
        val = item.get("values", [])
        if len(val) >= 4:
            side_str = str(val[3]).lower()
            if "left" in side_str:
                self._assign_left()
                return
        self._assign_right()

    def _assign_left(self):
        sel = self.tree.selection()
        if not sel:
            return
        item = self.tree.item(sel[0])
        val = item.get("values", [])
        if len(val) >= 2 and val[1] != "--":
            name = str(val[0])
            mac = str(val[1]).strip().upper()
            self.entry_mac_l.delete(0, tk.END)
            self.entry_mac_l.insert(0, mac)
            self.app.discovered_device_names[mac] = name

            dev_meta = next((d for d in self.app.scanned_devices if d.get("address", "").strip().upper() == mac), {})
            type_str = dev_meta.get("type", "")
            is_click = "click" in name.lower() or "click" in type_str.lower() or dev_meta.get("side", "").lower() == "click"
            if is_click:
                self.app.cfg["model_left"] = "click"
                self.app.cfg["name_left"] = "Zwift Click (Lewa)"
                self.app.discovered_device_names[mac] = "Zwift Click"
            elif "play" in name.lower() or "play" in type_str.lower():
                self.app.cfg["model_left"] = "play"
                self.app.cfg["name_left"] = "Zwift Play (Left)"

    def _assign_right(self):
        sel = self.tree.selection()
        if not sel:
            return
        item = self.tree.item(sel[0])
        val = item.get("values", [])
        if len(val) >= 2 and val[1] != "--":
            name = str(val[0])
            mac = str(val[1]).strip().upper()
            self.entry_mac_r.delete(0, tk.END)
            self.entry_mac_r.insert(0, mac)
            self.app.discovered_device_names[mac] = name

            dev_meta = next((d for d in self.app.scanned_devices if d.get("address", "").strip().upper() == mac), {})
            type_str = dev_meta.get("type", "")
            is_click = "click" in name.lower() or "click" in type_str.lower() or dev_meta.get("side", "").lower() == "click"
            if is_click:
                self.app.cfg["model_right"] = "click"
                self.app.cfg["name_right"] = "Zwift Click"
                self.app.cfg["hardware_model"] = "click"
                self.app.selected_hardware_model = "click"
                self.app.discovered_device_names[mac] = "Zwift Click"
            elif "play" in name.lower() or "play" in type_str.lower():
                self.app.cfg["model_right"] = "play"
                self.app.cfg["name_right"] = "Zwift Play"
                self.app.cfg["hardware_model"] = "play"
                self.app.selected_hardware_model = "play"

    def _swap_macs(self):
        """Swaps MAC addresses between left and right controller slots."""
        mac_l = self.entry_mac_l.get().strip()
        mac_r = self.entry_mac_r.get().strip()
        self.entry_mac_l.delete(0, tk.END)
        self.entry_mac_l.insert(0, mac_r)
        self.entry_mac_r.delete(0, tk.END)
        self.entry_mac_r.insert(0, mac_l)

    def _save_and_close(self):
        self.app.cfg["mac_left"] = self.entry_mac_l.get().strip()
        self.app.cfg["mac_right"] = self.entry_mac_r.get().strip()
        self.app.cfg["hardware_model"] = self.app.selected_hardware_model
        if self.app.selected_hardware_model == "click":
            self.app.cfg["model_right"] = "click"
        elif self.app.selected_hardware_model == "play":
            self.app.cfg["model_right"] = "play"
        self.app._sync_device_mode_config()
        self.app.config_mgr.save()
        self.app._update_connection_display()
        self.app._check_connected_hardware_models()
        self.app._render_controller_diagram()
        self._on_close()

    def _on_close(self):
        if getattr(self.app, "active_device_dialog", None) is self:
            self.app.active_device_dialog = None
        self.destroy()


class LogsViewerDialog(tk.Toplevel):
    """Full scrolling diagnostic log window."""

    def __init__(self, parent, log_text: str):
        super().__init__(parent)
        self.title("Dziennik Zdarzeń BLE i DirectInput")
        self.geometry("720x500")
        self.configure(bg=BG_DARK)
        apply_windows_dark_titlebar(self)
        icon_path = get_asset_path("app_icon.ico")
        if os.path.exists(icon_path):
            try:
                self.iconbitmap(icon_path)
            except Exception:
                pass

        txt = tk.Text(
            self,
            bg="#080C12",
            fg="#CBD5E1",
            font=("Consolas", 9),
            wrap=tk.WORD,
            bd=0,
            padx=12,
            pady=12
        )
        scroll = ttk.Scrollbar(self, orient="vertical", command=txt.yview)
        txt.configure(yscrollcommand=scroll.set)
        txt.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        txt.insert(tk.END, log_text)
        txt.see(tk.END)


class MyWhooshPathDialog(tk.Toplevel):
    """
    Modern modal dialog allowing user to configure or auto-detect MyWhoosh executable / shortcut path.
    Saves path to VeloBridge_config.json.
    """

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.title("Lokalizacja i ścieżka gry MyWhoosh — VeloBridge")
        self.geometry("700x530")
        self.minsize(620, 460)
        self.configure(bg=BG_DARK)
        self.transient(parent)
        self.grab_set()

        apply_windows_dark_titlebar(self)

        icon_path = get_asset_path("app_icon.ico")
        if os.path.exists(icon_path):
            try:
                self.iconbitmap(icon_path)
            except Exception:
                pass

        # Center on parent window
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - 350
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - 265
            self.geometry(f"+{max(20, x)}+{max(20, y)}")
        except Exception:
            pass

        self._build_ui()

    def _build_ui(self):
        # 1. Header
        header = tk.Frame(self, bg=BG_DARK, padx=20, pady=12)
        header.pack(fill=tk.X)

        title_row = tk.Frame(header, bg=BG_DARK)
        title_row.pack(fill=tk.X)

        tk.Label(
            title_row,
            text="📁 Ścieżka do gry MyWhoosh / MyWhoosh HD",
            font=("Segoe UI", 12, "bold"),
            fg=TEXT_WHITE,
            bg=BG_DARK
        ).pack(side=tk.LEFT)

        tk.Label(
            header,
            text=(
                "Wskaż aplikację MyWhoosh.app (w /Applications) lub skorzystaj z automatycznego wykrywania (Mac App Store / Spotlight)."
                if IS_MACOS else
                "Wskaż plik .exe lub skrót .lnk, albo skorzystaj z automatycznego wykrywania (np. Microsoft Store)."
            ),
            font=("Segoe UI", 9),
            fg=TEXT_MUTED,
            bg=BG_DARK
        ).pack(anchor="w", pady=(3, 0))

        # Thin divider
        tk.Frame(self, bg=BORDER_COLOR, height=1).pack(fill=tk.X, padx=16, pady=(0, 10))

        # 2. Main Content Card
        main_body = tk.Frame(self, bg=BG_DARK, padx=16)
        main_body.pack(fill=tk.BOTH, expand=True)

        card = tk.Frame(
            main_body,
            bg=BG_CARD,
            padx=16,
            pady=14,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR
        )
        card.pack(fill=tk.X, pady=(0, 10))

        tk.Label(
            card,
            text=(
                "Ścieżka do aplikacji gry MyWhoosh.app (macOS):"
                if IS_MACOS else
                "Ścieżka do pliku wykonywalnego gry (.exe) lub skrótu Windows (.lnk):"
            ),
            font=("Segoe UI", 9, "bold"),
            fg=TEXT_WHITE,
            bg=BG_CARD
        ).pack(anchor="w", pady=(0, 6))

        # Entry + Browse button row
        row_entry = tk.Frame(card, bg=BG_CARD)
        row_entry.pack(fill=tk.X, pady=(0, 10))

        current_val = self.app.cfg.get("mywhoosh_path", "")
        self.entry_path = tk.Entry(
            row_entry,
            font=("Consolas", 9),
            bg=BG_INPUT,
            fg=TEXT_WHITE,
            insertbackground=TEXT_WHITE,
            bd=0,
            highlightthickness=1,
            highlightbackground=BORDER_TILE
        )
        self.entry_path.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=6, padx=(0, 8))
        self.entry_path.insert(0, current_val)
        self.entry_path.bind("<KeyRelease>", lambda e: self._update_status_feedback())

        btn_browse = tk.Button(
            row_entry,
            text="📁 Przeglądaj...",
            font=("Segoe UI", 9, "bold"),
            bg="#13273D",
            fg=ACCENT_CYAN,
            activebackground="#1E3E5F",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#0284C7",
            padx=12,
            pady=4,
            cursor="hand2",
            command=self._browse_file
        )
        btn_browse.pack(side=tk.LEFT)

        # Status feedback banner
        self.f_status = tk.Frame(card, bg="#07131D", padx=10, pady=8, highlightthickness=1, highlightbackground="#0E2E4A")
        self.f_status.pack(fill=tk.X, pady=(0, 10))

        self.lbl_status = tk.Label(
            self.f_status,
            text="",
            font=("Segoe UI", 8),
            bg="#07131D",
            anchor="w",
            justify=tk.LEFT
        )
        self.lbl_status.pack(fill=tk.X)

        # Quick action row: Reset to auto & Test launch
        row_actions = tk.Frame(card, bg=BG_CARD)
        row_actions.pack(fill=tk.X)

        btn_auto = tk.Button(
            row_actions,
            text="🔄 Wykrywaj automatycznie (Resetuj)",
            font=("Segoe UI", 8),
            bg="#0F172A",
            fg="#94A3B8",
            activebackground="#1E293B",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#334155",
            padx=10,
            pady=4,
            cursor="hand2",
            command=self._set_auto
        )
        btn_auto.pack(side=tk.LEFT, padx=(0, 8))

        btn_test = tk.Button(
            row_actions,
            text="🚀 Przetestuj uruchomienie",
            font=("Segoe UI", 8, "bold"),
            bg="#064E3B",
            fg="#6EE7B7",
            activebackground="#059669",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#059669",
            padx=10,
            pady=4,
            cursor="hand2",
            command=self._test_launch
        )
        btn_test.pack(side=tk.LEFT)

        if IS_MACOS:
            btn_acc = tk.Button(
                row_actions,
                text="🔒 Uprawnienia Dostępności macOS",
                font=("Segoe UI", 8, "bold"),
                bg="#1E1B4B",
                fg="#A5B4FC",
                activebackground="#312E81",
                activeforeground=TEXT_WHITE,
                bd=1,
                relief=tk.SOLID,
                highlightbackground="#4338CA",
                padx=10,
                pady=4,
                cursor="hand2",
                command=lambda: check_macos_accessibility_permission(prompt=True)
            )
            btn_acc.pack(side=tk.LEFT, padx=(8, 0))

        # 3. Help Instructions Card
        card_help = tk.Frame(
            main_body,
            bg=BG_CARD,
            padx=14,
            pady=10,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR
        )
        card_help.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        tk.Label(
            card_help,
            text=(
                "💡 Wskazówki dla systemu macOS (Mac App Store / /Applications):"
                if IS_MACOS else
                "💡 Jak znaleźć grę (Microsoft Store lub MyWhoosh HD):"
            ),
            font=("Segoe UI", 9, "bold"),
            fg=ACCENT_AMBER,
            bg=BG_CARD
        ).pack(anchor="w", pady=(0, 4))

        if IS_MACOS:
            tips = [
                ("Katalog /Applications:", "Domyślnie VeloBridge automatycznie wykrywa aplikację /Applications/MyWhoosh.app zainstalowaną z Mac App Store lub instalatora."),
                ("Uprawnienia Dostępności:", "W systemie macOS przejdź do Ustawienia Systemowe -> Prywatność i ochrona -> Dostępność i włącz VeloBridge (lub Terminal), aby przekazywać klawisze K / I do MyWhoosh."),
                ("Uprawnienia Bluetooth:", "Przy pierwszym uruchomieniu zezwól aplikacji VeloBridge na dostęp do Bluetooth w celu połączenia z manetkami Zwift Play / Click."),
                ("Zapis w konfiguracji:", "Ścieżka zostanie natychmiast zapisana w pliku VeloBridge_config.json.")
            ]
        else:
            tips = [
                ("Microsoft Store (UWP):", "Domyślnie wykrywany automatycznie. Aby utworzyć skrót: przeciągnij ikonę MyWhoosh z Menu Start bezpośrednio na Pulpit, a następnie wskaż ten plik .lnk tutaj."),
                ("Folder shell:AppsFolder:", "Alternatywnie: wciśnij Win+R, wpisz 'shell:AppsFolder', kliknij prawym przyciskiem myszy na MyWhoosh i wybierz 'Utwórz skrót na pulpicie'."),
                ("MyWhoosh HD / Standalone:", "Wskaż plik MyWhoosh.exe (np. w folderze C:\\Program Files\\MyWhoosh\\) lub istniejący skrót na pulpicie."),
                ("Zapis w konfiguracji:", "Ścieżka zostanie natychmiast zapisana w pliku VeloBridge_config.json.")
            ]
        for title, desc in tips:
            row_tip = tk.Frame(card_help, bg=BG_CARD)
            row_tip.pack(fill=tk.X, pady=2)
            tk.Label(row_tip, text=f"• {title}", font=("Segoe UI", 8, "bold"), fg=TEXT_WHITE, bg=BG_CARD, width=24, anchor="w").pack(side=tk.LEFT)
            tk.Label(row_tip, text=desc, font=("Segoe UI", 8), fg=TEXT_MUTED, bg=BG_CARD, anchor="w", justify=tk.LEFT, wraplength=450).pack(side=tk.LEFT, fill=tk.X, expand=True)

        # 4. Footer
        footer = tk.Frame(self, bg=BG_DARK, padx=16, pady=10)
        footer.pack(fill=tk.X, side=tk.BOTTOM)

        tk.Label(
            footer,
            text="Plik konfiguracji: VeloBridge_config.json",
            font=("Segoe UI", 8),
            fg="#64748B",
            bg=BG_DARK
        ).pack(side=tk.LEFT)

        btn_save = tk.Button(
            footer,
            text="✓ Zapisz i zastosuj",
            font=("Segoe UI", 9, "bold"),
            bg=ACCENT_EMERALD,
            fg=BG_DARK,
            activebackground="#10B981",
            activeforeground=BG_DARK,
            bd=0,
            padx=16,
            pady=6,
            cursor="hand2",
            command=self._save_and_apply
        )
        btn_save.pack(side=tk.RIGHT, padx=(8, 0))

        btn_cancel = tk.Button(
            footer,
            text="Anuluj",
            font=("Segoe UI", 9),
            bg="#131D2B",
            fg=TEXT_WHITE,
            activebackground="#1C293D",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#223348",
            padx=14,
            pady=6,
            cursor="hand2",
            command=self.destroy
        )
        btn_cancel.pack(side=tk.RIGHT)

        self._update_status_feedback()

    def _browse_file(self):
        curr = self.entry_path.get().strip()
        if IS_MACOS:
            initial = "/Applications"
            if curr and os.path.exists(curr):
                initial = os.path.dirname(curr.rstrip("/")) or "/Applications"
            chosen = filedialog.askopenfilename(
                parent=self,
                title="Wskaż aplikację MyWhoosh.app w katalogu /Applications",
                initialdir=initial,
            )
            if not chosen:
                chosen = filedialog.askdirectory(
                    parent=self,
                    title="Lub wskaż pakiet MyWhoosh.app",
                    initialdir=initial,
                )
        else:
            initial = "C:\\Program Files"
            if curr and os.path.exists(curr):
                initial = os.path.dirname(curr)
            chosen = filedialog.askopenfilename(
                parent=self,
                title="Wskaż plik wykonywalny MyWhoosh.exe lub skrót gry (.lnk)",
                initialdir=initial,
                filetypes=[
                    ("Pliki MyWhoosh (*.exe, *.lnk)", "*.exe;*.lnk"),
                    ("Pliki wykonywalne (*.exe)", "*.exe"),
                    ("Skróty Windows (*.lnk)", "*.lnk"),
                    ("Wszystkie pliki (*.*)", "*.*")
                ]
            )
        if chosen:
            self.entry_path.delete(0, tk.END)
            self.entry_path.insert(0, chosen)
            self._update_status_feedback()

    def _set_auto(self):
        self.entry_path.delete(0, tk.END)
        self._update_status_feedback()

    def _update_status_feedback(self):
        p = self.entry_path.get().strip()
        if p:
            if os.path.exists(p):
                ext = os.path.splitext(p.rstrip("/\\"))[1].lower()
                if ext == ".app" or os.path.isdir(p):
                    kind = "Pakiet aplikacji macOS (.app)"
                    size_info = kind
                else:
                    size_kb = os.path.getsize(p) // 1024
                    kind = "Skrót Windows (.lnk)" if ext == ".lnk" else "Plik wykonywalny (.exe)"
                    size_info = f"{kind}, {size_kb} KB"
                self.lbl_status.configure(
                    text=f"✓ Poprawna ścieżka ({size_info}):\n  {p}",
                    fg="#6EE7B7"
                )
                self.f_status.configure(highlightbackground="#059669")
            else:
                self.lbl_status.configure(
                    text=f"⚠️ Plik nie istnieje pod wskazaną ścieżką:\n  {p}",
                    fg="#FCA5A5"
                )
                self.f_status.configure(highlightbackground="#DC2626")
        else:
            # Check auto-detection
            info = detect_mywhoosh("")
            if info:
                disp = info.get("display", "")
                src = info.get("source", "")
                self.lbl_status.configure(
                    text=f"⚡ Tryb automatyczny: Wykryto MyWhoosh ({disp})\n  Źródło: {src}",
                    fg=ACCENT_CYAN
                )
                self.f_status.configure(highlightbackground="#0284C7")
            else:
                self.lbl_status.configure(
                    text="⚡ Tryb automatyczny: Brak zapamiętanej ścieżki (VeloBridge spróbuje wykryć aktywny proces w tle).",
                    fg="#94A3B8"
                )
                self.f_status.configure(highlightbackground="#1E293B")

    def _test_launch(self):
        p = self.entry_path.get().strip()
        ok = launch_or_focus_mywhoosh(p if p else None)
        if ok:
            messagebox.showinfo(
                "Uruchomienie udane",
                "Pomyślnie uruchomiono lub uaktywniono okno gry MyWhoosh!",
                parent=self
            )
        else:
            messagebox.showwarning(
                "Niepowodzenie uruchomienia",
                "Nie udało się uruchomić gry. Upewnij się, że ścieżka jest poprawna lub gra jest zainstalowana.",
                parent=self
            )

    def _save_and_apply(self):
        new_path = self.entry_path.get().strip()
        self.app.cfg["mywhoosh_path"] = new_path
        self.app.config_mgr.save()
        self.app._update_mywhoosh_tile()
        self.app._log_local(f"Zapisano ścieżkę MyWhoosh: {new_path if new_path else 'Automatyczna detekcja'}")
        self.destroy()


class HelpDialog(tk.Toplevel):
    """Modern dark Help & User Guide dialog with clean scrollable manual cards."""

    def __init__(self, parent):
        super().__init__(parent)
        self.title("Centrum Pomocy - VeloBridge Pro")
        self.geometry("740x580")
        self.minsize(620, 460)
        self.configure(bg=BG_DARK)
        self.transient(parent)
        self.grab_set()

        apply_windows_dark_titlebar(self)

        icon_path = get_asset_path("app_icon.ico")
        if os.path.exists(icon_path):
            try:
                self.iconbitmap(icon_path)
            except Exception:
                pass

        # Center on parent window
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - 370
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - 290
            self.geometry(f"+{max(20, x)}+{max(20, y)}")
        except Exception:
            pass

        self._build_ui()

    def _build_ui(self):
        # Header
        header = tk.Frame(self, bg=BG_DARK, padx=20, pady=12)
        header.pack(fill=tk.X)

        title_row = tk.Frame(header, bg=BG_DARK)
        title_row.pack(fill=tk.X)

        tk.Label(
            title_row,
            text="📖 Centrum Pomocy i Podręcznik Użytkownika",
            font=("Segoe UI", 12, "bold"),
            fg=TEXT_WHITE,
            bg=BG_DARK
        ).pack(side=tk.LEFT)

        lbl_badge = tk.Label(
            title_row,
            text=APP_BADGE,
            font=("Segoe UI", 8, "bold"),
            fg=ACCENT_CYAN,
            bg="#13273D",
            padx=7,
            pady=2
        )
        lbl_badge.pack(side=tk.LEFT, padx=10)

        tk.Label(
            header,
            text="Instrukcja obsługi wirtualnej zmiany biegów (MyShift) dla gry MyWhoosh z manetkami Zwift Click i Play.",
            font=("Segoe UI", 9),
            fg=TEXT_MUTED,
            bg=BG_DARK
        ).pack(anchor="w", pady=(3, 0))

        # Thin cyan divider line
        divider = tk.Frame(self, bg=BORDER_COLOR, height=1)
        divider.pack(fill=tk.X, padx=16, pady=(0, 8))

        # Footer (placed first with side=BOTTOM so scrollable frame fills remaining space)
        footer = tk.Frame(self, bg=BG_DARK, padx=18, pady=10)
        footer.pack(fill=tk.X, side=tk.BOTTOM)

        btn_coffee_footer = tk.Button(
            footer,
            text="☕ Postaw kawę (buycoffee.to/mkola)",
            font=("Segoe UI", 9, "bold"),
            bg="#251810",
            fg="#FDBA74",
            activebackground="#3A2314",
            activeforeground="#FED7AA",
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#7C2D12",
            padx=14,
            pady=6,
            cursor="hand2",
            command=lambda: webbrowser.open("https://buycoffee.to/mkola")
        )
        btn_coffee_footer.pack(side=tk.LEFT)

        btn_close = tk.Button(
            footer,
            text="Zamknij",
            font=("Segoe UI", 9, "bold"),
            bg="#131D2B",
            fg=TEXT_WHITE,
            activebackground="#1C293D",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#223348",
            padx=20,
            pady=6,
            cursor="hand2",
            command=self.destroy
        )
        btn_close.pack(side=tk.RIGHT)

        # Scrollable container
        container = tk.Frame(self, bg=BG_DARK)
        container.pack(fill=tk.BOTH, expand=True, padx=16)

        canvas = tk.Canvas(container, bg=BG_DARK, bd=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=BG_DARK)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas_window = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

        def _on_canvas_configure(e):
            canvas.itemconfig(canvas_window, width=e.width)

        canvas.bind("<Configure>", _on_canvas_configure)
        canvas.configure(yscrollcommand=scrollbar.set)

        def _on_mousewheel(e):
            if canvas.winfo_exists():
                step = int(-1 * e.delta) if IS_MACOS else int(-1 * (e.delta / 120))
                if step == 0 and e.delta != 0:
                    step = -1 if e.delta > 0 else 1
                canvas.yview_scroll(step, "units")

        canvas.bind("<MouseWheel>", _on_mousewheel)
        scrollable_frame.bind("<MouseWheel>", _on_mousewheel)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        def _add_section(title: str, icon: str, badge_color: str, rows: list):
            card = tk.Frame(
                scrollable_frame,
                bg=BG_CARD,
                padx=16,
                pady=10,
                highlightthickness=1,
                highlightbackground=BORDER_COLOR
            )
            card.pack(fill=tk.X, pady=(0, 10))
            card.bind("<MouseWheel>", _on_mousewheel)

            top = tk.Frame(card, bg=BG_CARD)
            top.pack(fill=tk.X, pady=(0, 6))
            top.bind("<MouseWheel>", _on_mousewheel)

            lbl_t = tk.Label(
                top,
                text=f"{icon} {title}",
                font=("Segoe UI", 10, "bold"),
                fg=badge_color,
                bg=BG_CARD
            )
            lbl_t.pack(side=tk.LEFT)
            lbl_t.bind("<MouseWheel>", _on_mousewheel)

            for line in rows:
                if isinstance(line, tuple):
                    lead, desc = line
                    r_frame = tk.Frame(card, bg=BG_CARD)
                    r_frame.pack(fill=tk.X, pady=2)
                    r_frame.bind("<MouseWheel>", _on_mousewheel)
                    lbl_l = tk.Label(
                        r_frame,
                        text=lead,
                        font=("Segoe UI", 9, "bold"),
                        fg=TEXT_WHITE,
                        bg=BG_CARD,
                        width=25,
                        anchor="w"
                    )
                    lbl_l.pack(side=tk.LEFT)
                    lbl_l.bind("<MouseWheel>", _on_mousewheel)
                    lbl_d = tk.Label(
                        r_frame,
                        text=desc,
                        font=("Segoe UI", 9),
                        fg=TEXT_MUTED,
                        bg=BG_CARD,
                        anchor="w",
                        justify=tk.LEFT,
                        wraplength=420
                    )
                    lbl_d.pack(side=tk.LEFT, fill=tk.X, expand=True)
                    lbl_d.bind("<MouseWheel>", _on_mousewheel)
                else:
                    lbl_txt = tk.Label(
                        card,
                        text=line,
                        font=("Segoe UI", 9),
                        fg=TEXT_MUTED,
                        bg=BG_CARD,
                        anchor="w",
                        justify=tk.LEFT,
                        wraplength=640
                    )
                    lbl_txt.pack(fill=tk.X, pady=2)
                    lbl_txt.bind("<MouseWheel>", _on_mousewheel)

        _add_section(
            "1. Szybki start (Pierwsze kroki)",
            "⚡",
            ACCENT_EMERALD,
            [
                ("1. Bluetooth w Windows", "Upewnij się, że moduł Bluetooth w komputerze jest włączony."),
                ("2. Wybudzenie manetek", "Naciśnij dowolny przycisk na manetkach Zwift Click lub Play (dioda LED zacznie migać)."),
                ("3. Uruchomienie połączenia", "Kliknij przycisk 'POŁĄCZ I URUCHOM MYWHOOSH' w górnym pasku aplikacji."),
                ("4. Wirtualna zmiana biegów", "W grze MyWhoosh przełożenie wirtualne MyShift działa od razu podczas jazdy.")
            ]
        )

        _add_section(
            "2. Sterowanie i klawisze MyWhoosh",
            "🎮",
            ACCENT_CYAN,
            [
                ("Bieg W GÓRĘ (+1)", "Prawa manetka: Przycisk '+' / górna łopatka (symuluje klawisz 'K' w MyWhoosh)."),
                ("Bieg W DÓŁ (-1)", "Lewa manetka: Przycisk '–' / dolna łopatka (symuluje klawisz 'I' w MyWhoosh)."),
                ("Nawigacja na trasie", "Lewy D-Pad: Strzałki w górę / dół / lewo / prawo do wyboru kierunku na trasie."),
                ("Akcja / Zatwierdzenie", "Przycisk A: Zatwierdź (Enter) | Przycisk B: Akcja / Powerup (Spacja)."),
                ("Kamera i Pauza", "Przycisk Y: Zmiana kamery (Klawisz C) | Przycisk Z: Pauza / Menu (Klawisz Esc)."),
                ("Własne mapowanie", "Kliknij dowolny dymek na schemacie manetek, aby zmienić przypisany klawisz.")
            ]
        )

        _add_section(
            "3. Rozwiązywanie typowych problemów",
            "🛠",
            ACCENT_AMBER,
            [
                ("Manetki nie łączą się", "Upewnij się, że manetki nie są sparowane z inną aplikacją (np. Zwift na telefonie lub tablecie). Jeśli tak jest, wyłącz Bluetooth w telefonie."),
                ("Odwrotne działanie manetek", "Kliknij ikonę trybu ⚙ w sekcji 'STAN POŁĄCZENIA', a następnie wybierz '⇄ Zamień manetki miejscami (L ↔ P)'."),
                ("Gra nie reaguje na biegi", "Sprawdź, czy okno gry MyWhoosh jest aktywne. VeloBridge wysyła bezpośrednie kody sprzętowe DirectInput, które działają natywnie w grze.")
            ]
        )

        _add_section(
            "4. Wskazywanie ścieżki do MyWhoosh (Microsoft Store & HD)",
            "📁",
            ACCENT_CYAN,
            [
                ("Automatyczna detekcja", "VeloBridge domyślnie sam przeszukuje system Windows (Microsoft Store przez PowerShell Get-StartApps, rejestr Windows, aktywne procesy oraz foldery Program Files) i wykrywa grę."),
                ("Microsoft Store (UWP)", "Folder WindowsApps jest zabezpieczony przed bezpośrednim przeglądaniem. Aby utworzyć skrót: przeciągnij ikonę MyWhoosh z Menu Start bezpośrednio na Pulpit (utworzy się plik .lnk), a następnie wskaż ten plik .lnk w oknie '📁 Ścieżka gry'."),
                ("Folder shell:AppsFolder", "Alternatywnie: wciśnij Win+R, wpisz 'shell:AppsFolder' i naciśnij Enter. Kliknij prawym przyciskiem myszy na kafelku MyWhoosh i wybierz 'Utwórz skrót na pulpicie'. Następnie wskaż ten skrót w VeloBridge."),
                ("Wersja MyWhoosh HD", "Dla instalacji samodzielnej kliknij '📁 Ścieżka gry' i wskaż plik MyWhoosh.exe (np. w C:\\Program Files\\MyWhoosh\\) lub istniejący skrót gry z Pulpitu."),
                ("Zapis w konfiguracji", "Wskazana ścieżka zapisuje się trwale w pliku VeloBridge_config.json. W każdej chwili możesz zresetować ją do trybu automatycznego klikając 'Wykrywaj automatycznie'.")
            ]
        )

        _add_section(
            "5. Plik konfiguracyjny (VeloBridge_config.json)",
            "⚙",
            TEXT_WHITE,
            [
                ("Plik VeloBridge_config.json", "Wszystkie Twoje ustawienia, sparowane adresy MAC kontrolerów, ścieżka do gry oraz mapowania przycisków są zapisywane w pliku VeloBridge_config.json obok programu lub w %APPDATA%\\VeloBridge.")
            ]
        )


class ClickDiagnosticDialog(tk.Toplevel):
    """
    Kreator Diagnostyki i Kalibracji Przycisków Zwift Click.
    Krok po kroku prosi o kliknięcie poszczególnych przycisków w obu manetkach Zwift Click,
    rejestruje odebrane zdarzenia BLE, kody przycisków oraz surowe hexy pakietów,
    a całość zapisuje do pliku logu zwift_click_diagnostic.log z możliwością
    skopiowania jednym kliknięciem do schowka.
    """

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.app.active_diagnostic_dialog = self
        self.title("Zwift Click — Kreator Diagnostyki i Mapowania Przycisków")
        self.geometry("860x720")
        self.minsize(800, 620)
        self.configure(bg=BG_DARK)
        self.transient(parent)
        self.grab_set()

        apply_windows_dark_titlebar(self)

        icon_path = get_asset_path("app_icon.ico")
        if os.path.exists(icon_path):
            try:
                self.iconbitmap(icon_path)
            except Exception:
                pass

        # Center on parent window
        self.update_idletasks()
        try:
            x = parent.winfo_rootx() + (parent.winfo_width() // 2) - 430
            y = parent.winfo_rooty() + (parent.winfo_height() // 2) - 360
            self.geometry(f"+{max(20, x)}+{max(20, y)}")
        except Exception:
            pass

        self.log_filepath = os.path.abspath("zwift_click_diagnostic.log")
        self.auto_advance_job = None
        self.is_completed = False

        self.steps = [
            # --- PRAWA MANETKA (5 przycisków: Y, A, B, Z, +) ---
            {
                "id": "right_y",
                "side": "Prawa",
                "side_en": "right",
                "btn": "Y",
                "role_expected": "right",
                "title": "Prawa manetka — Przycisk [Y]",
                "instruction": "Weź do ręki PRAWĄ manetkę i kliknij fizyczny przycisk [Y] (górny przycisk pada).",
                "hint": "Górny przycisk na prawym padzie nawigacyjnym."
            },
            {
                "id": "right_a",
                "side": "Prawa",
                "side_en": "right",
                "btn": "A",
                "role_expected": "right",
                "title": "Prawa manetka — Przycisk [A]",
                "instruction": "Weź do ręki PRAWĄ manetkę i kliknij fizyczny przycisk [A] (prawy przycisk pada).",
                "hint": "Prawy przycisk na prawym padzie nawigacyjnym."
            },
            {
                "id": "right_b",
                "side": "Prawa",
                "side_en": "right",
                "btn": "B",
                "role_expected": "right",
                "title": "Prawa manetka — Przycisk [B]",
                "instruction": "Weź do ręki PRAWĄ manetkę i kliknij fizyczny przycisk [B] (dolny przycisk pada).",
                "hint": "Dolny przycisk na prawym padzie nawigacyjnym."
            },
            {
                "id": "right_z",
                "side": "Prawa",
                "side_en": "right",
                "btn": "Z",
                "role_expected": "right",
                "title": "Prawa manetka — Przycisk [Z]",
                "instruction": "Weź do ręki PRAWĄ manetkę i kliknij fizyczny przycisk [Z] (lewy przycisk pada).",
                "hint": "Lewy przycisk na prawym padzie nawigacyjnym."
            },
            {
                "id": "right_plus",
                "side": "Prawa",
                "side_en": "right",
                "btn": "+",
                "role_expected": "right",
                "title": "Prawa manetka — Przycisk PLUS (+)",
                "instruction": "Weź do ręki PRAWĄ manetkę i kliknij fizyczny przycisk PLUS (+) (dźwignia / shifter).",
                "hint": "Dźwignia / przycisk zmiany biegów w górę (+)."
            },
            # --- LEWA MANETKA (5 przycisków: Góra, Prawo, Lewo, Dół, -) ---
            {
                "id": "left_up",
                "side": "Lewa",
                "side_en": "left",
                "btn": "GÓRA (▲)",
                "role_expected": "left",
                "title": "Lewa manetka — Strzałka GÓRA (▲)",
                "instruction": "Weź do ręki LEWĄ manetkę i kliknij fizyczny przycisk ze strzałką w GÓRĘ (▲).",
                "hint": "Górny przycisk pada nawigacyjnego na lewej manetce."
            },
            {
                "id": "left_right",
                "side": "Lewa",
                "side_en": "left",
                "btn": "PRAWO (▶)",
                "role_expected": "left",
                "title": "Lewa manetka — Strzałka W PRAWO (▶)",
                "instruction": "Weź do ręki LEWĄ manetkę i kliknij fizyczny przycisk ze strzałką W PRAWO (▶).",
                "hint": "Prawy przycisk pada nawigacyjnego na lewej manetce."
            },
            {
                "id": "left_left",
                "side": "Lewa",
                "side_en": "left",
                "btn": "LEWO (◀)",
                "role_expected": "left",
                "title": "Lewa manetka — Strzałka W LEWO (◀)",
                "instruction": "Weź do ręki LEWĄ manetkę i kliknij fizyczny przycisk ze strzałką W LEWO (◀).",
                "hint": "Lewy przycisk pada nawigacyjnego na lewej manetce."
            },
            {
                "id": "left_down",
                "side": "Lewa",
                "side_en": "left",
                "btn": "DÓŁ (▼)",
                "role_expected": "left",
                "title": "Lewa manetka — Strzałka W DÓŁ (▼)",
                "instruction": "Weź do ręki LEWĄ manetkę i kliknij fizyczny przycisk ze strzałką W DÓŁ (▼).",
                "hint": "Dolny przycisk pada nawigacyjnego na lewej manetce."
            },
            {
                "id": "left_minus",
                "side": "Lewa",
                "side_en": "left",
                "btn": "MINUS (−)",
                "role_expected": "left",
                "title": "Lewa manetka — Przycisk MINUS (−)",
                "instruction": "Weź do ręki LEWĄ manetkę i kliknij fizyczny przycisk MINUS (−) (dźwignia / shifter).",
                "hint": "Dźwignia / przycisk redukcji biegów w dół (−)."
            }
        ]

        self.current_step_idx = 0
        self.results: List[Optional[Dict[str, Any]]] = [None] * len(self.steps)

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._build_ui()
        self._render_current_step()
        self._save_full_report_to_file()

    def _build_ui(self):
        # Header Frame
        header = tk.Frame(self, bg=BG_DARK, padx=20, pady=12)
        header.pack(fill=tk.X)

        top_row = tk.Frame(header, bg=BG_DARK)
        top_row.pack(fill=tk.X)

        tk.Label(
            top_row,
            text="🧪 Kreator Diagnostyki i Mapowania Zwift Click",
            font=("Segoe UI", 12, "bold"),
            fg=TEXT_WHITE,
            bg=BG_DARK
        ).pack(side=tk.LEFT)

        lbl_badge = tk.Label(
            top_row,
            text="DIAGNOSTIC PRO",
            font=("Segoe UI", 8, "bold"),
            fg="#A5B4FC",
            bg="#1E1B4B",
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#4338CA",
            padx=7,
            pady=2
        )
        lbl_badge.pack(side=tk.LEFT, padx=10)

        # Connection status pill & connect button on right
        self.frame_conn_pill = tk.Frame(top_row, bg=BG_DARK)
        self.frame_conn_pill.pack(side=tk.RIGHT)

        self.btn_conn_now = tk.Button(
            self.frame_conn_pill,
            text="🔗 Połącz teraz",
            font=("Segoe UI", 8, "bold"),
            bg=ACCENT_EMERALD,
            fg=BG_DARK,
            activebackground="#059669",
            activeforeground=TEXT_WHITE,
            bd=0,
            padx=10,
            pady=3,
            cursor="hand2",
            command=self._connect_click
        )

        self.lbl_conn_status = tk.Label(
            self.frame_conn_pill,
            text="○ Brak połączenia BLE",
            font=("Segoe UI", 8, "bold"),
            fg="#FECDD3",
            bg="#881337",
            bd=0,
            highlightthickness=1,
            highlightbackground="#9F1239",
            padx=10,
            pady=3
        )
        self.lbl_conn_status.pack(side=tk.RIGHT)
        self._update_connection_indicator()

        tk.Label(
            header,
            text="Program kolejno poprosi Cię o kliknięcie poszczególnych przycisków w obu manetkach. Raport zostanie zapisany w pliku logu.",
            font=("Segoe UI", 8),
            fg=TEXT_MUTED,
            bg=BG_DARK
        ).pack(anchor="w", pady=(4, 0))

        # -------------------------------------------------------------------------
        # Step Progress Pills Rows (2 rows: Row 1 = Prawa manetka, Row 2 = Lewa manetka + Podsumowanie)
        # -------------------------------------------------------------------------
        self.frame_steps_nav = tk.Frame(self, bg=BG_DARK, padx=20, pady=4)
        self.frame_steps_nav.pack(fill=tk.X)

        self.step_pills = []

        # Row 1: Prawa manetka
        row1_frame = tk.Frame(self.frame_steps_nav, bg=BG_DARK)
        row1_frame.pack(fill=tk.X, pady=(0, 4))
        lbl_r_tag = tk.Label(
            row1_frame,
            text="PRAWA:",
            font=("Segoe UI", 8, "bold"),
            fg="#93C5FD",
            bg="#1E293B",
            padx=8,
            pady=3,
            bd=1,
            relief=tk.SOLID
        )
        lbl_r_tag.pack(side=tk.LEFT, padx=(0, 6))

        pills_row1 = [
            "1. Y",
            "2. A",
            "3. B",
            "4. Z",
            "5. PLUS (+)"
        ]
        for idx, ptitle in enumerate(pills_row1):
            f_pill = tk.Frame(
                row1_frame,
                bg="#0D1522",
                highlightthickness=1,
                highlightbackground="#1C2D44",
                padx=8,
                pady=3
            )
            f_pill.pack(side=tk.LEFT, padx=(0, 6), expand=True, fill=tk.X)
            lbl_p = tk.Label(f_pill, text=ptitle, font=("Segoe UI", 8, "bold"), fg="#64748B", bg="#0D1522")
            lbl_p.pack()
            self.step_pills.append((f_pill, lbl_p))

        # Row 2: Lewa manetka + Raport
        row2_frame = tk.Frame(self.frame_steps_nav, bg=BG_DARK)
        row2_frame.pack(fill=tk.X, pady=(0, 2))
        lbl_l_tag = tk.Label(
            row2_frame,
            text="LEWA:",
            font=("Segoe UI", 8, "bold"),
            fg="#F472B6",
            bg="#3B0764",
            padx=12,
            pady=3,
            bd=1,
            relief=tk.SOLID
        )
        lbl_l_tag.pack(side=tk.LEFT, padx=(0, 6))

        pills_row2 = [
            "6. GÓRA (▲)",
            "7. PRAWO (▶)",
            "8. LEWO (◀)",
            "9. DÓŁ (▼)",
            "10. MINUS (−)",
            "11. RAPORT 🏁"
        ]
        for idx, ptitle in enumerate(pills_row2):
            f_pill = tk.Frame(
                row2_frame,
                bg="#0D1522",
                highlightthickness=1,
                highlightbackground="#1C2D44",
                padx=8,
                pady=3
            )
            f_pill.pack(side=tk.LEFT, padx=(0, 6 if idx < len(pills_row2) - 1 else 0), expand=True, fill=tk.X)
            lbl_p = tk.Label(f_pill, text=ptitle, font=("Segoe UI", 8, "bold"), fg="#64748B", bg="#0D1522")
            lbl_p.pack()
            self.step_pills.append((f_pill, lbl_p))

        # -------------------------------------------------------------------------
        # Main Interactive Card
        # -------------------------------------------------------------------------
        self.card_main = tk.Frame(
            self,
            bg=BG_CARD,
            padx=20,
            pady=16,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR
        )
        self.card_main.pack(fill=tk.X, padx=20, pady=(8, 10))

        self.lbl_step_heading = tk.Label(
            self.card_main,
            text=f"KROK 1 Z {len(self.steps)}",
            font=("Segoe UI", 8, "bold"),
            fg=ACCENT_CYAN,
            bg=BG_CARD
        )
        self.lbl_step_heading.pack(anchor="w")

        self.lbl_step_title = tk.Label(
            self.card_main,
            text="Prawa manetka — Przycisk PLUS (+)",
            font=("Segoe UI", 13, "bold"),
            fg=TEXT_WHITE,
            bg=BG_CARD
        )
        self.lbl_step_title.pack(anchor="w", pady=(2, 4))

        self.lbl_step_desc = tk.Label(
            self.card_main,
            text="Weź do ręki PRAWĄ manetkę Zwift Click i kliknij fizyczny przycisk PLUS (+).",
            font=("Segoe UI", 9),
            fg="#E2E8F0",
            bg=BG_CARD,
            justify=tk.LEFT
        )
        self.lbl_step_desc.pack(anchor="w")

        self.lbl_step_hint = tk.Label(
            self.card_main,
            text="Podpowiedź: Domyślnie powinien podbijać bieg (Shift UP / y_up).",
            font=("Segoe UI", 8, "italic"),
            fg=TEXT_MUTED,
            bg=BG_CARD,
            justify=tk.LEFT
        )
        self.lbl_step_hint.pack(anchor="w", pady=(2, 10))

        # Detection Status Box (glowing box when detected)
        self.box_detect = tk.Frame(
            self.card_main,
            bg="#0B132B",
            padx=16,
            pady=12,
            highlightthickness=1,
            highlightbackground="#1E3A5F"
        )
        self.box_detect.pack(fill=tk.X, pady=(0, 10))

        self.lbl_detect_title = tk.Label(
            self.box_detect,
            text="⏳ Oczekiwanie na kliknięcie przycisku... (kliknij przycisk na manetce)",
            font=("Segoe UI", 10, "bold"),
            fg="#93C5FD",
            bg="#0B132B"
        )
        self.lbl_detect_title.pack(anchor="w")

        self.lbl_detect_details = tk.Label(
            self.box_detect,
            text="Status detektora BLE: nasłuchiwanie zdarzeń na żywo...",
            font=("Consolas", 8),
            fg=TEXT_MUTED,
            bg="#0B132B",
            justify=tk.LEFT
        )
        self.lbl_detect_details.pack(anchor="w", pady=(3, 0))

        # Buttons row inside central card
        self.frame_card_buttons = tk.Frame(self.card_main, bg=BG_CARD)
        self.frame_card_buttons.pack(fill=tk.X)

        self.btn_retry = tk.Button(
            self.frame_card_buttons,
            text="⟳ Powtórz ten krok",
            font=("Segoe UI", 8),
            bg="#1E293B",
            fg=TEXT_WHITE,
            activebackground="#334155",
            activeforeground=TEXT_WHITE,
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=self._do_retry_current_step
        )
        self.btn_retry.pack(side=tk.LEFT, padx=(0, 6))

        self.btn_skip = tk.Button(
            self.frame_card_buttons,
            text="⏭ Pomiń ten krok",
            font=("Segoe UI", 8),
            bg="#1E293B",
            fg="#94A3B8",
            activebackground="#334155",
            activeforeground=TEXT_WHITE,
            bd=0,
            padx=12,
            pady=4,
            cursor="hand2",
            command=self._do_skip_current_step
        )
        self.btn_skip.pack(side=tk.LEFT, padx=(0, 6))

        self.btn_next = tk.Button(
            self.frame_card_buttons,
            text="Dalej ➔",
            font=("Segoe UI", 8, "bold"),
            bg="#1E3A8A",
            fg=TEXT_WHITE,
            activebackground="#2563EB",
            activeforeground=TEXT_WHITE,
            bd=0,
            padx=14,
            pady=4,
            cursor="hand2",
            command=self._go_next_step
        )
        self.btn_next.pack(side=tk.RIGHT)

        # -------------------------------------------------------------------------
        # Live Sniffer and Raw BLE Traffic Frame
        # -------------------------------------------------------------------------
        frame_sniffer_wrap = tk.Frame(
            self,
            bg=BG_CARD,
            padx=16,
            pady=10,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR
        )
        frame_sniffer_wrap.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 10))

        sniff_top = tk.Frame(frame_sniffer_wrap, bg=BG_CARD)
        sniff_top.pack(fill=tk.X, pady=(0, 4))
        tk.Label(
            sniff_top,
            text="📡 Podgląd na żywo pakietów BLE i detektora zdarzeń (Sniffer):",
            font=("Segoe UI", 8, "bold"),
            fg=ACCENT_CYAN,
            bg=BG_CARD
        ).pack(side=tk.LEFT)

        tk.Button(
            sniff_top,
            text="Wyczyść podgląd",
            font=("Segoe UI", 7),
            bg="#1E293B",
            fg="#94A3B8",
            bd=0,
            padx=6,
            pady=1,
            cursor="hand2",
            command=lambda: self.txt_sniffer.delete("1.0", tk.END)
        ).pack(side=tk.RIGHT)

        sniff_box = tk.Frame(frame_sniffer_wrap, bg="#05080E")
        sniff_box.pack(fill=tk.BOTH, expand=True)

        self.txt_sniffer = tk.Text(
            sniff_box,
            bg="#05080E",
            fg="#94A3B8",
            font=("Consolas", 8),
            wrap=tk.WORD,
            bd=0,
            padx=8,
            pady=6,
            height=7
        )
        scroll_s = ttk.Scrollbar(sniff_box, orient="vertical", command=self.txt_sniffer.yview)
        self.txt_sniffer.configure(yscrollcommand=scroll_s.set)
        self.txt_sniffer.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll_s.pack(side=tk.RIGHT, fill=tk.Y)

        # -------------------------------------------------------------------------
        # Bottom Footer Action Bar
        # -------------------------------------------------------------------------
        footer = tk.Frame(self, bg=BG_DARK, padx=20, pady=8)
        footer.pack(fill=tk.X)

        self.lbl_toast = tk.Label(
            footer,
            text=f"💾 Zapis do pliku: {os.path.basename(self.log_filepath)}",
            font=("Segoe UI", 8),
            fg=TEXT_MUTED,
            bg=BG_DARK
        )
        self.lbl_toast.pack(side=tk.LEFT)

        tk.Button(
            footer,
            text="✖ Zamknij",
            font=("Segoe UI", 8),
            bg="#1E293B",
            fg=TEXT_WHITE,
            bd=0,
            padx=12,
            pady=5,
            cursor="hand2",
            command=self._on_close
        ).pack(side=tk.RIGHT, padx=(6, 0))

        tk.Button(
            footer,
            text="📁 Otwórz plik logu",
            font=("Segoe UI", 8),
            bg="#1E293B",
            fg="#93C5FD",
            bd=0,
            padx=12,
            pady=5,
            cursor="hand2",
            command=self._open_log_file
        ).pack(side=tk.RIGHT, padx=(6, 0))

        self.btn_copy_bottom = tk.Button(
            footer,
            text="📋 Kopiuj cały raport",
            font=("Segoe UI", 8, "bold"),
            bg=ACCENT_EMERALD,
            fg=BG_DARK,
            activebackground="#059669",
            activeforeground=TEXT_WHITE,
            bd=0,
            padx=14,
            pady=5,
            cursor="hand2",
            command=self._copy_report_to_clipboard
        )
        self.btn_copy_bottom.pack(side=tk.RIGHT)

    def _render_current_step(self):
        total = len(self.steps)
        for idx, (f_pill, lbl_p) in enumerate(self.step_pills):
            if idx == self.current_step_idx:
                f_pill.configure(bg="#0B2536", highlightbackground=ACCENT_CYAN)
                lbl_p.configure(fg=ACCENT_CYAN)
            elif idx < self.current_step_idx:
                res = self.results[idx] if idx < len(self.results) else None
                if res and res.get("skipped"):
                    f_pill.configure(bg="#1E293B", highlightbackground="#334155")
                    lbl_p.configure(fg="#94A3B8")
                else:
                    f_pill.configure(bg="#064E3B", highlightbackground=ACCENT_EMERALD)
                    lbl_p.configure(fg="#6EE7B7")
            else:
                f_pill.configure(bg="#0D1522", highlightbackground="#1C2D44")
                lbl_p.configure(fg="#64748B")

        if self.current_step_idx < total:
            step = self.steps[self.current_step_idx]
            self.lbl_step_heading.configure(text=f"KROK {self.current_step_idx + 1} Z {total} — {step['side'].upper()} MANETKA", fg=ACCENT_CYAN)
            self.lbl_step_title.configure(text=step["title"], fg=TEXT_WHITE)
            self.lbl_step_desc.configure(text=step["instruction"], fg="#E2E8F0")
            self.lbl_step_hint.configure(text=f"Podpowiedź: {step['hint']}", fg=TEXT_MUTED)

            existing_res = self.results[self.current_step_idx]
            if existing_res and not existing_res.get("skipped"):
                self.box_detect.configure(bg="#064E3B", highlightbackground=ACCENT_EMERALD)
                self.lbl_detect_title.configure(
                    text="✅ ZAREJESTROWANO KLIKNIĘCIE!",
                    fg=ACCENT_EMERALD,
                    bg="#064E3B"
                )
                details = (
                    f"Rola BLE: {existing_res['detected_role'].upper()}  •  Wykryty Button ID: {existing_res['detected_button']}  •  Pad: {existing_res['detected_pad']}\n"
                    f"Payload Hex: {existing_res.get('payload_hex') or existing_res.get('raw_hex') or 'N/A'}"
                )
                self.lbl_detect_details.configure(text=details, fg="#E2E8F0", bg="#064E3B")
            else:
                self.box_detect.configure(bg="#0B132B", highlightbackground="#1E3A5F")
                self.lbl_detect_title.configure(
                    text="⏳ Oczekiwanie na kliknięcie przycisku... (kliknij przycisk na manetce)",
                    fg="#93C5FD",
                    bg="#0B132B"
                )
                self.lbl_detect_details.configure(
                    text="Status detektora BLE: nasłuchiwanie zdarzeń na żywo...",
                    fg=TEXT_MUTED,
                    bg="#0B132B"
                )
            self.btn_next.configure(text="Dalej ➔")
        else:
            self._show_summary_view()

    def _show_summary_view(self):
        self.is_completed = True
        summary_pill_idx = len(self.steps)
        for idx, (f_pill, lbl_p) in enumerate(self.step_pills):
            if idx == summary_pill_idx:
                f_pill.configure(bg="#064E3B", highlightbackground=ACCENT_EMERALD)
                lbl_p.configure(fg="#6EE7B7")

        self.lbl_step_heading.configure(text="KALIBRACJA ZAKOŃCZONA", fg=ACCENT_EMERALD)
        self.lbl_step_title.configure(text="🎉 Podsumowanie i Raport Diagnostyczny Zwift Click", fg=TEXT_WHITE)
        self.lbl_step_desc.configure(
            text="Wszystkie 10 przycisków zostało przetestowanych. Pełny raport został zapisany do pliku zwift_click_diagnostic.log.\n"
                 "Kliknij przycisk '📋 KOPIUJ RAPORT DO SCHOWKA' i wklej go do czatu z asystentem.",
            fg="#E2E8F0"
        )
        self.lbl_step_hint.configure(
            text="Możesz teraz skopiować wynik i przesłać go w odpowiedzi.",
            fg=ACCENT_CYAN
        )

        summary_lines = []
        summary_lines.append("PRAWA MANETKA (Y, A, B, Z, +):")
        for i in range(min(5, len(self.steps))):
            st = self.steps[i]
            r = self.results[i]
            if r and r.get("skipped"):
                summary_lines.append(f"  • [{st['btn']}]: POMINIĘTO PRZEZ UŻYTKOWNIKA")
            elif r:
                summary_lines.append(
                    f"  • [{st['btn']}]: Button ID={r.get('detected_button')} | Rola BLE={r.get('detected_role')} | Pad={r.get('detected_pad')} | Hex={r.get('payload_hex') or r.get('raw_hex')}"
                )
            else:
                summary_lines.append(f"  • [{st['btn']}]: BRAK REAKCJI")

        summary_lines.append("\nLEWA MANETKA (GÓRA, PRAWO, LEWO, DÓŁ, −):")
        for i in range(5, len(self.steps)):
            st = self.steps[i]
            r = self.results[i]
            if r and r.get("skipped"):
                summary_lines.append(f"  • [{st['btn']}]: POMINIĘTO PRZEZ UŻYTKOWNIKA")
            elif r:
                summary_lines.append(
                    f"  • [{st['btn']}]: Button ID={r.get('detected_button')} | Rola BLE={r.get('detected_role')} | Pad={r.get('detected_pad')} | Hex={r.get('payload_hex') or r.get('raw_hex')}"
                )
            else:
                summary_lines.append(f"  • [{st['btn']}]: BRAK REAKCJI")

        self.box_detect.configure(bg="#064E3B", highlightbackground=ACCENT_EMERALD)
        self.lbl_detect_title.configure(text="✅ WYNIKI ZAREJESTROWANYCH PRZYCISKÓW (10 KROKÓW):", fg=ACCENT_EMERALD, bg="#064E3B")
        self.lbl_detect_details.configure(text="\n".join(summary_lines), fg="#FFFFFF", bg="#064E3B")

        self.btn_retry.configure(text="🔄 Rozpocznij od nowa", command=self._restart_wizard)
        self.btn_skip.pack_forget()
        self.btn_next.configure(
            text="📋 KOPIUJ RAPORT DO SCHOWKA",
            bg=ACCENT_EMERALD,
            fg=BG_DARK,
            command=self._copy_report_to_clipboard
        )
        self._save_full_report_to_file()

    def _do_retry_current_step(self):
        if self.auto_advance_job:
            try:
                self.after_cancel(self.auto_advance_job)
            except Exception:
                pass
            self.auto_advance_job = None
        if self.current_step_idx < len(self.steps):
            self.results[self.current_step_idx] = None
        self._render_current_step()

    def _do_skip_current_step(self):
        if self.auto_advance_job:
            try:
                self.after_cancel(self.auto_advance_job)
            except Exception:
                pass
            self.auto_advance_job = None
        if self.current_step_idx < len(self.steps):
            step = self.steps[self.current_step_idx]
            self.results[self.current_step_idx] = {
                "step_id": step["id"],
                "step_title": step["title"],
                "expected_role": step["role_expected"],
                "skipped": True,
                "time": time.strftime("%H:%M:%S")
            }
        self._save_full_report_to_file()
        self._go_next_step()

    def _go_next_step(self):
        if self.auto_advance_job:
            try:
                self.after_cancel(self.auto_advance_job)
            except Exception:
                pass
            self.auto_advance_job = None
        if self.current_step_idx < len(self.steps):
            self.current_step_idx += 1
        self._render_current_step()

    def _restart_wizard(self):
        if self.auto_advance_job:
            try:
                self.after_cancel(self.auto_advance_job)
            except Exception:
                pass
            self.auto_advance_job = None
        self.current_step_idx = 0
        self.results = [None] * len(self.steps)
        self.is_completed = False
        self.btn_retry.configure(text="⟳ Powtórz ten krok", command=self._do_retry_current_step)
        self.btn_skip.pack(side=tk.LEFT, padx=(0, 6))
        self.btn_next.configure(
            text="Dalej ➔",
            bg="#1E3A8A",
            fg=TEXT_WHITE,
            command=self._go_next_step
        )
        self._render_current_step()

    def _log_sniffer(self, line: str):
        try:
            self.txt_sniffer.insert(tk.END, line)
            self.txt_sniffer.see(tk.END)
        except Exception:
            pass

    def on_button_event(self, evt: Dict[str, Any]):
        pressed = evt.get("pressed", False)
        if not pressed:
            return

        role = evt.get("role", "")
        pad = evt.get("pad", "")
        button = evt.get("button", "")
        raw_hex = evt.get("raw_hex", "")
        payload_hex = evt.get("payload_hex", "")
        timestr = time.strftime("%H:%M:%S")

        line = f"[{timestr}] [BUTTON_CHANGE] Rola={role} | Pad={pad} | Przycisk={button} | Payload={payload_hex or raw_hex}\n"
        self._log_sniffer(line)

        if self.is_completed or self.current_step_idx >= len(self.steps):
            return

        step = self.steps[self.current_step_idx]
        res = {
            "step_id": step["id"],
            "step_title": step["title"],
            "expected_role": step["role_expected"],
            "detected_role": role,
            "detected_pad": pad,
            "detected_button": button,
            "pressed": True,
            "raw_hex": raw_hex,
            "payload_hex": payload_hex,
            "full_state": evt.get("full_state", {}),
            "time": timestr,
            "skipped": False
        }
        self.results[self.current_step_idx] = res

        # Update detection card UI
        self.box_detect.configure(bg="#064E3B", highlightbackground=ACCENT_EMERALD)
        self.lbl_detect_title.configure(
            text="✅ ZAREJESTROWANO KLIKNIĘCIE!",
            fg=ACCENT_EMERALD,
            bg="#064E3B"
        )
        details = (
            f"Otrzymana Rola BLE: {role.upper()}  •  Wykryty Przycisk: {button}  •  Pad Name: {pad}\n"
            f"Payload Hex: {payload_hex or raw_hex or 'N/A'}"
        )
        self.lbl_detect_details.configure(text=details, fg="#E2E8F0", bg="#064E3B")

        # Auto-save report to disk
        self._save_full_report_to_file()

        # Auto-advance after 1.3s
        if self.auto_advance_job:
            try:
                self.after_cancel(self.auto_advance_job)
            except Exception:
                pass
        self.auto_advance_job = self.after(1300, self._go_next_step)

    def on_packet_sniff(self, evt: Dict[str, Any]):
        role = evt.get("role", "")
        payload_hex = evt.get("payload_hex", "")
        parsed_type = evt.get("parsed_type", "")
        if parsed_type == "heartbeat":
            return

        timestr = time.strftime("%H:%M:%S")
        line = f"[{timestr}] [RX {role.upper()}] Payload: {payload_hex} (Typ: {parsed_type})\n"
        self._log_sniffer(line)

    def on_status_change(self, role: str, status_text: str, connected: bool):
        self._update_connection_indicator()

    def _update_connection_indicator(self):
        has_conn = (self.app.connected_left or self.app.connected_right)
        if has_conn:
            r_name = self.app.connected_device_names.get("right", "") or self.app.cfg.get("mac_right", "") or "Click (P)"
            l_name = self.app.connected_device_names.get("left", "") or self.app.cfg.get("mac_left", "") or "Click (L)"
            txt = f"● Połączono z Click ({r_name})"
            if self.app.connected_left and self.app.connected_right:
                txt = f"● Połączono (P: {r_name} | L: {l_name})"
            self.lbl_conn_status.configure(text=txt, fg=ACCENT_EMERALD, bg="#064E3B", highlightbackground="#059669")
            self.btn_conn_now.pack_forget()
        else:
            self.lbl_conn_status.configure(text="○ Brak połączenia BLE", fg="#FECDD3", bg="#881337", highlightbackground="#9F1239")
            self.btn_conn_now.pack(side=tk.RIGHT, padx=(6, 0))

    def _connect_click(self):
        self.app._on_connect_only()

    def _save_full_report_to_file(self) -> str:
        lines = []
        lines.append("=" * 80)
        lines.append("VELOBRIDGE PRO - RAPORT DIAGNOSTYCZNY PRZYCISKÓW ZWIFT CLICK")
        lines.append(f"Data i godzina testu: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Aplikacja: VeloBridge {APP_BADGE}")
        lines.append(f"Aktywny tryb w programie: {self.app.selected_hardware_model.upper()}")
        lines.append("-" * 80)
        lines.append("STATUS POŁĄCZENIA BLE:")
        lines.append(f"  Prawa manetka: Połączona={self.app.connected_right}, MAC={self.app.cfg.get('mac_right', '')}, Nazwa={self.app.connected_device_names.get('right', '')}, Bateria={self.app.battery_right}%")
        lines.append(f"  Lewa manetka:  Połączona={self.app.connected_left}, MAC={self.app.cfg.get('mac_left', '')}, Nazwa={self.app.connected_device_names.get('left', '')}, Bateria={self.app.battery_left}%")
        lines.append("=" * 80)
        lines.append("\nWYNIKI PROCEDURY KALIBRACJI / KLIKNIĘĆ KROK PO KROKU:\n")

        for i, step in enumerate(self.steps):
            res = self.results[i] if i < len(self.results) else None
            lines.append(f"[KROK {i+1}/{len(self.steps)}] {step['title']}")
            lines.append(f"  • Strona / Oczekiwana rola: {step['side'].upper()} ({step['role_expected']}) | Przycisk fizyczny: {step['btn']}")
            if res and res.get("skipped"):
                lines.append("  • Status: POMINIĘTO PRZEZ UŻYTKOWNIKA")
            elif res:
                lines.append("  • Status: ZAREJESTROWANO KLIKNIĘCIE")
                lines.append(f"  • Czas odebrania: {res.get('time', '')}")
                lines.append(f"  • Otrzymana rola BLE: {res.get('detected_role', '')}")
                lines.append(f"  • Pad Name: {res.get('detected_pad', '')}")
                lines.append(f"  • Wykryty Button ID: {res.get('detected_button', '')}")
                lines.append(f"  • Decrypted Payload Hex: {res.get('payload_hex', '')}")
                lines.append(f"  • Raw BLE Hex: {res.get('raw_hex', '')}")
                lines.append(f"  • Pełny stan zdarzenia: {res.get('full_state', {})}")
            else:
                lines.append("  • Status: BRAK REAKCJI (NIE WYKRYTO KLIKNIĘCIA)")
            lines.append("")

        lines.append("=" * 80)
        lines.append("HISTORIA PRZECHWYCONYCH PAKIETÓW BLE (SNIFFER LOG):")
        if hasattr(self, "txt_sniffer"):
            try:
                sniffer_content = self.txt_sniffer.get("1.0", tk.END).strip()
                lines.append(sniffer_content if sniffer_content else "(Brak pakietów w buforze sniffera)")
            except Exception:
                pass
        lines.append("=" * 80)
        lines.append("KONIEC RAPORTU DIAGNOSTYCZNEGO")

        report_text = "\n".join(lines)
        try:
            with open(self.log_filepath, "w", encoding="utf-8") as f:
                f.write(report_text)
        except Exception as e:
            print(f"[Diag Log Error] {e}")

        return report_text

    def _copy_report_to_clipboard(self):
        report_text = self._save_full_report_to_file()
        try:
            self.clipboard_clear()
            self.clipboard_append(report_text)
            self.update()
            self.lbl_toast.configure(
                text="✓ Skopiowano cały raport do schowka! Wklej go teraz w czacie.",
                fg=ACCENT_EMERALD
            )
            self.after(4000, lambda: self.lbl_toast.configure(
                text=f"💾 Zapisano w: {os.path.basename(self.log_filepath)}",
                fg=TEXT_MUTED
            ))
        except Exception as e:
            messagebox.showerror("Błąd schowka", f"Nie udało się skopiować: {e}", parent=self)

    def _open_log_file(self):
        self._save_full_report_to_file()
        try:
            if os.path.exists(self.log_filepath):
                if IS_MACOS:
                    import subprocess
                    subprocess.Popen(["open", self.log_filepath])
                else:
                    os.startfile(self.log_filepath)
            else:
                messagebox.showinfo("Brak pliku", "Plik logu nie został jeszcze utworzony.", parent=self)
        except Exception:
            try:
                import subprocess
                cmd = ["open", self.log_filepath] if IS_MACOS else ["notepad.exe", self.log_filepath]
                subprocess.Popen(cmd)
            except Exception as e:
                messagebox.showerror("Błąd", f"Nie udało się otworzyć pliku: {e}", parent=self)

    def _on_close(self):
        if self.auto_advance_job:
            try:
                self.after_cancel(self.auto_advance_job)
            except Exception:
                pass
        self._save_full_report_to_file()
        if getattr(self.app, "active_diagnostic_dialog", None) == self:
            self.app.active_diagnostic_dialog = None
        self.destroy()


class VeloBridgeApp:
    def __init__(self, root: tk.Tk):
        self.root = root

        # Check command-line arguments for debug mode ('dbg' or '--dbg')
        self.is_debug_mode: bool = any(
            arg.lower().strip("-/") in ("dbg", "debug") for arg in sys.argv[1:]
        )
        if self.is_debug_mode:
            print("[VeloBridge] *** TRYB DIAGNOSTYCZNY (DBG) AKTYWNY ***")

        app_title = f"VeloBridge Pro v{APP_VERSION} • Virtual Shifting dla MyWhoosh"
        if self.is_debug_mode:
            app_title = f"VeloBridge Pro v{APP_VERSION} [DEBUG] • Virtual Shifting dla MyWhoosh"
        self.root.title(app_title)
        self.root.geometry("1160x860")
        self.root.minsize(1040, 740)
        self.root.configure(bg=BG_DARK)
        apply_windows_dark_titlebar(self.root)
        register_custom_fonts()

        # Set dedicated Windows AppUserModelID for taskbar grouping & icon
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(f"velobridge.virtualshifting.cockpit.{APP_VERSION}")
        except Exception:
            pass

        # Set application icon for Windows titlebar & taskbar
        icon_path = get_asset_path("app_icon.ico")
        if os.path.exists(icon_path):
            try:
                self.root.iconbitmap(icon_path)
            except Exception:
                pass
        logo_path = get_asset_path("velobridge_logo.png")
        if not os.path.exists(logo_path):
            logo_path = get_asset_path("app_logo.png")
        if os.path.exists(logo_path) and PIL_AVAILABLE:
            try:
                self._app_window_icon = ImageTk.PhotoImage(file=logo_path)
                self.root.iconphoto(True, self._app_window_icon)
            except Exception:
                pass

        self.config_mgr = ConfigManager()
        self.cfg = self.config_mgr.data

        # Shifter engine
        self.shifter = VirtualShifter(
            min_gear=self.cfg.get("min_gear", 1),
            max_gear=self.cfg.get("max_gear", 30),
            initial_gear=self.cfg.get("initial_gear", 15)
        )
        self.shifter.sound_enabled = self.cfg.get("sound_enabled", True)
        self.shifter.auto_focus = self.cfg.get("auto_focus_mywhoosh", False)
        self.shifter.on_gear_change_callback = self._on_gear_changed

        # BLE Worker & Queue
        self.event_queue = queue.Queue()
        self.ble = BleWorker(self.event_queue)
        self.ble.start()

        self.mini_overlay: Optional[MiniOverlayWindow] = None
        self.connected_left = False
        self.connected_right = False
        self.battery_left = -1
        self.battery_right = -1
        self.scanned_devices: list = []
        self.discovered_device_names: Dict[str, str] = {}
        self.connected_device_names: Dict[str, str] = {"left": "", "right": ""}
        self.is_play_disabled: bool = False
        self.is_click_disabled: bool = False
        self.active_device_dialog = None
        self.logs_cache: list = []

        # Hardware Model & Active View for Controller Diagram
        hw_model = self.cfg.get("hardware_model", "")
        mode = self.cfg.get("device_mode", "")
        if hw_model == "click":
            self.selected_hardware_model = "click"
        elif hw_model == "play":
            self.selected_hardware_model = "play"
        elif "Click" in mode:
            self.selected_hardware_model = "click"
        elif "Play" in mode:
            self.selected_hardware_model = "play"
        else:
            self.selected_hardware_model = "click" if ("click" in self.cfg.get("model_right", "").lower()) else "play"

        if "Tylko Lewa" in mode:
            self.active_diagram_side = "left"
        elif "Tylko Prawa" in mode:
            self.active_diagram_side = "right"
        else:
            self.active_diagram_side = "both"

        # Widgets for callout frames and canvas shapes
        self.callout_widgets: Dict[str, Dict[str, Any]] = {}
        self.canvas_shape_ids: Dict[str, int] = {}
        self.button_hotspot_coords: Dict[str, Tuple[int, int]] = {}

        # Cached PhotoImage references to prevent garbage collection
        self._image_cache: Dict[Tuple[str, int], Any] = {}
        self._handlebar_photo = None
        self._handlebar_cache_key = None
        self.loaded_card_images = []
        self._last_diag_w = 0
        self._last_diag_h = 0
        self._resize_job = None
        self.active_diagnostic_dialog = None

        self._setup_styles()
        self._build_ui()
        self._update_selector_buttons_ui()
        self._update_connection_display()
        self._update_mywhoosh_tile()

        if IS_MACOS:
            if not check_macos_accessibility_permission(prompt=False):
                self._log_local(
                    "⚠️ macOS: Nadaj VeloBridge uprawnienia Dostępności (Ustawienia Systemowe -> Prywatność i ochrona -> Dostępność), aby przekazywać klawisze zmiany biegów do MyWhoosh."
                )
            self.root.after(1200, self._check_macos_accessibility_on_startup)

        # Start periodic queue polling
        self.root.after(30, self._process_events)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _check_macos_accessibility_on_startup(self):
        if not IS_MACOS:
            return
        if not check_macos_accessibility_permission(prompt=False):
            ans = messagebox.askyesno(
                "Wymagane uprawnienie macOS (Dostępność)",
                "Aby VeloBridge mógł przekazywać klawisze zmiany biegów (K / I) do gry MyWhoosh, system macOS wymaga włączenia uprawnienia Dostępności (Accessibility).\n\n"
                "KROKI:\n"
                "1. Kliknij 'Tak', aby otworzyć Ustawienia Systemowe.\n"
                "2. Włącz suwak obok 'VeloBridge'.\n\n"
                "⚠️ WAŻNA WSKAZÓWKA PO AKTUALIZACJI:\n"
                "Jeśli VeloBridge był już wcześniej na liście, wyłącz i włącz suwak ponownie (odświeża to zapamiętany podpis programu w macOS TCC).\n\n"
                "Czy chcesz otworzyć Ustawienia Systemowe teraz?",
                parent=self.root
            )
            if ans:
                check_macos_accessibility_permission(prompt=True)

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        # Combobox
        style.configure(
            "TCombobox",
            fieldbackground=BG_INPUT,
            background=BG_CARD,
            foreground=TEXT_WHITE,
            arrowcolor=ACCENT_CYAN,
            padding=5
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", BG_INPUT)],
            selectbackground=[("readonly", BG_CARD)],
            selectforeground=[("readonly", TEXT_WHITE)]
        )

        # Treeview
        style.configure(
            "Treeview",
            background="#0C131D",
            foreground=TEXT_WHITE,
            fieldbackground="#0C131D",
            borderwidth=0,
            rowheight=26,
            font=("Segoe UI", 9)
        )
        style.configure(
            "Treeview.Heading",
            background=BG_CARD_INNER,
            foreground=TEXT_WHITE,
            borderwidth=1,
            relief=tk.FLAT,
            font=("Segoe UI", 9, "bold")
        )
        style.map(
            "Treeview",
            background=[("selected", "#0284C7")],
            foreground=[("selected", "#FFFFFF")]
        )

    def _build_ui(self):
        # 1. Top Header Bar
        self._build_header()

        # 2. Main Body Container
        main_body = tk.Frame(self.root, bg=BG_DARK)
        main_body.pack(fill=tk.BOTH, expand=True, padx=18, pady=(8, 10))

        # 2a. Upper Panoramic Telemetry Row (Cards 1, 2, 3 across the screen)
        self.telemetry_row = tk.Frame(main_body, bg=BG_DARK)
        self.telemetry_row.pack(fill=tk.X, pady=(0, 8))

        self.telemetry_row.columnconfigure(0, weight=4, uniform="telemetry")
        self.telemetry_row.columnconfigure(1, weight=5, uniform="telemetry")
        self.telemetry_row.columnconfigure(2, weight=3, uniform="telemetry")

        self._build_card_connection(self.telemetry_row)
        self._build_card_virtual_shifter(self.telemetry_row)
        self._build_card_options_monitor(self.telemetry_row)

        # 2b. Lower Main Arena: Visualization & Controller Mapping Bay (Rider's POV)
        self.arena_row = tk.Frame(main_body, bg=BG_DARK)
        self.arena_row.pack(fill=tk.BOTH, expand=True, pady=(0, 8))

        self._build_arena_card(self.arena_row)

        # 3. Bottom Information Cards
        self._build_bottom_cards()

    def _build_header(self):
        header = tk.Frame(self.root, bg=BG_PANEL, padx=18, pady=8, highlightthickness=1, highlightbackground=BORDER_COLOR)
        header.pack(fill=tk.X)

        # Brand on left (Logo + Title/Badge + Subtitle directly underneath)
        brand_frame = tk.Frame(header, bg=BG_PANEL)
        brand_frame.pack(side=tk.LEFT)

        self._header_logo_img = None
        logo_path = get_asset_path("velobridge_logo.png")
        if not os.path.exists(logo_path):
            logo_path = get_asset_path("brand_cockpit_logo.png")
        if not os.path.exists(logo_path):
            logo_path = get_asset_path("app_logo.png")
        if PIL_AVAILABLE and os.path.exists(logo_path):
            try:
                raw_logo = Image.open(logo_path).convert("RGBA")
                raw_logo = raw_logo.resize((38, 38), Image.Resampling.LANCZOS)
                self._header_logo_img = ImageTk.PhotoImage(raw_logo)
            except Exception:
                self._header_logo_img = None

        if self._header_logo_img:
            lbl_logo = tk.Label(
                brand_frame,
                image=self._header_logo_img,
                bg=BG_PANEL
            )
            lbl_logo.pack(side=tk.LEFT, padx=(0, 10))
        else:
            lbl_logo = tk.Label(
                brand_frame,
                text="⚡",
                font=("Segoe UI", 18, "bold"),
                fg=ACCENT_EMERALD,
                bg=BG_PANEL
            )
            lbl_logo.pack(side=tk.LEFT, padx=(0, 8))

        brand_text_box = tk.Frame(brand_frame, bg=BG_PANEL)
        brand_text_box.pack(side=tk.LEFT)

        top_title_row = tk.Frame(brand_text_box, bg=BG_PANEL)
        top_title_row.pack(anchor="w")

        lbl_title = tk.Label(
            top_title_row,
            text="VeloBridge",
            font=("Chakra Petch", 16, "bold"),
            fg=TEXT_WHITE,
            bg=BG_PANEL
        )
        lbl_title.pack(side=tk.LEFT)

        badge_text = APP_BADGE
        lbl_badge = tk.Label(
            top_title_row,
            text=badge_text,
            font=("Segoe UI", 8, "bold"),
            fg=ACCENT_CYAN,
            bg="#0B2536",
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#164E63",
            padx=7,
            pady=1
        )
        lbl_badge.pack(side=tk.LEFT, padx=(8, 0))

        lbl_sub = tk.Label(
            brand_text_box,
            text="Virtual Shifting Cockpit dla MyWhoosh • DirectInput 60Hz",
            font=("Segoe UI", 8),
            fg=TEXT_MUTED,
            bg=BG_PANEL
        )
        lbl_sub.pack(anchor="w", pady=(1, 0))

        # Action Buttons group on right (single row)
        actions_bar = tk.Frame(header, bg=BG_PANEL)
        actions_bar.pack(side=tk.RIGHT)

        # 1. Main Action Button: Launch MyWhoosh
        if PIL_AVAILABLE:
            self.btn_action_launch = GradientPillButton(
                actions_bar,
                text="Połącz i Uruchom MyWhoosh",
                command=self._on_connect_and_launch,
                width=225,
                height=36,
                icon="lightning",
                font_size=9
            )
            self.btn_action_launch.pack(side=tk.LEFT, padx=(0, 6))
        else:
            self.btn_action_launch = tk.Button(
                actions_bar,
                text="⚡ Połącz i Uruchom MyWhoosh",
                font=("Segoe UI", 9, "bold"),
                bg="#059669",
                fg=BG_DARK,
                activebackground="#10B981",
                activeforeground=BG_DARK,
                bd=0,
                padx=14,
                pady=6,
                cursor="hand2",
                command=self._on_connect_and_launch
            )
            self.btn_action_launch.pack(side=tk.LEFT, padx=(0, 6))

        # 2. Help Button
        self.btn_help = tk.Button(
            actions_bar,
            text="❓ Pomoc",
            font=("Segoe UI", 9, "bold"),
            bg="#131D2B",
            fg="#93C5FD",
            activebackground="#1C2B3F",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#1E3A5F",
            padx=12,
            pady=5,
            cursor="hand2",
            command=self._open_help_dialog
        )
        self.btn_help.bind("<Enter>", lambda e: self.btn_help.configure(bg="#1E2F46", fg="#FFFFFF"))
        self.btn_help.bind("<Leave>", lambda e: self.btn_help.configure(bg="#131D2B", fg="#93C5FD"))
        self.btn_help.pack(side=tk.LEFT, padx=4)

        # 3. Diagnostic Wizard Button for Zwift Click (only packed in debug mode)
        self.btn_diag_click = tk.Button(
            actions_bar,
            text="🧪 Diagnostyka Click",
            font=("Segoe UI", 9, "bold"),
            bg="#1E1B4B",
            fg="#A5B4FC",
            activebackground="#312E81",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#4338CA",
            padx=11,
            pady=5,
            cursor="hand2",
            command=self._open_click_diagnostic
        )
        self.btn_diag_click.bind("<Enter>", lambda e: self.btn_diag_click.configure(bg="#2E1065", fg="#C4B5FD"))
        self.btn_diag_click.bind("<Leave>", lambda e: self.btn_diag_click.configure(bg="#1E1B4B", fg="#A5B4FC"))
        if self.is_debug_mode:
            self.btn_diag_click.pack(side=tk.LEFT, padx=4)

        # 4. Vertical 1px divider
        tk.Frame(actions_bar, width=1, height=22, bg="#1E293B").pack(side=tk.LEFT, padx=6)

        # 5. Connect Only Button
        self.btn_action_connect_only = tk.Button(
            actions_bar,
            text="🔗 Tylko połącz",
            font=("Segoe UI", 9, "bold"),
            bg="#131D2B",
            fg="#CBD5E1",
            activebackground="#1C293D",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#223348",
            padx=12,
            pady=5,
            cursor="hand2",
            command=self._on_connect_only
        )
        self.btn_action_connect_only.bind("<Enter>", lambda e: self.btn_action_connect_only.configure(bg="#1C2B3F", fg="#FFFFFF"))
        self.btn_action_connect_only.bind("<Leave>", lambda e: self.btn_action_connect_only.configure(bg="#131D2B", fg="#CBD5E1"))
        self.btn_action_connect_only.pack(side=tk.LEFT, padx=4)

        # 6. Disconnect Button
        self.btn_action_stop = tk.Button(
            actions_bar,
            text="⏹ Rozłącz",
            font=("Segoe UI", 9, "bold"),
            bg="#280D15",
            fg="#FECDD3",
            activebackground="#3D1220",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#5A1525",
            padx=12,
            pady=5,
            cursor="hand2",
            command=self._on_disconnect_all
        )
        self.btn_action_stop.bind("<Enter>", lambda e: self.btn_action_stop.configure(bg="#3D1220", fg="#FFFFFF"))
        self.btn_action_stop.bind("<Leave>", lambda e: self.btn_action_stop.configure(bg="#280D15", fg="#FECDD3"))
        self.btn_action_stop.pack(side=tk.LEFT, padx=4)

        # 7. Status Indicator Pill (○ MOST ROZŁĄCZONY)
        self.lbl_master_pill = tk.Label(
            actions_bar,
            text="○ MOST ROZŁĄCZONY",
            font=("Segoe UI", 8, "bold"),
            fg="#94A3B8",
            bg="#111B28",
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#1E2F46",
            padx=10,
            pady=5
        )
        self.lbl_master_pill.pack(side=tk.LEFT, padx=(4, 0))

    def _build_card_connection(self, parent):
        self.card_conn = ModernCard(parent, height=265, bg_parent=BG_DARK, radius=12, pad_x=14, pad_y=12)
        self.card_conn.grid(row=0, column=0, sticky="nsew", padx=(0, 5))

        top_conn = tk.Frame(self.card_conn.inner, bg=BG_CARD)
        top_conn.pack(fill=tk.X, pady=(0, 2))

        f_left_hdr = tk.Frame(top_conn, bg=BG_CARD)
        f_left_hdr.pack(side=tk.LEFT)

        lbl_c1_title = tk.Label(
            f_left_hdr,
            text="STAN POŁĄCZENIA",
            font=("Chakra Petch", 9, "bold"),
            fg=ACCENT_CYAN,
            bg=BG_CARD
        )
        lbl_c1_title.pack(side=tk.LEFT)

        lbl_c1_badge = tk.Label(
            f_left_hdr,
            text="BLE 5.0",
            font=("Consolas", 8),
            fg="#64748B",
            bg=BG_CARD,
            padx=4,
            pady=0
        )
        lbl_c1_badge.pack(side=tk.LEFT, padx=(6, 0))

        # Gear configuration button in top right of Connection card
        self.btn_gear_config = tk.Button(
            top_conn,
            text="⚙",
            font=("Segoe UI", 9, "bold"),
            bg="#132338",
            fg="#94A3B8",
            activebackground="#1E3858",
            activeforeground="#FFFFFF",
            bd=0,
            highlightthickness=1,
            highlightbackground="#23456D",
            padx=6,
            pady=1,
            cursor="hand2",
            command=self._open_device_manager
        )
        self.btn_gear_config.pack(side=tk.RIGHT)

        # Subtle separator line
        tk.Frame(self.card_conn.inner, height=1, bg="#162234").pack(fill=tk.X, pady=(4, 6))

        # Item Left
        self.frame_conn_left = tk.Frame(self.card_conn.inner, bg="#080D15", padx=10, pady=5, highlightthickness=1, highlightbackground=BORDER_TILE)
        self.frame_conn_left.pack(fill=tk.X, pady=2)
        self.dot_left = tk.Label(self.frame_conn_left, text="○", font=("Segoe UI", 11), fg=TEXT_DIM, bg="#080D15")
        self.dot_left.pack(side=tk.LEFT, padx=(0, 8))

        box_l = tk.Frame(self.frame_conn_left, bg="#080D15")
        box_l.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.lbl_title_left = tk.Label(box_l, text="Zwift (Lewa manetka)", font=("Segoe UI", 8, "bold"), fg=TEXT_WHITE, bg="#080D15")
        self.lbl_title_left.pack(anchor="w")
        self.lbl_desc_left = tk.Label(box_l, text="Rozłączono — naciśnij przycisk", font=("Segoe UI", 7), fg="#64748B", bg="#080D15")
        self.lbl_desc_left.pack(anchor="w")

        self.lbl_bat_left = tk.Label(
            self.frame_conn_left,
            text="🔋 --%",
            font=("Consolas", 8, "bold"),
            fg="#64748B",
            bg="#0E1724",
            bd=0,
            highlightthickness=1,
            highlightbackground="#1C2D44",
            padx=8,
            pady=2,
            width=6
        )
        self.lbl_bat_left.pack(side=tk.RIGHT)

        # Item Right
        self.frame_conn_right = tk.Frame(self.card_conn.inner, bg="#080D15", padx=10, pady=5, highlightthickness=1, highlightbackground=BORDER_TILE)
        self.frame_conn_right.pack(fill=tk.X, pady=2)
        self.dot_right = tk.Label(self.frame_conn_right, text="○", font=("Segoe UI", 11), fg=TEXT_DIM, bg="#080D15")
        self.dot_right.pack(side=tk.LEFT, padx=(0, 8))

        box_r = tk.Frame(self.frame_conn_right, bg="#080D15")
        box_r.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.lbl_title_right = tk.Label(box_r, text="Zwift (Prawa manetka)", font=("Segoe UI", 8, "bold"), fg=TEXT_WHITE, bg="#080D15")
        self.lbl_title_right.pack(anchor="w")
        self.lbl_desc_right = tk.Label(box_r, text="Rozłączono — naciśnij przycisk", font=("Segoe UI", 7), fg="#64748B", bg="#080D15")
        self.lbl_desc_right.pack(anchor="w")

        self.lbl_bat_right = tk.Label(
            self.frame_conn_right,
            text="🔋 --%",
            font=("Consolas", 8, "bold"),
            fg="#64748B",
            bg="#0E1724",
            bd=0,
            highlightthickness=1,
            highlightbackground="#1C2D44",
            padx=8,
            pady=2,
            width=6
        )
        self.lbl_bat_right.pack(side=tk.RIGHT)

        # Item MyWhoosh
        f_myw = tk.Frame(self.card_conn.inner, bg="#080D15", padx=10, pady=5, highlightthickness=1, highlightbackground=BORDER_TILE)
        f_myw.pack(fill=tk.X, pady=2)
        self.dot_mywhoosh = tk.Label(f_myw, text="●", font=("Segoe UI", 11), fg=ACCENT_CYAN, bg="#080D15")
        self.dot_mywhoosh.pack(side=tk.LEFT, padx=(0, 8))

        box_m = tk.Frame(f_myw, bg="#080D15")
        box_m.pack(side=tk.LEFT, fill=tk.X, expand=True)
        tk.Label(box_m, text="MyWhoosh (Gra)", font=("Segoe UI", 8, "bold"), fg=TEXT_WHITE, bg="#080D15").pack(anchor="w")
        self.lbl_desc_mywhoosh = tk.Label(box_m, text="Wykryto i aktywne • DirectInput", font=("Segoe UI", 7), fg=ACCENT_CYAN, bg="#080D15")
        self.lbl_desc_mywhoosh.pack(anchor="w")

        btn_mywhoosh_path = tk.Button(
            f_myw,
            text="📁 Ścieżka gry",
            font=("Segoe UI", 7, "bold"),
            bg="#0B2536",
            fg=ACCENT_CYAN,
            activebackground="#164E63",
            activeforeground=TEXT_WHITE,
            bd=1,
            relief=tk.SOLID,
            highlightbackground="#0284C7",
            padx=7,
            pady=1,
            cursor="hand2",
            command=self._open_mywhoosh_path_dialog
        )
        btn_mywhoosh_path.pack(side=tk.RIGHT, padx=(4, 0))

        btn_ble_scanner_link = tk.Button(
            f_myw,
            text="Skaner BLE",
            font=("Segoe UI", 7, "underline"),
            fg="#94A3B8",
            bg="#080D15",
            activebackground="#080D15",
            activeforeground="#FFFFFF",
            bd=0,
            cursor="hand2",
            command=self._open_device_manager
        )
        btn_ble_scanner_link.pack(side=tk.RIGHT)

        if self.is_debug_mode:
            btn_diag_link = tk.Button(
                f_myw,
                text="🧪 Diagnostyka",
                font=("Segoe UI", 7, "underline"),
                fg="#A5B4FC",
                bg="#080D15",
                activebackground="#080D15",
                activeforeground="#FFFFFF",
                bd=0,
                cursor="hand2",
                command=self._open_click_diagnostic
            )
            btn_diag_link.pack(side=tk.RIGHT, padx=(0, 6))

        # Footer inside Card 1 (always visible, not clipped)
        tk.Frame(self.card_conn.inner, height=1, bg="#162234").pack(fill=tk.X, pady=(8, 6))

        f_footer = tk.Frame(self.card_conn.inner, bg=BG_CARD)
        f_footer.pack(fill=tk.X)

        f_enc = tk.Frame(f_footer, bg=BG_CARD)
        f_enc.pack(side=tk.LEFT)
        tk.Label(f_enc, text="Szyfrowanie: ", font=("Segoe UI", 7), fg="#64748B", bg=BG_CARD).pack(side=tk.LEFT)
        tk.Label(f_enc, text="ECDH/AES-CCM", font=("Segoe UI", 7, "bold"), fg="#E2E8F0", bg=BG_CARD).pack(side=tk.LEFT)

        btn_swap = tk.Button(
            f_footer,
            text="⇄ Zamień L ↔ P",
            font=("Segoe UI", 8, "bold"),
            bg=BG_CARD,
            fg=ACCENT_CYAN,
            activebackground=BG_CARD,
            activeforeground="#38BDF8",
            bd=0,
            cursor="hand2",
            command=self._swap_controllers
        )
        btn_swap.pack(side=tk.RIGHT)

    def _swap_controllers(self):
        """Swaps MAC addresses assigned to left and right controllers."""
        l = self.cfg.get("mac_left", "").strip()
        r = self.cfg.get("mac_right", "").strip()
        self.cfg["mac_left"] = r
        self.cfg["mac_right"] = l
        self.config_mgr.save()
        self._update_connection_display()
        self._log_local("Zamieniono przypisanie manetek: Lewa ⮂ Prawa")
        messagebox.showinfo(
            "Zamiana manetek (L ↔ P)",
            f"Pomyślnie zamieniono adresy MAC manetek!\n\n"
            f"👈 Lewa manetka: {r if r else '(Brak)'}\n"
            f"👉 Prawa manetka: {l if l else '(Brak)'}\n\n"
            "Wskazówka: Jeśli manetki były połączone, kliknij 'Rozłącz' i połącz ponownie.",
            parent=self.root
        )

    def _build_card_virtual_shifter(self, parent):
        self.card_shift = ModernCard(parent, height=265, bg_parent=BG_DARK, radius=12, pad_x=14, pad_y=12)
        self.card_shift.grid(row=0, column=1, sticky="nsew", padx=3)

        top_bar = tk.Frame(self.card_shift.inner, bg=BG_CARD)
        top_bar.pack(fill=tk.X, pady=(0, 2))

        lbl_hud_title = tk.Label(
            top_bar,
            text="PRZEŁOŻENIE WIRTUALNE (MYSHIFT)",
            font=("Chakra Petch", 9, "bold"),
            fg=ACCENT_EMERALD,
            bg=BG_CARD
        )
        lbl_hud_title.pack(side=tk.LEFT)

        lbl_gear_badge = tk.Label(
            top_bar,
            text="30 Biegów • Krok ±1",
            font=("Segoe UI", 8),
            fg=TEXT_MUTED,
            bg=BG_CARD
        )
        lbl_gear_badge.pack(side=tk.RIGHT)

        # Subtle separator line
        tk.Frame(self.card_shift.inner, height=1, bg="#162234").pack(fill=tk.X, pady=(4, 6))

        # Futuristic Cockpit Gear Telemetry Widget (large, glowing 64pt font, tall LED cassette)
        self.gear_hud_widget = FuturisticGearWidget(
            self.card_shift.inner,
            current_gear=self.shifter.current_gear,
            max_gear=self.shifter.max_gear,
            height=120,
            bg=BG_CARD
        )
        self.gear_hud_widget.pack(fill=tk.X, pady=(0, 4))

        # Bottom separator line
        tk.Frame(self.card_shift.inner, height=1, bg="#162234").pack(fill=tk.X, pady=(4, 6))

        # Shift buttons row (3 pill buttons matching mockup)
        shift_btn_row = tk.Frame(self.card_shift.inner, bg=BG_CARD)
        shift_btn_row.pack(fill=tk.X)

        tk.Button(
            shift_btn_row,
            text="▼ -1 [Klawisz I]",
            font=("Segoe UI", 8, "bold"),
            bg="#2A0B14",
            fg="#FDA4AF",
            activebackground="#4C0519",
            activeforeground=TEXT_WHITE,
            bd=0,
            highlightthickness=1,
            highlightbackground="#7A152E",
            padx=10,
            pady=5,
            cursor="hand2",
            command=lambda: self.shifter.shift_down(1)
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 3))

        tk.Button(
            shift_btn_row,
            text="↺ Reset (15)",
            font=("Segoe UI", 8, "bold"),
            bg="#131D2B",
            fg="#94A3B8",
            activebackground="#1E2B3E",
            activeforeground=TEXT_WHITE,
            bd=0,
            highlightthickness=1,
            highlightbackground="#1E2B3E",
            padx=8,
            pady=5,
            cursor="hand2",
            command=lambda: self.shifter.reset_gear(15)
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)

        tk.Button(
            shift_btn_row,
            text="▲ +1 [Klawisz K]",
            font=("Segoe UI", 8, "bold"),
            bg="#063324",
            fg="#6EE7B7",
            activebackground="#064E3B",
            activeforeground=TEXT_WHITE,
            bd=0,
            highlightthickness=1,
            highlightbackground="#065F46",
            padx=10,
            pady=5,
            cursor="hand2",
            command=lambda: self.shifter.shift_up(1)
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(3, 0))

    def _build_card_options_monitor(self, parent):
        self.card_opts = ModernCard(parent, height=265, bg_parent=BG_DARK, radius=12, pad_x=14, pad_y=12)
        self.card_opts.grid(row=0, column=2, sticky="nsew", padx=(5, 0))

        top_bar = tk.Frame(self.card_opts.inner, bg=BG_CARD)
        top_bar.pack(fill=tk.X, pady=(0, 2))

        lbl_opts_title = tk.Label(
            top_bar,
            text="OPCJE & LIVE MONITOR",
            font=("Chakra Petch", 9, "bold"),
            fg=ACCENT_AMBER,
            bg=BG_CARD
        )
        lbl_opts_title.pack(side=tk.LEFT)

        f_lat = tk.Frame(top_bar, bg=BG_CARD)
        f_lat.pack(side=tk.RIGHT)
        tk.Label(f_lat, text="●", font=("Segoe UI", 7), fg=ACCENT_EMERALD, bg=BG_CARD).pack(side=tk.LEFT, padx=(0, 2))
        tk.Label(f_lat, text="< 2ms", font=("Segoe UI", 8, "bold"), fg=ACCENT_EMERALD, bg=BG_CARD).pack(side=tk.LEFT)

        # Subtle separator line
        tk.Frame(self.card_opts.inner, height=1, bg="#162234").pack(fill=tk.X, pady=(4, 6))

        # Real-time last action well (3 lines matching mockup)
        well = tk.Frame(self.card_opts.inner, bg="#070D16", padx=8, pady=5, highlightthickness=1, highlightbackground=BORDER_TILE)
        well.pack(fill=tk.X, pady=(0, 4))

        lbl_well_hdr = tk.Label(
            well,
            text="OSTATNIA AKCJA (REAL-TIME):",
            font=("Segoe UI", 7, "bold"),
            fg="#64748B",
            bg="#070D16"
        )
        lbl_well_hdr.pack(anchor="w")

        self.lbl_last_action = tk.Label(
            well,
            text="🟢 [PRAWA +] → Bieg W GÓRĘ (+1)",
            font=("Segoe UI", 8, "bold"),
            fg="#34D399",
            bg="#070D16",
            anchor="w",
            justify=tk.LEFT,
            wraplength=270
        )
        self.lbl_last_action.pack(anchor="w", fill=tk.X)

        self.lbl_last_action_sub = tk.Label(
            well,
            text="Godzina: 19:15:30 • Hardware Scancode 0x25",
            font=("Segoe UI", 7),
            fg="#64748B",
            bg="#070D16",
            anchor="w"
        )
        self.lbl_last_action_sub.pack(anchor="w")

        # Toggles using modern toggle tiles (no Windows checkbox artifact, no tofu)
        self.var_sound = tk.BooleanVar(value=self.cfg.get("sound_enabled", True))
        self.toggle_sound = ModernToggleTile(
            self.card_opts.inner,
            text="Dźwięk kliku manetki",
            variable=self.var_sound,
            icon_type="sound",
            command=self._on_options_changed
        )
        self.toggle_sound.pack(fill=tk.X, pady=2)

        self.var_haptic = tk.BooleanVar(value=self.cfg.get("haptic_enabled", True))
        self.toggle_haptic = ModernToggleTile(
            self.card_opts.inner,
            text="Wibracja haptic feedback",
            variable=self.var_haptic,
            icon_type="haptic",
            command=self._on_options_changed
        )
        self.toggle_haptic.pack(fill=tk.X, pady=2)

        # Bottom button row: Full-width HUD button matching mockup
        f_btn_hud = tk.Frame(self.card_opts.inner, bg=BG_CARD)
        f_btn_hud.pack(fill=tk.X, pady=(6, 0))

        btn_hud = tk.Button(
            f_btn_hud,
            text="🗔 Otwórz pływający HUD do gry",
            font=("Segoe UI", 8, "bold"),
            bg="#081E2E",
            fg=ACCENT_CYAN,
            activebackground="#0F3854",
            activeforeground=TEXT_WHITE,
            bd=0,
            highlightthickness=1,
            highlightbackground=ACCENT_CYAN,
            padx=6,
            pady=5,
            cursor="hand2",
            command=self._toggle_mini_overlay
        )
        btn_hud.pack(fill=tk.X)

    def _build_arena_card(self, parent):
        self.card_config = ModernCard(parent, bg_parent=BG_DARK, radius=12, pad_x=14, pad_y=10)
        self.card_config.pack(fill=tk.BOTH, expand=True)

        # Top Bar of Arena Card
        top_bar = tk.Frame(self.card_config.inner, bg=BG_CARD)
        top_bar.pack(fill=tk.X, pady=(0, 4))

        # Title & Subtitle on left
        title_box = tk.Frame(top_bar, bg=BG_CARD)
        title_box.pack(side=tk.LEFT)

        tk.Label(
            title_box,
            text="🎮 WIZUALIZACJA I MAPOWANIE MANETEK",
            font=("Chakra Petch", 11, "bold"),
            fg=TEXT_WHITE,
            bg=BG_CARD
        ).pack(anchor="w")

        tk.Label(
            title_box,
            text="Perspektywa rowerzysty (widok z siodełka od strony mostka) • Wybierz model i stronę",
            font=("Segoe UI", 8),
            fg=TEXT_MUTED,
            bg=BG_CARD
        ).pack(anchor="w")

        # Selectors on right
        selectors_frame = tk.Frame(top_bar, bg=BG_CARD)
        selectors_frame.pack(side=tk.RIGHT)

        # Tier 1: Hardware Model Selector
        f_model = tk.Frame(selectors_frame, bg="#080D16", padx=2, pady=2, highlightthickness=1, highlightbackground=BORDER_TILE)
        f_model.pack(side=tk.LEFT, padx=(0, 8))

        self.btn_model_click = tk.Button(
            f_model,
            text="🔘 Zwift Click",
            font=("Segoe UI", 9, "bold"),
            bd=0,
            padx=10,
            pady=3,
            cursor="hand2",
            command=lambda: self._select_hardware_model("click")
        )
        self.btn_model_click.pack(side=tk.LEFT, padx=1)

        self.btn_model_play = tk.Button(
            f_model,
            text="🎮 Zwift Play",
            font=("Segoe UI", 9),
            bd=0,
            padx=10,
            pady=3,
            cursor="hand2",
            command=lambda: self._select_hardware_model("play")
        )
        self.btn_model_play.pack(side=tk.LEFT, padx=1)

        # Tier 2: Side Sub-Selector
        f_side = tk.Frame(selectors_frame, bg="#080D16", padx=2, pady=2, highlightthickness=1, highlightbackground=BORDER_TILE)
        f_side.pack(side=tk.LEFT)

        self.btn_pill_both = tk.Button(
            f_side,
            text="Zestaw (L + P)",
            font=("Segoe UI", 9, "bold"),
            bd=0,
            padx=10,
            pady=3,
            cursor="hand2",
            command=lambda: self._select_diagram_side("both")
        )
        self.btn_pill_both.pack(side=tk.LEFT, padx=1)

        self.btn_pill_left = tk.Button(
            f_side,
            text="👈 Tylko Lewa",
            font=("Segoe UI", 9),
            bd=0,
            padx=10,
            pady=3,
            cursor="hand2",
            command=lambda: self._select_diagram_side("left")
        )
        self.btn_pill_left.pack(side=tk.LEFT, padx=1)

        self.btn_pill_right = tk.Button(
            f_side,
            text="👉 Tylko Prawa",
            font=("Segoe UI", 9),
            bd=0,
            padx=10,
            pady=3,
            cursor="hand2",
            command=lambda: self._select_diagram_side("right")
        )
        self.btn_pill_right.pack(side=tk.LEFT, padx=1)

        # Hidden combobox for seamless backwards compatibility
        self.combo_device_type = ttk.Combobox(
            self.card_config.inner,
            values=[
                "Zestaw Zwift Click (Lewa + Prawa)",
                "Zwift Click (Tylko Prawa: + / Y,Z,B,A)",
                "Zwift Click (Tylko Lewa: - / D-Pad)",
                "Zestaw Zwift Play (Lewa + Prawa)",
                "Zwift Play (Tylko Prawa)",
                "Zwift Play (Tylko Lewa)"
            ],
            state="readonly"
        )
        self.combo_device_type.set(self.cfg.get("device_mode", "Zestaw Zwift Click (Lewa + Prawa)"))

        # Hint text
        lbl_hint = tk.Label(
            self.card_config.inner,
            text="💡 Kliknij dowolny przycisk na wizualizacji, aby zmienić przypisany klawisz gry MyWhoosh.",
            font=("Segoe UI", 8),
            fg=TEXT_MUTED,
            bg=BG_CARD
        )
        lbl_hint.pack(pady=(2, 4))

        # Canvas for Interactive Controller Diagram
        self.canvas_diag = tk.Canvas(
            self.card_config.inner,
            bg="#070B11",
            bd=0,
            highlightthickness=1,
            highlightbackground=BORDER_COLOR
        )
        self.canvas_diag.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        self.canvas_diag.bind("<Configure>", self._on_canvas_configure)

        # Summary footer line in right card
        f_foot = tk.Frame(self.card_config.inner, bg=BG_CARD)
        f_foot.pack(fill=tk.X, pady=(4, 0))
        tk.Label(f_foot, text="Profil: Zwift Default Virtual Shifting", font=("Segoe UI", 8), fg=TEXT_MUTED, bg=BG_CARD).pack(side=tk.LEFT)
        tk.Label(f_foot, text="● Hotspots & DirectInput Active", font=("Segoe UI", 8, "bold"), fg=ACCENT_CYAN, bg=BG_CARD).pack(side=tk.RIGHT)

        self._update_selector_buttons_ui()

    def _update_selector_buttons_ui(self):
        """Updates styling and text of model and side buttons based on active state."""
        if not hasattr(self, "btn_model_click"):
            return

        is_click = (self.selected_hardware_model == "click")
        is_play_disabled = getattr(self, "is_play_disabled", False)
        is_click_disabled = getattr(self, "is_click_disabled", False)

        # Model buttons styling
        if is_click:
            self.btn_model_click.configure(
                state=tk.NORMAL,
                bg=ACCENT_CYAN, fg="#070B11",
                activebackground="#33ECFF", activeforeground="#070B11",
                font=("Segoe UI", 9, "bold"),
                cursor="hand2"
            )
            if is_play_disabled:
                # Wygaszony i niedostępny
                self.btn_model_play.configure(
                    state=tk.DISABLED,
                    bg="#070B12", fg="#334155",
                    disabledforeground="#334155",
                    font=("Segoe UI", 9),
                    cursor="arrow"
                )
            else:
                self.btn_model_play.configure(
                    state=tk.NORMAL,
                    bg="#080D16", fg="#64748B",
                    activebackground="#141F30", activeforeground=TEXT_WHITE,
                    font=("Segoe UI", 9),
                    cursor="hand2"
                )
            self.btn_pill_both.configure(text="Zestaw (L + P)")
            self.btn_pill_left.configure(text="👈 Lewy (− / D-Pad)")
            self.btn_pill_right.configure(text="👉 Prawy (+ / ABXY)")
            if hasattr(self, "lbl_title_left") and hasattr(self, "lbl_title_right"):
                self.lbl_title_left.configure(text="Zwift Click (Lewa manetka)")
                self.lbl_title_right.configure(text="Zwift Click (Prawa manetka)")
        else:
            if is_click_disabled:
                # Wygaszony i niedostępny
                self.btn_model_click.configure(
                    state=tk.DISABLED,
                    bg="#070B12", fg="#334155",
                    disabledforeground="#334155",
                    font=("Segoe UI", 9),
                    cursor="arrow"
                )
            else:
                self.btn_model_click.configure(
                    state=tk.NORMAL,
                    bg="#080D16", fg="#64748B",
                    activebackground="#141F30", activeforeground=TEXT_WHITE,
                    font=("Segoe UI", 9),
                    cursor="hand2"
                )
            self.btn_model_play.configure(
                state=tk.NORMAL,
                bg=ACCENT_CYAN, fg="#070B11",
                activebackground="#33ECFF", activeforeground="#070B11",
                font=("Segoe UI", 9, "bold"),
                cursor="hand2"
            )
            self.btn_pill_both.configure(text="Zestaw (L + P)")
            self.btn_pill_left.configure(text="👈 Lewy (Łopatka / D-Pad)")
            self.btn_pill_right.configure(text="👉 Prawy (Łopatka / ABXY)")
            if hasattr(self, "lbl_title_left") and hasattr(self, "lbl_title_right"):
                self.lbl_title_left.configure(text="Zwift Play (Lewa manetka)")
                self.lbl_title_right.configure(text="Zwift Play (Prawa manetka)")

        # Side buttons styling
        for side_name, btn in [("both", self.btn_pill_both), ("left", self.btn_pill_left), ("right", self.btn_pill_right)]:
            if self.active_diagram_side == side_name:
                btn.configure(
                    bg=ACCENT_EMERALD, fg="#070B11",
                    activebackground="#34D399", activeforeground="#070B11",
                    font=("Segoe UI", 9, "bold")
                )
            else:
                btn.configure(
                    bg="#080D16", fg="#64748B",
                    activebackground="#141F30", activeforeground=TEXT_WHITE,
                    font=("Segoe UI", 9)
                )

    def _select_hardware_model(self, model: str):
        if model == "play" and getattr(self, "is_play_disabled", False):
            return
        if model == "click" and getattr(self, "is_click_disabled", False):
            return
        self.selected_hardware_model = model
        self._sync_device_mode_config()
        self._update_selector_buttons_ui()
        self._render_controller_diagram()

    def _select_diagram_side(self, side: str):
        self.active_diagram_side = side
        self._sync_device_mode_config()
        self._update_selector_buttons_ui()
        self._render_controller_diagram()

    def _sync_device_mode_config(self):
        m = self.selected_hardware_model
        s = self.active_diagram_side
        if m == "click":
            if s == "left":
                mode_str = "Zwift Click (Tylko Lewa: - / D-Pad)"
            elif s == "right":
                mode_str = "Zwift Click (Tylko Prawa: + / Y,Z,B,A)"
            else:
                mode_str = "Zestaw Zwift Click (Lewa + Prawa)"
        else:
            if s == "left":
                mode_str = "Zwift Play (Tylko Lewa)"
            elif s == "right":
                mode_str = "Zwift Play (Tylko Prawa)"
            else:
                mode_str = "Zestaw Zwift Play (Lewa + Prawa)"
        self.cfg["device_mode"] = mode_str
        self.cfg["hardware_model"] = m
        if m == "click":
            self.cfg["model_right"] = "click"
        elif m == "play":
            self.cfg["model_right"] = "play"
        self.config_mgr.save()
        if hasattr(self, "combo_device_type"):
            self.combo_device_type.set(mode_str)

    def _switch_diagram_side(self, side: str):
        self._select_diagram_side(side)

    def _update_pills_ui(self):
        self._update_selector_buttons_ui()

    def _refresh_pill_colors(self):
        self._update_selector_buttons_ui()

    def _on_canvas_configure(self, event):
        """Debounced responsive handler for canvas resize and fullscreen events."""
        if abs(event.width - self._last_diag_w) < 4 and abs(event.height - self._last_diag_h) < 4:
            return
        self._last_diag_w = event.width
        self._last_diag_h = event.height

        if self._resize_job is not None:
            try:
                self.root.after_cancel(self._resize_job)
            except Exception:
                pass
        self._resize_job = self.root.after(35, self._render_controller_diagram)

    def _get_handlebar_background(self, w: int, h: int) -> Optional[Any]:
        """Loads, scales, and dims the road bike handlebar image from rider perspective."""
        if not PIL_AVAILABLE:
            return None
        cache_key = (w, h)
        if hasattr(self, "_handlebar_cache_key") and self._handlebar_cache_key == cache_key and self._handlebar_photo is not None:
            return self._handlebar_photo

        handlebar_path = get_asset_path("road_handlebar_pov.jpg")
        if not os.path.exists(handlebar_path):
            return None

        try:
            from PIL import ImageEnhance
            im = Image.open(handlebar_path).convert("RGBA")
            iw, ih = im.size
            if iw < 10 or ih < 10 or w < 10 or h < 10:
                return None
            scale = max(w / iw, h / ih)
            nw, nh = int(iw * scale), int(ih * scale)
            im_resized = im.resize((nw, nh), Image.Resampling.LANCZOS)
            # Center crop
            left = (nw - w) // 2
            top = (nh - h) // 2
            im_cropped = im_resized.crop((left, top, left + w, top + h))

            # Dim slightly to enhance cockpit contrast and button readability
            enhancer = ImageEnhance.Brightness(im_cropped)
            im_dimmed = enhancer.enhance(0.48)
            photo = ImageTk.PhotoImage(im_dimmed)
            self._handlebar_cache_key = cache_key
            self._handlebar_photo = photo
            return photo
        except Exception as e:
            print(f"[VeloBridge Handlebar Load Error] {e}")
            return None

    def _build_bottom_cards(self):
        bottom_frame = tk.Frame(self.root, bg=BG_DARK, padx=18)
        bottom_frame.pack(fill=tk.X, pady=(0, 10))

        # Cards 1 & 2: Steps and Shifters Info
        cards_spec = [
            ("1. Pierwsze kroki", "• Wybudź manetki klikając dowolny przycisk.\n• Kliknij 'POŁĄCZ I URUCHOM MYWHOOSH'.\n• W grze biegi MyShift działają natychmiast!", ACCENT_EMERALD, ACCENT_CYAN),
            ("2. Manetki Zwift Click & Play", "• Prawa manetka (+) podbija bieg wirtualny.\n• Lewa manetka (−) redukuje bieg.\n• Wszystkie przyciski i łopatki możesz dowolnie skonfigurować.", ACCENT_CYAN, "#0284C7"),
        ]

        for i, (title, desc, c_start, c_mid) in enumerate(cards_spec):
            c = ModernCard(bottom_frame, height=95, radius=10, pad_x=12, pad_y=10, bg_parent=BG_DARK)
            c.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0 if i == 0 else 6, 6))
            tk.Label(c.inner, text=title, font=("Segoe UI", 9, "bold"), fg=c_start, bg=BG_CARD).pack(anchor="w")
            tk.Label(c.inner, text=desc, font=("Segoe UI", 8), fg=TEXT_MUTED, bg=BG_CARD, justify=tk.LEFT).pack(anchor="w", pady=(3, 0))

        # 3. Bottom-Right Panel: Aesthetic BuyCoffee Interactive Button Card
        self.coffee_card = FeaturedCoffeeCard(bottom_frame, height=95, radius=10, pad_x=12, pad_y=10, bg_parent=BG_DARK)
        self.coffee_card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(6, 0))

    # ----------------------------------------------------
    # Photorealistic Card Loaders with Pillow
    # ----------------------------------------------------
    def _get_click_card_image(self, side: str, size: int) -> Optional[Any]:
        """Loads and resizes the photorealistic Zwift Click image into a seamless cockpit graphic."""
        if not PIL_AVAILABLE:
            return None

        cache_key = (f"click_{side}", size)
        if cache_key in self._image_cache:
            return self._image_cache[cache_key]

        card_filename = f"click_{side}_card.png"
        raw_filename = f"click_{side}.jpg"

        card_path = get_asset_path(card_filename)
        raw_path = get_asset_path(raw_filename)
        src_path = card_path if os.path.exists(card_path) else raw_path

        if not os.path.exists(src_path):
            return None

        try:
            im = Image.open(src_path).convert("RGBA")
            w, h = im.size
            if w != h:
                min_dim = min(w, h)
                left = (w - min_dim) // 2
                top = (h - min_dim) // 2
                im = im.crop((left, top, left + min_dim, top + min_dim))

            im_resized = im.resize((size, size), Image.Resampling.LANCZOS)
            # Anti-aliased circular alpha mask to prevent rectangular corner clipping
            mask = Image.new("L", (size * 2, size * 2), 0)
            m_draw = ImageDraw.Draw(mask)
            m_draw.ellipse((4, 4, size * 2 - 5, size * 2 - 5), fill=255)
            mask = mask.resize((size, size), Image.Resampling.LANCZOS)
            im_resized.putalpha(mask)

            photo = ImageTk.PhotoImage(im_resized)
            self._image_cache[cache_key] = photo
            return photo
        except Exception as e:
            print(f"[VeloBridge Image Load Error Click] {e}")
            return None

    def _get_play_card_image(self, side: str, size: int) -> Optional[Any]:
        """Loads and resizes the photorealistic Zwift Play image into a seamless cockpit graphic."""
        if not PIL_AVAILABLE:
            return None

        cache_key = (f"play_{side}", size)
        if cache_key in self._image_cache:
            return self._image_cache[cache_key]

        card_filename = f"play_{side}_card.png"
        raw_filename = f"play_{side}.jpg"

        card_path = get_asset_path(card_filename)
        raw_path = get_asset_path(raw_filename)
        src_path = card_path if os.path.exists(card_path) else raw_path

        if not os.path.exists(src_path):
            return None

        try:
            im = Image.open(src_path).convert("RGBA")
            w, h = im.size
            if w != h:
                min_dim = min(w, h)
                left = (w - min_dim) // 2
                top = (h - min_dim) // 2
                im = im.crop((left, top, left + min_dim, top + min_dim))

            im_resized = im.resize((size, size), Image.Resampling.LANCZOS)
            # Anti-aliased circular alpha mask to prevent rectangular corner clipping
            mask = Image.new("L", (size * 2, size * 2), 0)
            m_draw = ImageDraw.Draw(mask)
            m_draw.ellipse((4, 4, size * 2 - 5, size * 2 - 5), fill=255)
            mask = mask.resize((size, size), Image.Resampling.LANCZOS)
            im_resized.putalpha(mask)

            photo = ImageTk.PhotoImage(im_resized)
            self._image_cache[cache_key] = photo
            return photo
        except Exception as e:
            print(f"[VeloBridge Image Load Error Play] {e}")
            return None

    # ----------------------------------------------------
    # Controller Diagram Drawing & Interactive Callouts
    def _render_controller_diagram(self):
        self._resize_job = None

        # Clean up existing canvas items and embedded widget frames
        for item in self.canvas_diag.find_all():
            self.canvas_diag.delete(item)
        for child in self.canvas_diag.winfo_children():
            try:
                child.destroy()
            except Exception:
                pass

        self.callout_widgets.clear()
        self.canvas_shape_ids.clear()
        self.button_hotspot_coords.clear()
        self.loaded_card_images.clear()

        # Canvas Dimensions
        cw = self.canvas_diag.winfo_width()
        ch = self.canvas_diag.winfo_height()
        if cw < 100 or ch < 100:
            self.canvas_diag.update_idletasks()
            cw = self.canvas_diag.winfo_width()
            ch = self.canvas_diag.winfo_height()
        cw = max(560, cw)
        ch = max(340, ch)
        cx = cw // 2
        cy = ch // 2

        # 1. Draw photorealistic Road Bike Handlebar background from rider perspective
        handlebar_bg = self._get_handlebar_background(cw, ch)
        if handlebar_bg is not None:
            self.canvas_diag.create_image(cx, cy, image=handlebar_bg, anchor=tk.CENTER, tags="bg_handlebar")

        is_click = (self.selected_hardware_model == "click")

        if is_click:
            draw_fn = self._draw_click_pod
            label_left = "Zwift Click • Lewy (D-Pad & −)"
            label_right = "Zwift Click • Prawy (Y/Z/B/A & +)"
        else:
            draw_fn = self._draw_play_pod
            label_left = "Zwift Play • Lewy (D-Pad & Łopatka)"
            label_right = "Zwift Play • Prawy (Y/Z/B/A & Łopatka)"

        # Vertical hood coordinate: in road_handlebar_pov.jpg, hoods are at ~46% from top
        cy_pod = int(ch * 0.46)

        if self.active_diagram_side == "both":
            # Dual Mode: Left controller on Left hood, Right controller on Right hood
            card_size = min(250, max(170, int(min(ch * 0.52, cw * 0.24))))
            hood_offset = int(cw * 0.22)
            cx_left = cx - hood_offset
            cx_right = cx + hood_offset
            tag_offset = int(card_size * 0.72)

            centers = [(cx_left, cy_pod), (cx_right, cy_pod)]

            # Symmetrical ambient cosmic cockpit aura behind each controller
            for ccx, ccy in centers:
                for r_pct, col in [(0.68, "#07101B"), (0.58, "#091424"), (0.50, "#0C1B2E")]:
                    rad = int(card_size * r_pct)
                    self.canvas_diag.create_oval(ccx - rad, ccy - rad, ccx + rad, ccy + rad, fill=col, outline="")

            # Draw both controllers strictly on their respective hoods
            draw_fn(cx_left, cy_pod, "left", is_both=True, cw=cw, ch=ch, card_size=card_size, tag_offset=tag_offset)
            draw_fn(cx_right, cy_pod, "right", is_both=True, cw=cw, ch=ch, card_size=card_size, tag_offset=tag_offset)

            label_y = cy_pod + int(card_size * 0.52) + 14
            self.canvas_diag.create_text(
                cx_left, label_y,
                text=label_left,
                fill=TEXT_WHITE,
                font=("Segoe UI", 9, "bold")
            )
            self.canvas_diag.create_text(
                cx_right, label_y,
                text=label_right,
                fill=TEXT_WHITE,
                font=("Segoe UI", 9, "bold")
            )

        elif self.active_diagram_side == "left":
            # STRICT REQUIREMENT: Only Left controller, placed on the LEFT side of the handlebar!
            card_size = min(260, max(180, int(min(ch * 0.56, cw * 0.27))))
            cx_left = cx - int(cw * 0.20)
            tag_offset = int(card_size * 0.72)

            centers = [(cx_left, cy_pod)]
            for ccx, ccy in centers:
                for r_pct, col in [(0.68, "#07101B"), (0.58, "#091424"), (0.50, "#0C1B2E")]:
                    rad = int(card_size * r_pct)
                    self.canvas_diag.create_oval(ccx - rad, ccy - rad, ccx + rad, ccy + rad, fill=col, outline="")

            draw_fn(cx_left, cy_pod, "left", is_both=False, cw=cw, ch=ch, card_size=card_size, tag_offset=tag_offset)

            label_y = cy_pod + int(card_size * 0.52) + 14
            self.canvas_diag.create_text(
                cx_left, label_y,
                text=label_left,
                fill=TEXT_WHITE,
                font=("Segoe UI", 10, "bold")
            )

        else: # active_diagram_side == "right"
            # STRICT REQUIREMENT: Only Right controller, placed on the RIGHT side of the handlebar!
            card_size = min(260, max(180, int(min(ch * 0.56, cw * 0.27))))
            cx_right = cx + int(cw * 0.20)
            tag_offset = int(card_size * 0.72)

            centers = [(cx_right, cy_pod)]
            for ccx, ccy in centers:
                for r_pct, col in [(0.68, "#07101B"), (0.58, "#091424"), (0.50, "#0C1B2E")]:
                    rad = int(card_size * r_pct)
                    self.canvas_diag.create_oval(ccx - rad, ccy - rad, ccx + rad, ccy + rad, fill=col, outline="")

            draw_fn(cx_right, cy_pod, "right", is_both=False, cw=cw, ch=ch, card_size=card_size, tag_offset=tag_offset)

            label_y = cy_pod + int(card_size * 0.52) + 14
            self.canvas_diag.create_text(
                cx_right, label_y,
                text=label_right,
                fill=TEXT_WHITE,
                font=("Segoe UI", 10, "bold")
            )

        # Draw glowing portal rings over pod borders
        for ccx, ccy in centers:
            r_halo = int(card_size * 0.52)
            r_main = int(card_size * 0.49)
            r_inner = int(card_size * 0.42)

            self.canvas_diag.create_oval(ccx - r_halo, ccy - r_halo, ccx + r_halo, ccy + r_halo, outline="#004D66", width=2)
            self.canvas_diag.create_oval(ccx - r_main, ccy - r_main, ccx + r_main, ccy + r_main, outline="#00E5FF", width=2)
            self.canvas_diag.create_oval(ccx - r_inner, ccy - r_inner, ccx + r_inner, ccy + r_inner, outline="#007799", width=1, dash=(3, 3))

            t_len = max(6, int(card_size * 0.04))
            self.canvas_diag.create_line(ccx - r_main - t_len, ccy, ccx - r_main + 3, ccy, fill="#00E5FF", width=2)
            self.canvas_diag.create_line(ccx + r_main - 3, ccy, ccx + r_main + t_len, ccy, fill="#00E5FF", width=2)
            self.canvas_diag.create_line(ccx, ccy - r_main - t_len, ccx, ccy - r_main + 3, fill="#00E5FF", width=2)
            self.canvas_diag.create_line(ccx, ccy + r_main - 3, ccx, ccy + r_main + t_len, fill="#00E5FF", width=2)

    def _draw_click_pod(self, cx: int, cy: int, side: str, is_both: bool, cw: int, ch: int, card_size: int = 240, tag_offset: Optional[int] = None):
        """Draws photorealistic photo-card Zwift Click with glowing button hotspots and callouts."""
        is_left = (side == "left")
        photo = self._get_click_card_image(side, card_size)

        if photo is not None:
            # 1. Render Photorealistic Image Card
            self.loaded_card_images.append(photo)  # keep reference
            self.canvas_diag.create_image(cx, cy, image=photo, anchor=tk.CENTER)

            # 2. Status LED Overlay
            is_conn = self.connected_left if is_left else self.connected_right
            led_nx, led_ny = (-0.058, -0.247) if is_left else (-0.127, -0.283)
            led_x = cx + int(led_nx * card_size)
            led_y = cy + int(led_ny * card_size)

            if is_conn:
                self.canvas_diag.create_oval(led_x - 7, led_y - 4, led_x + 7, led_y + 4, outline=ACCENT_EMERALD, width=2)
                self.canvas_diag.create_oval(led_x - 4, led_y - 2, led_x + 4, led_y + 2, fill=ACCENT_EMERALD, outline="")
            else:
                self.canvas_diag.create_oval(led_x - 4, led_y - 2, led_x + 4, led_y + 2, fill="#475569", outline="")

            # 3. Hotspot Button Coordinates from Physical Photo
            if is_left:
                btn_defs = [
                    ("y_up",    -0.002, -0.140, "▲", "#00E5FF"),  # Up arrow
                    ("z_left",  -0.091,  0.031, "◄", "#FF6B00"),  # Left arrow
                    ("b_down",   0.081,  0.103, "▼", "#E61E7A"),  # Down arrow
                    ("a_right",  0.169, -0.063, "►", "#10B981"),  # Right arrow
                    ("shifter",  0.174,  0.246, "−", "#00E676")   # Minus shifter
                ]
            else:
                btn_defs = [
                    ("y_up",    -0.068, -0.172, "Y", "#00E5FF"),  # Cyan Y
                    ("z_left",  -0.150,  0.011, "Z", "#FF6B00"),  # Orange Z
                    ("b_down",   0.049,  0.081, "B", "#E61E7A"),  # Magenta B
                    ("a_right",  0.138, -0.092, "A", "#10B981"),  # Green A
                    ("shifter",  0.108,  0.223, "+", "#00E676")   # Plus shifter
                ]

            hotspot_radius = max(11, int(15 * (card_size / 260)))

            # Render hotspots over the photo
            for btn_id, nx, ny, glyph, fill_c in btn_defs:
                bx = cx + int(nx * card_size)
                by = cy + int(ny * card_size)
                self.button_hotspot_coords[f"{side}_{btn_id}"] = (bx, by)

                # Hotspot ring on the photo
                ring_id = self.canvas_diag.create_oval(
                    bx - hotspot_radius, by - hotspot_radius,
                    bx + hotspot_radius, by + hotspot_radius,
                    outline=fill_c,
                    width=2,
                    fill=""
                )
                self.canvas_shape_ids[f"{side}_{btn_id}"] = ring_id

                # Allow direct clicking on the button in the photo
                self.canvas_diag.tag_bind(
                    ring_id,
                    "<Button-1>",
                    lambda e, s=side, b=btn_id: self._open_action_menu(e, s, b)
                )

        else:
            # Fallback to vector drawing if Pillow/image not found
            self._draw_click_pod_vector_fallback(cx, cy, side, is_both, cw)

        # 4. Interactive Callout Bubbles Placement
        v_step = max(38, min(52, int(card_size * 0.17)))
        if tag_offset is None:
            tag_offset = int(card_size * 0.70)

        if is_left:
            if is_both:
                tag_x = cx - tag_offset
                spec = [
                    ("y_up",    "▲", "#00E5FF", tag_x, cy - 2 * v_step),
                    ("z_left",  "◄", "#FF6B00", tag_x, cy - v_step),
                    ("a_right", "►", "#10B981", tag_x, cy),
                    ("b_down",  "▼", "#E61E7A", tag_x, cy + v_step),
                    ("shifter", "−", "#00E676", tag_x, cy + 2 * v_step),
                ]
            else:
                tag_x_l = cx - tag_offset
                tag_x_r = cx + tag_offset
                spec = [
                    ("y_up",    "▲", "#00E5FF", tag_x_l, cy - int(v_step * 1.6)),
                    ("z_left",  "◄", "#FF6B00", tag_x_l, cy - int(v_step * 0.3)),
                    ("a_right", "►", "#10B981", tag_x_r, cy - int(v_step * 0.8)),
                    ("b_down",  "▼", "#E61E7A", tag_x_r, cy + int(v_step * 0.5)),
                    ("shifter", "−", "#00E676", tag_x_r, cy + int(v_step * 1.8)),
                ]
        else:
            if is_both:
                tag_x = cx + tag_offset
                spec = [
                    ("y_up",    "Y", "#00E5FF", tag_x, cy - 2 * v_step),
                    ("z_left",  "Z", "#FF6B00", tag_x, cy - v_step),
                    ("a_right", "A", "#10B981", tag_x, cy),
                    ("b_down",  "B", "#E61E7A", tag_x, cy + v_step),
                    ("shifter", "+", "#00E676", tag_x, cy + 2 * v_step),
                ]
            else:
                tag_x_l = cx - tag_offset
                tag_x_r = cx + tag_offset
                spec = [
                    ("y_up",    "Y", "#00E5FF", tag_x_l, cy - int(v_step * 1.6)),
                    ("z_left",  "Z", "#FF6B00", tag_x_l, cy - int(v_step * 0.3)),
                    ("a_right", "A", "#10B981", tag_x_r, cy - int(v_step * 0.8)),
                    ("b_down",  "B", "#E61E7A", tag_x_r, cy + int(v_step * 0.5)),
                    ("shifter", "+", "#00E676", tag_x_r, cy + int(v_step * 1.8)),
                ]

        for btn_id, glyph, fill_c, tx, ty in spec:
            full_key = f"{side}_{btn_id}"
            bx, by = self.button_hotspot_coords.get(full_key, (cx, cy))
            self._create_callout(btn_id, glyph, fill_c, bx, by, tx, ty, side)

    def _draw_click_pod_vector_fallback(self, cx: int, cy: int, side: str, is_both: bool, cw: int):
        """Vector drawing fallback used only when Click photos cannot be loaded."""
        is_left = (side == "left")

        # Main body
        body_pts = [
            cx - 30, cy - 42, cx - 16, cy - 54, cx, cy - 57, cx + 16, cy - 54, cx + 30, cy - 42,
            cx + 44, cy - 30, cx + 47, cy - 10, cx + 47, cy + 10, cx + 44, cy + 30,
            cx + 30, cy + 40, cx + 18, cy + 40, cx - 18, cy + 40, cx - 30, cy + 40,
            cx - 44, cy + 30, cx - 47, cy + 10, cx - 47, cy - 10, cx - 44, cy - 30,
        ]
        self.canvas_diag.create_polygon(body_pts, fill="#1A1E25", outline="#323B49", width=2, smooth=True)

        # Tab
        tab_pts = [cx - 17, cy + 36, cx + 17, cy + 36, cx + 17, cy + 68, cx + 11, cy + 82, cx - 11, cy + 82, cx - 17, cy + 68]
        tab_id = self.canvas_diag.create_polygon(tab_pts, fill="#1D222A", outline="#364152", width=2)
        self.canvas_shape_ids[f"{side}_shifter"] = tab_id
        self.button_hotspot_coords[f"{side}_shifter"] = (cx, cy + 58)

        if is_left:
            self.canvas_shape_ids["left_y_up"] = self.canvas_diag.create_oval(cx - 7, cy - 28, cx + 7, cy - 14, fill="#0284C7")
            self.canvas_shape_ids["left_z_left"] = self.canvas_diag.create_oval(cx - 21, cy - 14, cx - 7, cy, fill="#D97706")
            self.canvas_shape_ids["left_a_right"] = self.canvas_diag.create_oval(cx + 7, cy - 14, cx + 21, cy, fill="#10B981")
            self.canvas_shape_ids["left_b_down"] = self.canvas_diag.create_oval(cx - 7, cy, cx + 7, cy + 14, fill="#DB2777")
            self.button_hotspot_coords["left_y_up"] = (cx, cy - 21)
            self.button_hotspot_coords["left_z_left"] = (cx - 14, cy - 7)
            self.button_hotspot_coords["left_a_right"] = (cx + 14, cy - 7)
            self.button_hotspot_coords["left_b_down"] = (cx, cy + 7)
        else:
            self.canvas_shape_ids["right_y_up"] = self.canvas_diag.create_oval(cx - 9, cy - 30, cx + 9, cy - 12, fill="#00C2E8")
            self.canvas_shape_ids["right_z_left"] = self.canvas_diag.create_oval(cx - 24, cy - 15, cx - 6, cy + 3, fill="#FF6B00")
            self.canvas_shape_ids["right_b_down"] = self.canvas_diag.create_oval(cx - 9, cy - 1, cx + 9, cy + 17, fill="#E61E7A")
            self.canvas_shape_ids["right_a_right"] = self.canvas_diag.create_oval(cx + 6, cy - 15, cx + 24, cy + 3, fill="#10B981")
            self.button_hotspot_coords["right_y_up"] = (cx, cy - 21)
            self.button_hotspot_coords["right_z_left"] = (cx - 15, cy - 6)
            self.button_hotspot_coords["right_b_down"] = (cx, cy + 8)
            self.button_hotspot_coords["right_a_right"] = (cx + 15, cy - 6)

    def _draw_play_pod(self, cx: int, cy: int, side: str, is_both: bool, cw: int, ch: int, card_size: int = 240, tag_offset: Optional[int] = None):
        """Draws photorealistic photo-card Zwift Play with glowing button hotspots and callouts."""
        is_left = (side == "left")
        photo = self._get_play_card_image(side, card_size)

        if photo is not None:
            # 1. Render Photorealistic Image Card
            self.loaded_card_images.append(photo)  # keep reference
            self.canvas_diag.create_image(cx, cy, image=photo, anchor=tk.CENTER)

            # 2. Status Connection Halo
            is_conn = self.connected_left if is_left else self.connected_right
            badge_y = cy + int(card_size * 0.42)
            if is_conn:
                self.canvas_diag.create_oval(cx - 5, badge_y - 3, cx + 5, badge_y + 3, fill=ACCENT_EMERALD, outline="")
            else:
                self.canvas_diag.create_oval(cx - 4, badge_y - 2, cx + 4, badge_y + 2, fill="#475569", outline="")

            # 3. Hotspot Button Coordinates from Physical Photo
            if is_left:
                btn_defs = [
                    ("y_up",    -0.124, -0.146, "▲", "#00E5FF"),  # Up arrow
                    ("z_left",  -0.190, -0.113, "◄", "#FF6B00"),  # Left arrow
                    ("b_down",  -0.177, -0.044, "▼", "#E61E7A"),  # Down arrow
                    ("a_right", -0.104, -0.078, "►", "#10B981"),  # Right arrow
                    ("shifter",  0.245, -0.122, "⚡", "#FF6B00")   # Orange paddle
                ]
            else:
                btn_defs = [
                    ("y_up",    -0.150, -0.185, "Y", "#00E5FF"),  # Cyan Y
                    ("z_left",  -0.239, -0.146, "Z", "#FF6B00"),  # Orange Z
                    ("b_down",  -0.226, -0.058, "B", "#E61E7A"),  # Magenta B
                    ("a_right", -0.131, -0.094, "A", "#10B981"),  # Green A
                    ("shifter",  0.308, -0.156, "⚡", "#FF6B00")   # Orange paddle
                ]

            hotspot_radius = max(10, int(13 * (card_size / 260)))
            paddle_radius = max(12, int(16 * (card_size / 260)))

            # Render hotspots over the photo
            for btn_id, nx, ny, glyph, fill_c in btn_defs:
                bx = cx + int(nx * card_size)
                by = cy + int(ny * card_size)
                self.button_hotspot_coords[f"{side}_{btn_id}"] = (bx, by)

                rad = paddle_radius if btn_id == "shifter" else hotspot_radius

                # Hotspot ring on the photo
                ring_id = self.canvas_diag.create_oval(
                    bx - rad, by - rad,
                    bx + rad, by + rad,
                    outline=fill_c,
                    width=2,
                    fill=""
                )
                self.canvas_shape_ids[f"{side}_{btn_id}"] = ring_id

                # Allow direct clicking on the button in the photo
                self.canvas_diag.tag_bind(
                    ring_id,
                    "<Button-1>",
                    lambda e, s=side, b=btn_id: self._open_action_menu(e, s, b)
                )

        else:
            # Fallback to vector drawing
            self._draw_play_pod_vector_fallback(cx, cy, side, cw)

        # 4. Interactive Callout Bubbles Placement
        v_step = max(38, min(52, int(card_size * 0.17)))
        if tag_offset is None:
            tag_offset = int(card_size * 0.70)

        if is_left:
            if is_both:
                tag_x = cx - tag_offset
                spec = [
                    ("y_up",    "▲", "#00E5FF", tag_x, cy - 2 * v_step),
                    ("z_left",  "◄", "#FF6B00", tag_x, cy - v_step),
                    ("a_right", "►", "#10B981", tag_x, cy),
                    ("b_down",  "▼", "#E61E7A", tag_x, cy + v_step),
                    ("shifter", "⚡", "#FF6B00", tag_x, cy + 2 * v_step),
                ]
            else:
                tag_x_l = cx - tag_offset
                tag_x_r = cx + tag_offset
                spec = [
                    ("y_up",    "▲", "#00E5FF", tag_x_l, cy - int(v_step * 1.6)),
                    ("z_left",  "◄", "#FF6B00", tag_x_l, cy - int(v_step * 0.4)),
                    ("b_down",  "▼", "#E61E7A", tag_x_l, cy + int(v_step * 0.8)),
                    ("a_right", "►", "#10B981", tag_x_l, cy + int(v_step * 2.0)),
                    ("shifter", "⚡", "#FF6B00", tag_x_r, cy - int(v_step * 0.5)),
                ]
        else:
            if is_both:
                tag_x = cx + tag_offset
                spec = [
                    ("y_up",    "Y", "#00E5FF", tag_x, cy - 2 * v_step),
                    ("z_left",  "Z", "#FF6B00", tag_x, cy - v_step),
                    ("a_right", "A", "#10B981", tag_x, cy),
                    ("b_down",  "B", "#E61E7A", tag_x, cy + v_step),
                    ("shifter", "⚡", "#FF6B00", tag_x, cy + 2 * v_step),
                ]
            else:
                tag_x_l = cx - tag_offset
                tag_x_r = cx + tag_offset
                spec = [
                    ("y_up",    "Y", "#00E5FF", tag_x_l, cy - int(v_step * 1.6)),
                    ("z_left",  "Z", "#FF6B00", tag_x_l, cy - int(v_step * 0.4)),
                    ("b_down",  "B", "#E61E7A", tag_x_l, cy + int(v_step * 0.8)),
                    ("a_right", "A", "#10B981", tag_x_l, cy + int(v_step * 2.0)),
                    ("shifter", "⚡", "#FF6B00", tag_x_r, cy - int(v_step * 0.5)),
                ]

        for btn_id, glyph, fill_c, tx, ty in spec:
            full_key = f"{side}_{btn_id}"
            bx, by = self.button_hotspot_coords.get(full_key, (cx, cy))
            self._create_callout(btn_id, glyph, fill_c, bx, by, tx, ty, side)

    def _draw_play_pod_vector_fallback(self, cx: int, cy: int, side: str, cw: int):
        """Vector drawing fallback used only when Play photos cannot be loaded."""
        is_left = (side == "left")

        # Ergonomic Pod Body
        self.canvas_diag.create_oval(cx - 75, cy - 65, cx + 75, cy + 95, fill="#131B24", outline="#1F2A37", width=3)
        self.canvas_diag.create_oval(cx - 62, cy - 62, cx + 62, cy + 62, fill="#1E293B", outline="#334155", width=2)
        self.canvas_diag.create_oval(cx - 48, cy - 48, cx + 48, cy + 48, fill="#0F172A", outline="#1E293B", width=2)

        # Shifter Paddle Tab
        pad_poly = self.canvas_diag.create_polygon(
            [cx - 24, cy + 58, cx + 24, cy + 58, cx + 18, cy + 84, cx - 18, cy + 84],
            fill="#065F46", outline="#10B981", width=2
        )
        self.canvas_shape_ids[f"{side}_shifter_body"] = pad_poly

        if is_left:
            self.canvas_shape_ids["left_y_up"] = self.canvas_diag.create_oval(cx - 13, cy - 43, cx + 13, cy - 17, fill="#00E5FF")
            self.canvas_shape_ids["left_b_down"] = self.canvas_diag.create_oval(cx - 13, cy + 17, cx + 13, cy + 43, fill="#E61E7A")
            self.canvas_shape_ids["left_z_left"] = self.canvas_diag.create_oval(cx - 43, cy - 13, cx - 17, cy + 13, fill="#FF6B00")
            self.canvas_shape_ids["left_a_right"] = self.canvas_diag.create_oval(cx + 17, cy - 13, cx + 43, cy + 13, fill="#10B981")
            self.canvas_shape_ids["left_shifter"] = self.canvas_diag.create_oval(cx - 11, cy + 57, cx + 11, cy + 79, fill="#FF6B00")
            self.button_hotspot_coords["left_y_up"] = (cx, cy - 30)
            self.button_hotspot_coords["left_b_down"] = (cx, cy + 30)
            self.button_hotspot_coords["left_z_left"] = (cx - 30, cy)
            self.button_hotspot_coords["left_a_right"] = (cx + 30, cy)
            self.button_hotspot_coords["left_shifter"] = (cx, cy + 68)
        else:
            self.canvas_shape_ids["right_y_up"] = self.canvas_diag.create_oval(cx - 13, cy - 43, cx + 13, cy - 17, fill="#00E5FF")
            self.canvas_shape_ids["right_b_down"] = self.canvas_diag.create_oval(cx - 13, cy + 17, cx + 13, cy + 43, fill="#E61E7A")
            self.canvas_shape_ids["right_z_left"] = self.canvas_diag.create_oval(cx - 43, cy - 13, cx - 17, cy + 13, fill="#FF6B00")
            self.canvas_shape_ids["right_a_right"] = self.canvas_diag.create_oval(cx + 17, cy - 13, cx + 43, cy + 13, fill="#10B981")
            self.canvas_shape_ids["right_shifter"] = self.canvas_diag.create_oval(cx - 11, cy + 57, cx + 11, cy + 79, fill="#FF6B00")
            self.button_hotspot_coords["right_y_up"] = (cx, cy - 30)
            self.button_hotspot_coords["right_b_down"] = (cx, cy + 30)
            self.button_hotspot_coords["right_z_left"] = (cx - 30, cy)
            self.button_hotspot_coords["right_a_right"] = (cx + 30, cy)
            self.button_hotspot_coords["right_shifter"] = (cx, cy + 68)

    def _create_callout(self, btn_id: str, glyph: str, fill_c: str, bx: int, by: int, tag_x: int, tag_y: int, side: str):
        is_click = (getattr(self, "selected_hardware_model", "play") == "click")
        if is_click:
            map_key = "click_left" if side == "left" else "click_right"
        else:
            map_key = "play_left" if side == "left" else "play_right"

        cur_map = self.cfg.get("mappings", {}).get(map_key, {})
        action_code = cur_map.get(btn_id)
        if action_code is None:
            if is_click:
                def_map = DEFAULT_CLICK_LEFT_MAPPING if side == "left" else DEFAULT_CLICK_RIGHT_MAPPING
            else:
                def_map = DEFAULT_PLAY_LEFT_MAPPING if side == "left" else DEFAULT_PLAY_RIGHT_MAPPING
            action_code = def_map.get(btn_id, "NONE")
        action_text = AVAILABLE_ACTIONS.get(action_code, "Brak")

        # Sleek dashed connector line with endpoint dots
        self.canvas_diag.create_oval(bx - 3, by - 3, bx + 3, by + 3, fill=fill_c, outline="#FFFFFF", width=1)
        line_id = self.canvas_diag.create_line(bx, by, tag_x, tag_y, fill="#00B4D8", width=1.5, dash=(4, 2))
        self.canvas_diag.create_oval(tag_x - 3, tag_y - 3, tag_x + 3, tag_y + 3, fill="#00E5FF", outline="")

        # Callout Bubble Frame (Modern Glass Badge)
        bubble = tk.Frame(
            self.canvas_diag,
            bg="#090E17",
            highlightthickness=1,
            highlightbackground="#1A2B42",
            padx=8,
            pady=4,
            cursor="hand2"
        )

        badge = tk.Label(bubble, text=f" {glyph} ", font=("Segoe UI", 8, "bold"), bg=fill_c, fg="white", padx=2, pady=1)
        badge.pack(side=tk.LEFT, padx=(0, 5))

        lbl_act = tk.Label(bubble, text=action_text, font=("Segoe UI", 8, "bold"), fg=TEXT_WHITE, bg="#090E17")
        lbl_act.pack(side=tk.LEFT, padx=(0, 4))

        lbl_arrow = tk.Label(bubble, text="▾", font=("Segoe UI", 7), fg=TEXT_MUTED, bg="#090E17")
        lbl_arrow.pack(side=tk.LEFT)

        def _on_enter_bubble(e, bf=bubble, la=lbl_act, ar=lbl_arrow):
            bf.configure(bg="#111D30", highlightbackground=ACCENT_CYAN)
            la.configure(bg="#111D30")
            ar.configure(bg="#111D30")

        def _on_leave_bubble(e, bf=bubble, la=lbl_act, ar=lbl_arrow):
            bf.configure(bg="#090E17", highlightbackground="#1A2B42")
            la.configure(bg="#090E17")
            ar.configure(bg="#090E17")

        for w in (bubble, badge, lbl_act, lbl_arrow):
            w.bind("<Button-1>", lambda e, s=side, b=btn_id: self._open_action_menu(e, s, b))
            w.bind("<Enter>", _on_enter_bubble)
            w.bind("<Leave>", _on_leave_bubble)

        full_key = f"{side}_{btn_id}"
        self.callout_widgets[full_key] = {
            "frame": bubble,
            "badge": badge,
            "label": lbl_act,
            "default_bg": "#090E17",
            "default_fill": fill_c,
            "line_id": line_id
        }

        self.canvas_diag.create_window(tag_x, tag_y, window=bubble)

    def _open_action_menu(self, event, side: str, btn_id: str):
        menu = tk.Menu(
            self.root,
            tearoff=0,
            bg=BG_CARD,
            fg=TEXT_WHITE,
            activebackground=ACCENT_EMERALD,
            activeforeground=BG_DARK,
            font=("Segoe UI", 9)
        )

        for code, label in AVAILABLE_ACTIONS.items():
            menu.add_command(label=label, command=lambda c=code: self._assign_action(side, btn_id, c))

        menu.tk_popup(event.x_root, event.y_root)

    def _assign_action(self, side: str, btn_id: str, action_code: str):
        is_click = (getattr(self, "selected_hardware_model", "play") == "click")
        if is_click:
            map_key = "click_left" if side == "left" else "click_right"
        else:
            map_key = "play_left" if side == "left" else "play_right"

        if "mappings" not in self.cfg:
            self.cfg["mappings"] = {}
        if map_key not in self.cfg["mappings"]:
            self.cfg["mappings"][map_key] = {}
        self.cfg["mappings"][map_key][btn_id] = action_code
        self.config_mgr.save()

        # Update callout text
        full_key = f"{side}_{btn_id}"
        if full_key in self.callout_widgets:
            lbl = self.callout_widgets[full_key]["label"]
            lbl.configure(text=AVAILABLE_ACTIONS.get(action_code, "Brak"))

        self._log_local(f"Przypisano ({map_key}): {side.upper()} {btn_id} -> {action_code}")

    # ----------------------------------------------------
    # Event Handlers & Actions
    # ----------------------------------------------------
    def _on_gear_changed(self, new_gear: int):
        if hasattr(self, "gear_hud_widget"):
            self.gear_hud_widget.update_gear(new_gear)
        if self.mini_overlay:
            self.mini_overlay.update_gear(new_gear)

    def _on_connect_and_launch(self):
        """Connects controllers and launches or focuses MyWhoosh."""
        if IS_MACOS and not check_macos_accessibility_permission(prompt=True):
            self._log_local(
                "⚠️ macOS: Otwarto Ustawienia Dostępności — zaznacz VeloBridge, aby klawisze K/I działały w MyWhoosh."
            )

        if not (self.connected_left or self.connected_right):
            self._on_connect_only()

        custom_path = self.cfg.get("mywhoosh_path", "")
        success = launch_or_focus_mywhoosh(custom_path)
        if success:
            self._log_local("Uruchomiono lub aktywowano okno gry MyWhoosh.")
            self._update_mywhoosh_tile()
        else:
            prompt_msg = (
                "Nie udało się automatycznie zlokalizować zainstalowanej gry MyWhoosh.\n\n"
                "Czy chcesz wskazać ścieżkę do aplikacji MyWhoosh.app ręcznie?"
                if IS_MACOS else
                "Nie udało się automatycznie zlokalizować zainstalowanej gry MyWhoosh.\n\n"
                "Czy chcesz wskazać ścieżkę do pliku MyWhoosh.exe ręcznie?"
            )
            res = messagebox.askyesno(
                "Lokalizacja gry MyWhoosh",
                prompt_msg,
                parent=self.root
            )
            if res:
                self._choose_mywhoosh_path()

    def _open_mywhoosh_path_dialog(self):
        """Opens dedicated modern modal dialog to configure or auto-detect MyWhoosh path."""
        MyWhooshPathDialog(self.root, self)

    def _choose_mywhoosh_path(self):
        """Opens MyWhoosh path dialog."""
        self._open_mywhoosh_path_dialog()

    def _update_mywhoosh_tile(self):
        """Updates MyWhoosh status tile with detected path or state."""
        try:
            custom_p = self.cfg.get("mywhoosh_path", "")
            info = detect_mywhoosh(custom_p)
            engine_lbl = "Quartz HID" if IS_MACOS else "DirectInput"
            auto_lbl = "Auto (macOS .app)" if IS_MACOS else "Auto (Store/HD)"
            if info:
                if custom_p:
                    base_n = os.path.basename(custom_p.rstrip("/\\"))
                    self.lbl_desc_mywhoosh.configure(text=f"📁 {base_n} • {engine_lbl}", fg=ACCENT_CYAN)
                else:
                    self.lbl_desc_mywhoosh.configure(text=f"{auto_lbl} • {engine_lbl}", fg=ACCENT_CYAN)
            else:
                self.lbl_desc_mywhoosh.configure(text=f"{engine_lbl} MyShift • Gotowy", fg="#94A3B8")
        except Exception:
            pass

    def _on_connect_only(self):
        mac_l = self.cfg.get("mac_left", "").strip()
        mac_r = self.cfg.get("mac_right", "").strip()

        if not mac_l and not mac_r:
            messagebox.showwarning(
                "Brak skonfigurowanych urządzeń",
                "Otwórz 'Zarządzaj manetkami & Skaner BLE' i wybierz lub wpisz adresy manetek."
            )
            self._open_device_manager()
            return

        if hasattr(self.btn_action_launch, "set_text"):
            self.btn_action_launch.set_text("Łączenie z manetkami...", is_active=False, icon="link")
        elif self.btn_action_launch is not None:
            self.btn_action_launch.configure(text="Łączenie z manetkami...")

        is_click = (
            self.selected_hardware_model == "click"
            or self.cfg.get("hardware_model") == "click"
            or "Click" in self.cfg.get("device_mode", "")
            or "click" in self.cfg.get("model_right", "").lower()
        )
        if mac_l and mac_r and mac_l.upper() != mac_r.upper():
            self.ble.post_command("CONNECT_BOTH", mac_left=mac_l, mac_right=mac_r)
        elif is_click:
            # Zwift Click communicates via a single primary BLE link (Right slot)
            target_mac = mac_r or mac_l
            self.ble.post_command("CONNECT", role="right", address=target_mac, device_type="Zwift Click")
        elif mac_r:
            self.ble.post_command("CONNECT", role="right", address=mac_r, device_type="Zwift Play (Right)")
        elif mac_l:
            self.ble.post_command("CONNECT", role="left", address=mac_l, device_type="Zwift Play (Left)")

    def _on_disconnect_all(self):
        self.ble.post_command("DISCONNECT_ALL")
        self.connected_left = False
        self.connected_right = False
        self.battery_left = -1
        self.battery_right = -1
        self.connected_device_names["left"] = ""
        self.connected_device_names["right"] = ""
        self._update_connection_display()
        self.lbl_master_pill.configure(text="○ MOST ROZŁĄCZONY", bg="#111B28", fg="#94A3B8", highlightbackground="#1E2F46")
        if hasattr(self.btn_action_launch, "set_text"):
            self.btn_action_launch.set_text("Połącz i Uruchom MyWhoosh", is_active=False, icon="lightning")
        else:
            self.btn_action_launch.configure(text="⚡ Połącz i Uruchom MyWhoosh")
        if self.mini_overlay:
            self.mini_overlay.update_battery(-1, -1)
        self.is_play_disabled = False
        self.is_click_disabled = False
        self._update_selector_buttons_ui()
        self._render_controller_diagram()

    def _open_device_manager(self):
        DeviceManagerDialog(self.root, self)

    def _open_logs_viewer(self):
        LogsViewerDialog(self.root, "\n".join(self.logs_cache))

    def _open_help_dialog(self):
        HelpDialog(self.root)

    def _open_click_diagnostic(self):
        if getattr(self, "active_diagnostic_dialog", None) is not None:
            try:
                if self.active_diagnostic_dialog.winfo_exists():
                    self.active_diagnostic_dialog.lift()
                    self.active_diagnostic_dialog.focus_force()
                    return
            except Exception:
                pass
        ClickDiagnosticDialog(self.root, self)

    def _on_device_mode_selected(self, event=None):
        self.cfg["device_mode"] = self.combo_device_type.get()
        self.config_mgr.save()
        mode = self.combo_device_type.get()
        if "Play" in mode:
            self.selected_hardware_model = "play"
        else:
            self.selected_hardware_model = "click"

        if "Tylko Lewa" in mode:
            self.active_diagram_side = "left"
        elif "Tylko Prawa" in mode:
            self.active_diagram_side = "right"
        else:
            self.active_diagram_side = "both"
        self._update_selector_buttons_ui()
        self._render_controller_diagram()

    def _on_options_changed(self):
        self.shifter.sound_enabled = self.var_sound.get()
        self.cfg["sound_enabled"] = self.var_sound.get()
        self.cfg["haptic_enabled"] = self.var_haptic.get()
        self.config_mgr.save()

    def _toggle_mini_overlay(self):
        if self.mini_overlay is None or not self.mini_overlay.winfo_exists():
            self.mini_overlay = MiniOverlayWindow(self.root, self.shifter)
            self.mini_overlay.update_battery(self.battery_left, self.battery_right)
        else:
            self.mini_overlay.destroy()
            self.mini_overlay = None

    def _update_connection_display(self):
        mac_l = self.cfg.get("mac_left", "").strip()
        mac_r = self.cfg.get("mac_right", "").strip()
        if not self.connected_left:
            self.dot_left.configure(fg=TEXT_DIM, text="○")
            if mac_l:
                self.lbl_desc_left.configure(text=f"Rozłączono ({mac_l})", fg="#64748B")
            else:
                self.lbl_desc_left.configure(text="Rozłączono — naciśnij przycisk", fg="#64748B")
            self.lbl_bat_left.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
        if not self.connected_right:
            self.dot_right.configure(fg=TEXT_DIM, text="○")
            if mac_r:
                self.lbl_desc_right.configure(text=f"Rozłączono ({mac_r})", fg="#64748B")
            else:
                self.lbl_desc_right.configure(text="Rozłączono — naciśnij przycisk", fg="#64748B")
            self.lbl_bat_right.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")

    # ----------------------------------------------------
    # Event Processing from BLE Worker
    # ----------------------------------------------------
    def _process_events(self):
        try:
            while not self.event_queue.empty():
                evt = self.event_queue.get_nowait()
                etype = evt.get("event")

                if etype == "LOG":
                    msg = evt.get("message", "")
                    self.logs_cache.append(f"[{time.strftime('%H:%M:%S')}] {msg}")
                    if len(self.logs_cache) > 200:
                        self.logs_cache.pop(0)
                elif etype == "STATUS":
                    self._handle_status(
                        evt.get("role", "right"),
                        evt.get("status", ""),
                        evt.get("connected", False),
                        evt.get("device_name", ""),
                        evt.get("address", "")
                    )
                elif etype == "BATTERY":
                    role = evt.get("role", "right")
                    level = evt.get("level", -1)
                    if role == "left":
                        self.battery_left = level
                        if level >= 20:
                            self.lbl_bat_left.configure(text=f"🔋 {level}%", fg="#6EE7B7", bg="#064E3B", highlightbackground="#065F46")
                        elif level >= 0:
                            self.lbl_bat_left.configure(text=f"🪫 {level}%", fg="#FECDD3", bg="#881337", highlightbackground="#9F1239")
                        else:
                            self.lbl_bat_left.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
                    else:
                        self.battery_right = level
                        if level >= 20:
                            self.lbl_bat_right.configure(text=f"🔋 {level}%", fg="#6EE7B7", bg="#064E3B", highlightbackground="#065F46")
                        elif level >= 0:
                            self.lbl_bat_right.configure(text=f"🪫 {level}%", fg="#FECDD3", bg="#881337", highlightbackground="#9F1239")
                        else:
                            self.lbl_bat_right.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
                    if self.mini_overlay:
                        self.mini_overlay.update_battery(self.battery_left, self.battery_right)
                elif etype == "BUTTON_CHANGE":
                    if getattr(self, "active_diagnostic_dialog", None) is not None:
                        try:
                            if self.active_diagnostic_dialog.winfo_exists():
                                self.active_diagnostic_dialog.on_button_event(evt)
                        except Exception as e:
                            print(f"[Diag Button Error] {e}")

                    self._handle_button_change(
                        evt.get("role", "right"),
                        evt.get("pad", "Right"),
                        evt.get("button", ""),
                        evt.get("pressed", False)
                    )
                elif etype == "BLE_PACKET_SNIFF":
                    if getattr(self, "active_diagnostic_dialog", None) is not None:
                        try:
                            if self.active_diagnostic_dialog.winfo_exists():
                                self.active_diagnostic_dialog.on_packet_sniff(evt)
                        except Exception as e:
                            pass
                elif etype == "SCAN_RESULT":
                    devices = evt.get("devices", [])
                    self.scanned_devices = devices
                    for d in devices:
                        addr = d.get("address", "")
                        name = d.get("name", "")
                        dev_type = d.get("type", "")
                        if addr and name:
                            self.discovered_device_names[addr] = name
                            self.discovered_device_names[addr.upper()] = name
                            if "click" in dev_type.lower() or d.get("side") == "click":
                                self.discovered_device_names[addr.upper()] = "Zwift Click"
                    if getattr(self, "active_device_dialog", None) is not None:
                        try:
                            if self.active_device_dialog.winfo_exists():
                                self.active_device_dialog.on_scan_completed(devices)
                        except Exception as e:
                            print(f"[Dialog Notification Error] {e}")
        except Exception as e:
            print(f"[GUI Event Error] {e}")

        self.root.after(30, self._process_events)

    def _handle_status(self, role: str, status_text: str, connected: bool, device_name: str = "", address: str = ""):
        if getattr(self, "active_diagnostic_dialog", None) is not None:
            try:
                if self.active_diagnostic_dialog.winfo_exists():
                    self.active_diagnostic_dialog.on_status_change(role, status_text, connected)
            except Exception:
                pass

        is_left = (role == "left")
        dot = self.dot_left if is_left else self.dot_right
        desc = self.lbl_desc_left if is_left else self.lbl_desc_right

        if connected:
            dot.configure(fg=ACCENT_EMERALD, text="●")
            desc.configure(text="Połączono i zaszyfrowano", fg="#94A3B8")
            if is_left:
                self.connected_left = True
            else:
                self.connected_right = True

            if not device_name and address:
                device_name = self.discovered_device_names.get(address, "")
            if not device_name:
                device_name = self.cfg.get(f"name_{role}", "")
            self.connected_device_names[role] = device_name
            self._check_connected_hardware_models()

            # For Zwift Click: the left pod pairs wirelessly through the right pod (only if right pod is a Click)
            is_click_device = "click" in (device_name or "").lower() or (
                self.selected_hardware_model == "click"
                and "play" not in (device_name or "").lower()
                and not self.cfg.get("mac_left")
            )
            if not is_left and is_click_device:
                self.connected_left = True
                self.dot_left.configure(fg=ACCENT_EMERALD, text="●")
                self.lbl_desc_left.configure(text="Zlinkowana z prawą manetką", fg="#94A3B8")
                self.connected_device_names["left"] = "Zwift Click (Lewa)"
        elif "..." in status_text:
            dot.configure(fg=ACCENT_AMBER, text="●")
            desc.configure(text=status_text, fg="#FBBF24")
            if "WZNAWIANIE" in status_text.upper():
                if is_left:
                    self.connected_left = False
                    self.battery_left = -1
                    self.lbl_bat_left.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
                else:
                    self.connected_right = False
                    self.battery_right = -1
                    self.lbl_bat_right.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
                if not is_left and (self.selected_hardware_model == "click" and not self.cfg.get("mac_left")):
                    self.connected_left = False
                    self.battery_left = -1
                    self.lbl_bat_left.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
                if self.mini_overlay:
                    self.mini_overlay.update_battery(self.battery_left, self.battery_right)
            if not is_left and (self.selected_hardware_model == "click" and not self.cfg.get("mac_left")):
                self.dot_left.configure(fg=ACCENT_AMBER, text="●")
                self.lbl_desc_left.configure(text="Oczekiwanie na link BLE...", fg="#FBBF24")
        else:
            dot.configure(fg=TEXT_DIM, text="○")
            desc.configure(text="Rozłączono — naciśnij przycisk", fg="#64748B")
            if is_left:
                self.connected_left = False
                self.battery_left = -1
                self.lbl_bat_left.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
            else:
                self.connected_right = False
                self.battery_right = -1
                self.lbl_bat_right.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
            self.connected_device_names[role] = ""

            if not is_left and (self.selected_hardware_model == "click" and not self.cfg.get("mac_left")):
                self.connected_left = False
                self.battery_left = -1
                self.dot_left.configure(fg=TEXT_DIM, text="○")
                self.lbl_desc_left.configure(text="Rozłączono — naciśnij przycisk", fg="#64748B")
                self.lbl_bat_left.configure(text="🔋 --%", fg="#64748B", bg="#0E1724", highlightbackground="#1C2D44")
                self.connected_device_names["left"] = ""

            if self.mini_overlay:
                self.mini_overlay.update_battery(self.battery_left, self.battery_right)

            self._check_connected_hardware_models()

        if self.connected_left or self.connected_right:
            self.lbl_master_pill.configure(text="● MOST AKTYWNY", bg="#064E3B", fg="#6EE7B7", highlightbackground="#059669")
            if hasattr(self.btn_action_launch, "set_text"):
                self.btn_action_launch.set_text("PRZEJDŹ DO MYWHOOSH", is_active=True, icon="check")
            else:
                self.btn_action_launch.configure(text="✓ Most Aktywny • Przejdź do MyWhoosh")
        else:
            self.lbl_master_pill.configure(text="○ MOST ROZŁĄCZONY", bg="#111B28", fg="#94A3B8", highlightbackground="#1E2F46")
            if hasattr(self.btn_action_launch, "set_text"):
                self.btn_action_launch.set_text("Połącz i Uruchom MyWhoosh", is_active=False, icon="lightning")
            else:
                self.btn_action_launch.configure(text="⚡ Połącz i Uruchom MyWhoosh")

        self._render_controller_diagram()

    def _check_connected_hardware_models(self):
        """
        Automatically selects hardware model and manages locked/disabled states:
        - If Zwift Play is connected:
          * Automatically switch to 'play' model and re-render diagram.
          * Lock/disable 'Zwift Click' model button (is_click_disabled = True, is_play_disabled = False).
        - If Zwift Click is connected:
          * Automatically switch to 'click' model and re-render diagram.
          * Lock/disable 'Zwift Play' model button (is_play_disabled = True, is_click_disabled = False).
        - If all controllers are disconnected:
          * Unlock both model buttons (is_play_disabled = False, is_click_disabled = False).
        """
        has_click_connected = False
        has_play_connected = False
        has_any_connected = (self.connected_left or self.connected_right)

        if has_any_connected:
            for r in ("left", "right"):
                is_conn = (self.connected_left if r == "left" else self.connected_right)
                if is_conn:
                    name = self.connected_device_names.get(r, "")
                    mac = self.cfg.get(f"mac_{r}", "")
                    if not name and mac:
                        name = self.discovered_device_names.get(mac.strip().upper(), "") or self.discovered_device_names.get(mac, "")
                    if not name:
                        name = self.cfg.get(f"model_{r}", "")
                    name_low = (name or "").lower()
                    if "click" in name_low:
                        has_click_connected = True
                    elif "play" in name_low and (r != "left" or self.cfg.get("mac_left")):
                        has_play_connected = True

            # If both are connected via dual real BLE links with mac_left configured: definitely Zwift Play
            if not has_click_connected and (self.connected_left and self.connected_right and self.cfg.get("mac_left")):
                has_play_connected = True

        if has_click_connected:
            has_play_connected = False
            self.is_play_disabled = True
            self.is_click_disabled = False
            if self.selected_hardware_model != "click":
                self.selected_hardware_model = "click"
                self._sync_device_mode_config()
                self._render_controller_diagram()
                self._log_local("Wykryto kontroler Zwift Click: Zwift Click wybrany automatycznie, Zwift Play zablokowany.")
            self._update_selector_buttons_ui()
        elif has_play_connected:
            self.is_click_disabled = True
            self.is_play_disabled = False
            if self.selected_hardware_model != "play":
                self.selected_hardware_model = "play"
                self._sync_device_mode_config()
                self._render_controller_diagram()
                self._log_local("Wykryto kontroler Zwift Play: Zwift Play wybrany automatycznie, Zwift Click zablokowany.")
            self._update_selector_buttons_ui()
        else:
            if not has_any_connected:
                self.is_play_disabled = False
                self.is_click_disabled = False
                self._update_selector_buttons_ui()

    def _handle_button_change(self, role: str, pad: str, btn_id: str, is_pressed: bool):
        # The BLE connection role is the absolute source of truth (Left vs Right slot)
        side = "left" if role.lower() == "left" else "right"
        full_key = f"{side}_{btn_id}"

        # Animate / Flash Callout Bubble
        if full_key in self.callout_widgets:
            widget_dict = self.callout_widgets[full_key]
            frame = widget_dict["frame"]
            if is_pressed:
                frame.configure(bg="#064E3B", highlightbackground=ACCENT_EMERALD)
            else:
                frame.configure(bg=widget_dict["default_bg"], highlightbackground=BORDER_COLOR)

        # Animate / Flash Hotspot Ring on Photo/Canvas
        if full_key in self.canvas_shape_ids:
            shape_id = self.canvas_shape_ids[full_key]
            if is_pressed:
                self.canvas_diag.itemconfig(shape_id, fill=ACCENT_EMERALD, outline="#FFFFFF", width=3)
            else:
                orig_fill = self.callout_widgets.get(full_key, {}).get("default_fill", ACCENT_CYAN)
                self.canvas_diag.itemconfig(shape_id, fill="", outline=orig_fill, width=2)

        # Execute action on Press
        if is_pressed:
            if getattr(self, "active_diagnostic_dialog", None) is not None:
                # During diagnostic calibration wizard, do not trigger virtual gear shifts or key sends
                return

            # Software Debounce: filter rapid contact bounce and vibration ripple (150ms window)
            if not hasattr(self, "_last_button_press_times"):
                self._last_button_press_times = {}
            now = time.monotonic()
            btn_key = f"{side}_{btn_id}"
            if (now - self._last_button_press_times.get(btn_key, 0.0)) < 0.15:
                return
            self._last_button_press_times[btn_key] = now

            dev_name = self.connected_device_names.get(side, "").lower()
            is_click = ("click" in dev_name) or (getattr(self, "selected_hardware_model", "play") == "click" and "play" not in dev_name)
            map_key = ("click_left" if side == "left" else "click_right") if is_click else ("play_left" if side == "left" else "play_right")

            mapping_dict = self.cfg.get("mappings", {}).get(map_key, {})
            action_code = mapping_dict.get(btn_id)

            if action_code is None:
                if is_click:
                    def_map = DEFAULT_CLICK_LEFT_MAPPING if side == "left" else DEFAULT_CLICK_RIGHT_MAPPING
                else:
                    def_map = DEFAULT_PLAY_LEFT_MAPPING if side == "left" else DEFAULT_PLAY_RIGHT_MAPPING
                action_code = def_map.get(btn_id, "NONE")

            if action_code and action_code != "NONE":
                self._execute_action(action_code, f"{side.upper()} {btn_id}", target_role=side)

    def _execute_action(self, action_code: str, source_btn: str, target_role: str = "right"):
        timestr = time.strftime("%H:%M:%S")
        action_name = AVAILABLE_ACTIONS.get(action_code, action_code)
        scancode_hex = "0x25" if "UP" in action_code else ("0x17" if "DOWN" in action_code else "0x00")
        if action_code in ["EMOTE_1", "EMOTE_2", "EMOTE_3", "EMOTE_4", "EMOTE_5"]:
            scancode_hex = hex(SCANCODES.get(action_code.split("_")[1], 0))
        elif action_code == "CAMERA":
            scancode_hex = hex(SCANCODES.get("C", 0))
        elif action_code == "UTURN":
            scancode_hex = hex(SCANCODES.get("U", 0))
        elif action_code in ("MENU", "ESC"):
            scancode_hex = hex(SCANCODES.get("ESC", 0))
        elif action_code in ("SPACE", "PAUSE_WORKOUT"):
            scancode_hex = hex(SCANCODES.get("SPACE", 0))
        elif action_code == "MENU_AND_PAUSE":
            scancode_hex = "0x01 + 0x39"
        elif action_code == "ENTER":
            scancode_hex = hex(SCANCODES.get("ENTER", 0))
        elif action_code == "TAB":
            scancode_hex = hex(SCANCODES.get("TAB", 0))
        elif action_code == "ARROW_UP":
            scancode_hex = hex(SCANCODES.get("UP", 0))
        elif action_code == "ARROW_DOWN":
            scancode_hex = hex(SCANCODES.get("DOWN", 0))
        elif action_code == "ARROW_LEFT":
            scancode_hex = hex(SCANCODES.get("LEFT", 0))
        elif action_code == "ARROW_RIGHT":
            scancode_hex = hex(SCANCODES.get("RIGHT", 0))

        self.lbl_last_action.configure(text=f"🟢 [{source_btn}] → {action_name}")
        if hasattr(self, "lbl_last_action_sub"):
            self.lbl_last_action_sub.configure(text=f"Godzina: {timestr} • Hardware Scancode {scancode_hex}")

        is_click = (self.selected_hardware_model == "click" or "Click" in self.cfg.get("device_mode", ""))

        if action_code == "SHIFT_UP":
            self.shifter.shift_up(1)
            if self.var_haptic.get() and not is_click:
                self.ble.post_command("HAPTIC", role=target_role, pattern=1)
        elif action_code == "SHIFT_DOWN":
            self.shifter.shift_down(1)
            if self.var_haptic.get() and not is_click:
                self.ble.post_command("HAPTIC", role=target_role, pattern=1)
        elif action_code == "SHIFT_UP_2":
            self.shifter.shift_up(2)
            if self.var_haptic.get() and not is_click:
                self.ble.post_command("HAPTIC", role=target_role, pattern=2)
        elif action_code == "SHIFT_DOWN_2":
            self.shifter.shift_down(2)
            if self.var_haptic.get() and not is_click:
                self.ble.post_command("HAPTIC", role=target_role, pattern=2)
        elif action_code and action_code != "NONE":
            def _dispatch_key():
                focus_mywhoosh()
                if action_code == "EMOTE_1": send_hardware_key(SCANCODES["1"], vk=VK_CODES.get("1"))
                elif action_code == "EMOTE_2": send_hardware_key(SCANCODES["2"], vk=VK_CODES.get("2"))
                elif action_code == "EMOTE_3": send_hardware_key(SCANCODES["3"], vk=VK_CODES.get("3"))
                elif action_code == "EMOTE_4": send_hardware_key(SCANCODES["4"], vk=VK_CODES.get("4"))
                elif action_code == "EMOTE_5": send_hardware_key(SCANCODES["5"], vk=VK_CODES.get("5"))
                elif action_code == "CAMERA": send_hardware_key(SCANCODES["C"], vk=VK_CODES.get("C"))
                elif action_code == "UTURN": send_hardware_key(SCANCODES["U"], vk=VK_CODES.get("U"))
                elif action_code == "MENU": trigger_mywhoosh_pause_or_menu(mode="auto")
                elif action_code == "PAUSE_WORKOUT": trigger_mywhoosh_pause_or_menu(mode="space")
                elif action_code == "MENU_AND_PAUSE": trigger_mywhoosh_pause_or_menu(mode="both")
                elif action_code == "ESC": send_hardware_key(SCANCODES["ESC"], duration=0.07, vk=VK_CODES.get("ESC"))
                elif action_code == "SPACE": send_hardware_key(SCANCODES["SPACE"], vk=VK_CODES.get("SPACE"))
                elif action_code == "ENTER": send_hardware_key(SCANCODES["ENTER"], vk=VK_CODES.get("ENTER"))
                elif action_code == "TAB": send_hardware_key(SCANCODES["TAB"], vk=VK_CODES.get("TAB"))
                elif action_code == "ARROW_UP": send_hardware_key(SCANCODES["UP"], vk=VK_CODES.get("UP"))
                elif action_code == "ARROW_DOWN": send_hardware_key(SCANCODES["DOWN"], vk=VK_CODES.get("DOWN"))
                elif action_code == "ARROW_LEFT": send_hardware_key(SCANCODES["LEFT"], vk=VK_CODES.get("LEFT"))
                elif action_code == "ARROW_RIGHT": send_hardware_key(SCANCODES["RIGHT"], vk=VK_CODES.get("RIGHT"))

            threading.Thread(target=_dispatch_key, daemon=True).start()

    def _log_local(self, text: str):
        self.logs_cache.append(f"[{time.strftime('%H:%M:%S')}] {text}")
        if len(self.logs_cache) > 200:
            self.logs_cache.pop(0)

    def _on_close(self):
        self.config_mgr.save()
        self.ble.stop()
        self.root.destroy()
