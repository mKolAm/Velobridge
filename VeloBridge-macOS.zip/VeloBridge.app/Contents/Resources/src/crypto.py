"""
VeloBridge - Zwift Cryptographic Layer
Implements ECDH (SECP256R1), HKDF-SHA256, and AES-256-CCM according to
the reverse-engineered Zwift Play / Click BLE protocol.
"""

from typing import Tuple, Optional
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESCCM


class ZwiftCryptoSession:
    """
    Manages key exchange and bidirectional AES-CCM encryption
    for a single Zwift controller session.
    """

    def __init__(self):
        # Generate local ECDH private key on SECP256R1 (NIST P-256)
        self.private_key = ec.generate_private_key(ec.SECP256R1())
        # Export uncompressed public key: strip leading 0x04 format byte to get 64 bytes
        full_pub = self.private_key.public_key().public_bytes(
            encoding=serialization.Encoding.X962,
            format=serialization.PublicFormat.UncompressedPoint
        )
        self.app_public_key_raw = full_pub[1:]  # 64 bytes (X || Y)
        
        self.device_public_key_raw: Optional[bytes] = None
        self.shared_secret: Optional[bytes] = None
        self.derived_key: Optional[bytes] = None
        self.aes_key: Optional[bytes] = None
        self.nonce_prefix: Optional[bytes] = None
        self.aes_ccm: Optional[AESCCM] = None
        
        # Outgoing frame counter for commands sent to the controller (e.g. haptics)
        self.out_counter = 1

    def get_handshake_request(self) -> bytes:
        """
        Creates the 72-byte payload to send to the Control Point characteristic:
        b"RideOn\x01\x02" + 64-byte app_public_key
        """
        return b"RideOn\x01\x02" + self.app_public_key_raw

    def complete_handshake(self, device_response: bytes) -> bool:
        """
        Processes device handshake response from Command Response characteristic.
        Expected format: b"RideOn\x00\x09" (or similar 8 bytes header) + 64 bytes device public key.
        Returns True if session is successfully established.
        """
        if len(device_response) < 72:
            # Some devices may return without 8-byte prefix if already established
            if len(device_response) == 64:
                dev_pub = device_response
            else:
                return False
        else:
            dev_pub = device_response[8:72]

        self.device_public_key_raw = dev_pub

        try:
            # Reconstruct elliptic curve point on SECP256R1 by prepending 0x04 uncompressed marker
            peer_key_obj = ec.EllipticCurvePublicKey.from_encoded_point(
                ec.SECP256R1(),
                b"\x04" + dev_pub
            )
            # Compute ECDH shared secret (32 bytes)
            self.shared_secret = self.private_key.exchange(ec.ECDH(), peer_key_obj)

            # Salt is the concatenation: device_public_key + app_public_key (128 bytes)
            salt = self.device_public_key_raw + self.app_public_key_raw

            # Derive 36-byte symmetric key material via HKDF-SHA256
            hkdf = HKDF(
                algorithm=hashes.SHA256(),
                length=36,
                salt=salt,
                info=b""
            )
            self.derived_key = hkdf.derive(self.shared_secret)

            # 32 bytes AES-256 key + 4 bytes nonce prefix
            self.aes_key = self.derived_key[:32]
            self.nonce_prefix = self.derived_key[32:36]

            # AES-CCM with 4-byte MIC (Message Integrity Check)
            self.aes_ccm = AESCCM(self.aes_key, tag_length=4)
            return True

        except Exception as ex:
            print(f"[Crypto] Handshake computation error: {ex}")
            return False

    def is_ready(self) -> bool:
        return self.aes_ccm is not None

    def decrypt_packet(self, raw_data: bytes) -> Optional[Tuple[int, bytes]]:
        """
        Decrypts an incoming notification packet from Measurement characteristic.
        Format:
          - 4 bytes: Little-endian frame counter
          - N bytes: Encrypted payload
          - 4 bytes: MIC / MAC tag
        Total minimum length: 4 (counter) + 0 + 4 (mic) = 8 bytes.
        Returns: (counter, decrypted_payload) or None on verification error.
        """
        if not self.aes_ccm or len(raw_data) < 8:
            return None

        counter_bytes = raw_data[:4]
        counter = int.from_bytes(counter_bytes, byteorder="little")
        ciphertext_and_tag = raw_data[4:]

        # 8-byte nonce: 4-byte prefix from HKDF key + 4-byte packet counter
        nonce = self.nonce_prefix + counter_bytes

        try:
            plaintext = self.aes_ccm.decrypt(nonce, ciphertext_and_tag, associated_data=None)
            return counter, plaintext
        except Exception:
            # AES-CCM authentication failed
            return None

    def encrypt_command(self, plaintext: bytes) -> bytes:
        """
        Encrypts an outgoing command to be written to Control Point characteristic.
        Returns: 4-byte counter + encrypted payload + 4-byte MIC tag.
        """
        if not self.aes_ccm:
            raise RuntimeError("Crypto session is not initialized")

        counter = self.out_counter
        self.out_counter += 1
        counter_bytes = counter.to_bytes(4, byteorder="little")
        nonce = self.nonce_prefix + counter_bytes

        ciphertext_and_tag = self.aes_ccm.encrypt(nonce, plaintext, associated_data=None)
        return counter_bytes + ciphertext_and_tag
