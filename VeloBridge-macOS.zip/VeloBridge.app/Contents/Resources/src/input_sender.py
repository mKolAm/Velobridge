"""
VeloBridge - Cross-Platform Input Sender & Shifter Audio Engine (Windows & macOS)
Simulates hardware scancodes / Quartz CGEvent keystrokes into MyWhoosh (Unreal Engine compatible)
and plays crisp mechanical gear shift sound effects.
"""

import ctypes
import time
import threading
import wave
import io
import math
import struct
import subprocess
import os
import sys
import glob
import json
import tempfile
from typing import Optional, Dict, Any, Tuple

IS_WINDOWS = sys.platform == "win32"
IS_MACOS = sys.platform == "darwin"

if IS_WINDOWS:
    import winsound
    import winreg

# Windows SendInput structures (defined cross-platform for type compatibility)
PUL = ctypes.POINTER(ctypes.c_ulong)


class KeyBdInput(ctypes.Structure):
    _fields_ = [
        ("wVk", ctypes.c_ushort),
        ("wScan", ctypes.c_ushort),
        ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", PUL)
    ]


class HardwareInput(ctypes.Structure):
    _fields_ = [
        ("uMsg", ctypes.c_ulong),
        ("wParamL", ctypes.c_short),
        ("wParamH", ctypes.c_ushort)
    ]


class MouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long),
        ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_ulong),
        ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", PUL)
    ]


class Input_I(ctypes.Union):
    _fields_ = [
        ("ki", KeyBdInput),
        ("mi", MouseInput),
        ("hi", HardwareInput)
    ]


class Input(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_ulong),
        ("ii", Input_I)
    ]


KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008
KEYEVENTF_EXTENDEDKEY = 0x0001

# Common Hardware Scan Codes (used as canonical key identifiers across VeloBridge)
SCANCODES: Dict[str, int] = {
    # Letters
    "A": 0x1E, "B": 0x30, "C": 0x2E, "D": 0x20, "E": 0x12, "F": 0x21,
    "G": 0x22, "H": 0x23, "I": 0x17, "J": 0x24, "K": 0x25, "L": 0x26,
    "M": 0x32, "N": 0x31, "O": 0x18, "P": 0x19, "Q": 0x10, "R": 0x13,
    "S": 0x1F, "T": 0x14, "U": 0x16, "V": 0x2F, "W": 0x11, "X": 0x2D,
    "Y": 0x15, "Z": 0x2C,
    # Numbers
    "1": 0x02, "2": 0x03, "3": 0x04, "4": 0x05, "5": 0x06,
    "6": 0x07, "7": 0x08, "8": 0x09, "9": 0x0A, "0": 0x0B,
    # Specials
    "ESC": 0x01, "SPACE": 0x39, "ENTER": 0x1C, "TAB": 0x0F,
    "BACKSPACE": 0x0E, "LEFT_SHIFT": 0x2A,
    # Arrows (extended)
    "UP": 0xE048, "DOWN": 0xE050, "LEFT": 0xE04B, "RIGHT": 0xE04D,
}

# Windows Virtual-Key Codes (wVk) for hybrid DirectInput + Slate/UWP compatibility
VK_CODES: Dict[str, int] = {
    "A": 0x41, "B": 0x42, "C": 0x43, "D": 0x44, "E": 0x45, "F": 0x46,
    "G": 0x47, "H": 0x48, "I": 0x49, "J": 0x4A, "K": 0x4B, "L": 0x4C,
    "M": 0x4D, "N": 0x4E, "O": 0x4F, "P": 0x50, "Q": 0x51, "R": 0x52,
    "S": 0x53, "T": 0x54, "U": 0x55, "V": 0x56, "W": 0x57, "X": 0x58,
    "Y": 0x59, "Z": 0x5A,
    "1": 0x31, "2": 0x32, "3": 0x33, "4": 0x34, "5": 0x35,
    "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39, "0": 0x30,
    "ESC": 0x1B, "SPACE": 0x20, "ENTER": 0x0D, "TAB": 0x09,
    "BACKSPACE": 0x08, "LEFT_SHIFT": 0x10,
    "UP": 0x26, "DOWN": 0x28, "LEFT": 0x25, "RIGHT": 0x27,
}

# macOS Quartz Virtual Key Codes (CGKeyCode from <Carbon/HIToolbox/Events.h>)
MACOS_KEYCODES: Dict[str, int] = {
    "A": 0x00, "S": 0x01, "D": 0x02, "F": 0x03, "H": 0x04, "G": 0x05,
    "Z": 0x06, "X": 0x07, "C": 0x08, "V": 0x09, "B": 0x0B, "Q": 0x0C,
    "W": 0x0D, "E": 0x0E, "R": 0x0F, "Y": 0x10, "T": 0x11,
    "1": 0x12, "2": 0x13, "3": 0x14, "4": 0x15, "6": 0x16, "5": 0x17,
    "9": 0x19, "7": 0x1A, "8": 0x1C, "0": 0x1D,
    "O": 0x1F, "U": 0x20, "I": 0x22, "P": 0x23, "ENTER": 0x24,
    "L": 0x25, "J": 0x26, "K": 0x28, "N": 0x2D, "M": 0x2E,
    "TAB": 0x30, "SPACE": 0x31, "BACKSPACE": 0x33, "ESC": 0x35,
    "LEFT_SHIFT": 0x38,
    "LEFT": 0x7B, "RIGHT": 0x7C, "DOWN": 0x7D, "UP": 0x7E,
}

# Lookup from Windows SCANCODE int -> macOS CGKeyCode int
SCANCODE_TO_MACOS: Dict[int, int] = {
    SCANCODES[k]: MACOS_KEYCODES[k]
    for k in SCANCODES
    if k in MACOS_KEYCODES
}

# Cached macOS CoreGraphics / CoreFoundation libraries for zero-latency key events
_mac_cg_lib = None
_mac_cf_lib = None
_mac_libs_initialized = False


class _CGPoint(ctypes.Structure):
    _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]


def _get_macos_quartz_libs():
    """Lazily initializes and configures ctypes bindings for macOS ApplicationServices & CoreFoundation."""
    global _mac_cg_lib, _mac_cf_lib, _mac_libs_initialized
    if _mac_libs_initialized:
        return _mac_cg_lib, _mac_cf_lib

    _mac_libs_initialized = True
    if not IS_MACOS:
        return None, None

    try:
        cg = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices"
        )
        cf = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation"
        )

        # Keyboard events
        cg.CGEventCreateKeyboardEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint16, ctypes.c_bool]
        cg.CGEventCreateKeyboardEvent.restype = ctypes.c_void_p

        cg.CGEventPost.argtypes = [ctypes.c_uint32, ctypes.c_void_p]
        cg.CGEventPost.restype = None

        # Event source (kCGEventSourceStateCombinedSessionState = 0, kCGEventSourceStateHIDSystemState = 1)
        try:
            cg.CGEventSourceCreate.argtypes = [ctypes.c_int32]
            cg.CGEventSourceCreate.restype = ctypes.c_void_p
        except Exception:
            pass

        # Direct process injection (routes directly to MyWhoosh's process queue)
        try:
            cg.CGEventPostToPid.argtypes = [ctypes.c_int32, ctypes.c_void_p]
            cg.CGEventPostToPid.restype = None
        except Exception:
            pass

        # Unicode character string support (required by Unreal Engine / Slate input)
        try:
            cg.CGEventKeyboardSetUnicodeString.argtypes = [
                ctypes.c_void_p,
                ctypes.c_ulong,
                ctypes.POINTER(ctypes.c_uint16)
            ]
            cg.CGEventKeyboardSetUnicodeString.restype = None
        except Exception:
            pass

        # Mouse events
        cg.CGEventCreate.argtypes = [ctypes.c_void_p]
        cg.CGEventCreate.restype = ctypes.c_void_p

        cg.CGEventGetLocation.argtypes = [ctypes.c_void_p]
        cg.CGEventGetLocation.restype = _CGPoint

        cg.CGEventCreateMouseEvent.argtypes = [
            ctypes.c_void_p,
            ctypes.c_uint32,
            _CGPoint,
            ctypes.c_uint32
        ]
        cg.CGEventCreateMouseEvent.restype = ctypes.c_void_p

        # Display dimensions
        cg.CGMainDisplayID.argtypes = []
        cg.CGMainDisplayID.restype = ctypes.c_uint32
        cg.CGDisplayPixelsWide.argtypes = [ctypes.c_uint32]
        cg.CGDisplayPixelsWide.restype = ctypes.c_size_t
        cg.CGDisplayPixelsHigh.argtypes = [ctypes.c_uint32]
        cg.CGDisplayPixelsHigh.restype = ctypes.c_size_t

        # Accessibility check
        cg.AXIsProcessTrusted.argtypes = []
        cg.AXIsProcessTrusted.restype = ctypes.c_bool

        cf.CFRelease.argtypes = [ctypes.c_void_p]
        cf.CFRelease.restype = None

        _mac_cg_lib = cg
        _mac_cf_lib = cf
    except Exception as e:
        print(f"[macOS Quartz Init Warning] {e}")
        _mac_cg_lib = None
        _mac_cf_lib = None

    return _mac_cg_lib, _mac_cf_lib


def check_macos_accessibility_permission(prompt: bool = False) -> bool:
    """
    Checks whether VeloBridge has macOS Accessibility (Dostępność) permission required
    to post hardware keystrokes (CGEventPost) to MyWhoosh.
    Always returns True on Windows.
    """
    if not IS_MACOS:
        return True
    try:
        cg, _ = _get_macos_quartz_libs()
        if cg:
            trusted = bool(cg.AXIsProcessTrusted())
            if not trusted and prompt:
                # Open macOS Accessibility settings pane directly so user can toggle VeloBridge
                subprocess.Popen([
                    "open",
                    "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"
                ])
            return trusted
    except Exception:
        pass
    return True


# Mapping from macOS CGKeyCode to representative Unicode character for Unreal Engine
MACOS_KEYCODE_TO_CHAR: Dict[int, str] = {
    0x00: "a", 0x01: "s", 0x02: "d", 0x03: "f", 0x04: "h", 0x05: "g",
    0x06: "z", 0x07: "x", 0x08: "c", 0x09: "v", 0x0B: "b", 0x0C: "q",
    0x0D: "w", 0x0E: "e", 0x0F: "r", 0x10: "y", 0x11: "t", 0x12: "1",
    0x13: "2", 0x14: "3", 0x15: "4", 0x16: "6", 0x17: "5", 0x19: "9",
    0x1A: "7", 0x1C: "8", 0x1D: "0", 0x1F: "o", 0x20: "u", 0x22: "i",
    0x23: "p", 0x24: "\r", 0x25: "l", 0x26: "j", 0x28: "k", 0x2D: "n",
    0x2E: "m", 0x30: "\t", 0x31: " ", 0x33: "\x08", 0x35: "\x1b",
}


def scancode_to_macos_keycode(scancode: int, vk: Optional[int] = None) -> Optional[int]:
    """Maps a Windows hardware scancode (or VK code) to a macOS Quartz CGKeyCode."""
    if scancode in SCANCODE_TO_MACOS:
        return SCANCODE_TO_MACOS[scancode]
    if vk is not None:
        for k, v in VK_CODES.items():
            if v == vk and k in MACOS_KEYCODES:
                return MACOS_KEYCODES[k]
    return None


def _send_macos_key(cg_keycode: int, duration: float = 0.05, char: Optional[str] = None) -> bool:
    """
    Sends a low-level key press and release on macOS via Quartz Event Services.
    Uses kCGSessionEventTap (1) for standard user-space session delivery,
    attaches Unicode character string for Unreal Engine / Slate compatibility,
    and dispatches via CGEventPostToPid if MyWhoosh is running.
    """
    cg, cf = _get_macos_quartz_libs()
    posted_quartz = False

    if cg and cf:
        try:
            # Create session event source (kCGEventSourceStateCombinedSessionState = 0)
            src = None
            if hasattr(cg, "CGEventSourceCreate"):
                try:
                    src = cg.CGEventSourceCreate(0)
                except Exception:
                    src = None

            ev_down = cg.CGEventCreateKeyboardEvent(src, cg_keycode, True)
            ev_up = cg.CGEventCreateKeyboardEvent(src, cg_keycode, False)

            if ev_down and ev_up:
                # Set Unicode character string if available (Unreal Engine / Slate requirement)
                if not char and cg_keycode in MACOS_KEYCODE_TO_CHAR:
                    char = MACOS_KEYCODE_TO_CHAR[cg_keycode]

                if char and hasattr(cg, "CGEventKeyboardSetUnicodeString"):
                    try:
                        u_buf = (ctypes.c_uint16 * len(char))(*[ord(c) for c in char])
                        cg.CGEventKeyboardSetUnicodeString(ev_down, len(char), u_buf)
                        cg.CGEventKeyboardSetUnicodeString(ev_up, len(char), u_buf)
                    except Exception:
                        pass

                # Find MyWhoosh PID for targeted process delivery
                target_pid = find_mywhoosh_window()

                # Dispatch KEY DOWN:
                # kCGSessionEventTap = 1 (Standard user login session tap, routes to focused foreground window)
                kCGSessionEventTap = 1
                cg.CGEventPost(kCGSessionEventTap, ev_down)

                # Direct PID injection into MyWhoosh process queue (works in full screen & background)
                if target_pid and hasattr(cg, "CGEventPostToPid"):
                    try:
                        cg.CGEventPostToPid(int(target_pid), ev_down)
                    except Exception:
                        pass

                time.sleep(duration)

                # Dispatch KEY UP:
                cg.CGEventPost(kCGSessionEventTap, ev_up)

                if target_pid and hasattr(cg, "CGEventPostToPid"):
                    try:
                        cg.CGEventPostToPid(int(target_pid), ev_up)
                    except Exception:
                        pass

                cf.CFRelease(ev_down)
                cf.CFRelease(ev_up)
                if src:
                    cf.CFRelease(src)

                posted_quartz = True
        except Exception as e:
            print(f"[macOS Key Send Warning] {e}")

    # If Quartz successfully ran and process has accessibility permission, return True
    if posted_quartz and check_macos_accessibility_permission(prompt=False):
        return True

    # Fallback via AppleScript System Events (routes directly to MyWhoosh if running)
    try:
        if not char and cg_keycode in MACOS_KEYCODE_TO_CHAR:
            char = MACOS_KEYCODE_TO_CHAR[cg_keycode]

        script = (
            f'tell application "System Events"\n'
            f'  set procList to (every process whose name contains "MyWhoosh")\n'
            f'  if (count of procList) > 0 then\n'
            f'    tell item 1 of procList to key code {int(cg_keycode)}\n'
            f'  else\n'
            f'    key code {int(cg_keycode)}\n'
            f'  end if\n'
            f'end tell'
        )
        subprocess.run(
            ["osascript", "-e", script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=1.0
        )
        return True
    except Exception:
        return False


def send_hardware_key(scancode: int, duration: float = 0.05, vk: Optional[int] = None):
    """
    Sends a key press and release event using:
    - Windows: Hardware Scan Code + Virtual-Key Code via Win32 SendInput
    - macOS: Quartz HID Event Tap (CGEventCreateKeyboardEvent + CGEventPost)
    """
    if IS_MACOS:
        cg_code = scancode_to_macos_keycode(scancode, vk)
        if cg_code is not None:
            _send_macos_key(cg_code, duration=duration)
        return

    if not IS_WINDOWS:
        return

    is_extended = (scancode & 0xFF00) == 0xE000
    clean_scan = scancode & 0x00FF

    press_flags = KEYEVENTF_SCANCODE
    release_flags = KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP
    if is_extended:
        press_flags |= KEYEVENTF_EXTENDEDKEY
        release_flags |= KEYEVENTF_EXTENDEDKEY

    if vk is None:
        try:
            vk = ctypes.windll.user32.MapVirtualKeyW(clean_scan, 1)  # MAPVK_VSC_TO_VK
        except Exception:
            vk = 0

    extra = ctypes.c_ulong(0)
    inp_down = Input(
        type=ctypes.c_ulong(1),
        ii=Input_I(ki=KeyBdInput(vk or 0, clean_scan, press_flags, 0, ctypes.pointer(extra)))
    )
    inp_up = Input(
        type=ctypes.c_ulong(1),
        ii=Input_I(ki=KeyBdInput(vk or 0, clean_scan, release_flags, 0, ctypes.pointer(extra)))
    )

    ctypes.windll.user32.SendInput(1, ctypes.pointer(inp_down), ctypes.sizeof(inp_down))
    time.sleep(duration)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(inp_up), ctypes.sizeof(inp_up))


def _generate_shift_sound_wav(shift_up: bool = True) -> bytes:
    """Generates a crisp mechanical derailleur shift sound in memory (WAV format)."""
    sample_rate = 44100
    duration = 0.045
    num_samples = int(sample_rate * duration)
    buf = io.BytesIO()

    base_freq1 = 1400.0 if shift_up else 950.0
    base_freq2 = 2800.0 if shift_up else 1900.0

    with wave.open(buf, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        frames = bytearray()
        for i in range(num_samples):
            t = i / sample_rate
            env = math.exp(-t * 85.0)
            f1 = base_freq1 * math.exp(-t * 35.0)
            f2 = base_freq2 * math.exp(-t * 50.0)
            sample = 0.6 * math.sin(2 * math.pi * f1 * t) + 0.4 * math.sin(2 * math.pi * f2 * t)
            val = int(sample * env * 32767 * 0.75)
            frames.extend(struct.pack('<h', max(-32768, min(32767, val))))
        wav.writeframes(frames)
    return buf.getvalue()


_WAV_SHIFT_UP = _generate_shift_sound_wav(shift_up=True)
_WAV_SHIFT_DOWN = _generate_shift_sound_wav(shift_up=False)
_MAC_WAV_PATHS: Dict[bool, str] = {}


def _get_macos_wav_path(shift_up: bool) -> str:
    """Caches in-memory WAV bytes to a temporary file for macOS afplay playback."""
    if shift_up in _MAC_WAV_PATHS and os.path.exists(_MAC_WAV_PATHS[shift_up]):
        return _MAC_WAV_PATHS[shift_up]
    fname = "velobridge_shift_up.wav" if shift_up else "velobridge_shift_down.wav"
    fpath = os.path.join(tempfile.gettempdir(), fname)
    try:
        with open(fpath, "wb") as f:
            f.write(_WAV_SHIFT_UP if shift_up else _WAV_SHIFT_DOWN)
        _MAC_WAV_PATHS[shift_up] = fpath
    except Exception:
        pass
    return fpath


def play_shift_sound(shift_up: bool = True):
    """Plays the mechanical gear shift sound in a non-blocking background thread."""
    wav_bytes = _WAV_SHIFT_UP if shift_up else _WAV_SHIFT_DOWN

    def _worker():
        try:
            if IS_WINDOWS:
                winsound.PlaySound(wav_bytes, winsound.SND_MEMORY)
            elif IS_MACOS:
                wav_path = _get_macos_wav_path(shift_up)
                if os.path.exists(wav_path):
                    subprocess.run(
                        ["afplay", wav_path],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        timeout=1.5
                    )
        except Exception:
            pass

    threading.Thread(target=_worker, daemon=True).start()


def find_mywhoosh_window() -> Optional[int]:
    """
    Finds the main handle/PID of the running MyWhoosh game window (strictly excluding VeloBridge).
    Returns HWND (int) on Windows or PID (int) on macOS, or None if not running.
    """
    current_pid = os.getpid()

    if IS_MACOS:
        try:
            proc = subprocess.run(
                ["ps", "-ax", "-o", "pid=,args="],
                capture_output=True, text=True, timeout=2.0
            )
            if proc.returncode == 0:
                for line in proc.stdout.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split(None, 1)
                    if len(parts) < 2:
                        continue
                    try:
                        pid_val = int(parts[0])
                    except ValueError:
                        continue
                    if pid_val == current_pid:
                        continue
                    args_low = parts[1].lower()
                    if "velobridge" in args_low:
                        continue
                    if "mywhoosh" in args_low or "whoosh" in args_low:
                        return pid_val
        except Exception:
            pass
        return None

    if not IS_WINDOWS:
        return None

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    target_hwnd = None

    def enum_cb(hwnd, lparam):
        nonlocal target_hwnd
        if not user32.IsWindowVisible(hwnd):
            return True

        pid = ctypes.c_ulong()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == 0 or pid.value == current_pid:
            return True

        length = user32.GetWindowTextLengthW(hwnd)
        if length > 0:
            buff = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buff, length + 1)
            title = buff.value.lower()
            if "velobridge" in title:
                return True
            if "mywhoosh" in title:
                target_hwnd = hwnd
                return False

        # Fallback: check process name by PID
        h_proc = kernel32.OpenProcess(0x1000, False, pid.value)  # PROCESS_QUERY_LIMITED_INFORMATION
        if h_proc:
            name_buff = ctypes.create_unicode_buffer(1024)
            size = ctypes.c_ulong(1024)
            if kernel32.QueryFullProcessImageNameW(h_proc, 0, name_buff, ctypes.byref(size)):
                proc_path = name_buff.value.lower()
                base_name = os.path.basename(proc_path)
                if "velobridge" not in base_name and ("mywhoosh" in base_name or "mywhoosh" in proc_path):
                    target_hwnd = hwnd
                    kernel32.CloseHandle(h_proc)
                    return False
            kernel32.CloseHandle(h_proc)

        return True

    WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
    user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
    return target_hwnd


def focus_mywhoosh() -> bool:
    """Brings MyWhoosh to foreground if it is running."""
    hwnd = find_mywhoosh_window()
    if not hwnd:
        return False

    if IS_MACOS:
        try:
            script = (
                'tell application "System Events"\n'
                '  set procList to every process whose name contains "MyWhoosh"\n'
                '  if (count of procList) > 0 then\n'
                '    set frontmost of item 1 of procList to true\n'
                '    return "ok"\n'
                '  end if\n'
                'end tell'
            )
            res = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True, text=True, timeout=1.5
            )
            if res.returncode == 0 and "ok" in res.stdout:
                time.sleep(0.02)
                return True
            # Fallback via open -a
            subprocess.run(
                ["open", "-a", "MyWhoosh"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=1.5
            )
            return True
        except Exception:
            return False

    if not IS_WINDOWS:
        return False

    try:
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32

        fore_hwnd = user32.GetForegroundWindow()
        if fore_hwnd == hwnd:
            return True

        fore_thread = user32.GetWindowThreadProcessId(fore_hwnd, None)
        cur_thread = kernel32.GetCurrentThreadId()

        try:
            user32.AllowSetForegroundWindow(0xFFFFFFFF)  # ASFW_ANY
        except Exception:
            pass

        attached = False
        if fore_thread != cur_thread and fore_thread != 0:
            attached = bool(user32.AttachThreadInput(cur_thread, fore_thread, True))

        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        else:
            user32.ShowWindow(hwnd, 5)  # SW_SHOW

        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)

        if attached:
            user32.AttachThreadInput(cur_thread, fore_thread, False)

        time.sleep(0.02)
        return True
    except Exception:
        return False


def click_mywhoosh_menu_button(hwnd: Optional[int] = None) -> bool:
    """
    Simulates a wake-up mouse move and click on the bottom-left Menu / Pause button
    on the MyWhoosh in-game HUD, then immediately restores the user's cursor position.
    Supports both Windows (user32) and macOS (Quartz CGEvent).
    """
    if not hwnd:
        hwnd = find_mywhoosh_window()
    if not hwnd:
        return False

    if IS_MACOS:
        try:
            cg, cf = _get_macos_quartz_libs()
            if not cg or not cf:
                return False

            # Save original cursor position
            ev_cur = cg.CGEventCreate(None)
            if not ev_cur:
                return False
            orig_pt = cg.CGEventGetLocation(ev_cur)
            cf.CFRelease(ev_cur)

            # Query MyWhoosh window position & size via System Events if available, else main display
            win_x, win_y = 0.0, 0.0
            main_disp = cg.CGMainDisplayID()
            win_w = float(cg.CGDisplayPixelsWide(main_disp) or 1920)
            win_h = float(cg.CGDisplayPixelsHigh(main_disp) or 1080)

            try:
                script = (
                    'tell application "System Events"\n'
                    '  tell (first process whose name contains "MyWhoosh")\n'
                    '    if (count of windows) > 0 then\n'
                    '      set {wx, wy} to position of window 1\n'
                    '      set {ww, wh} to size of window 1\n'
                    '      return (wx as string) & "," & (wy as string) & "," & (ww as string) & "," & (wh as string)\n'
                    '    end if\n'
                    '  end tell\n'
                    'end tell'
                )
                r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=1.0)
                if r.returncode == 0 and "," in r.stdout:
                    vals = [float(x.strip()) for x in r.stdout.strip().split(",")]
                    if len(vals) == 4 and vals[2] > 100 and vals[3] > 100:
                        win_x, win_y, win_w, win_h = vals
            except Exception:
                pass

            target_x = win_x + max(32.0, win_w * 0.035)
            target_y = win_y + max(32.0, win_h * 0.945)
            pt_target = _CGPoint(target_x, target_y)

            kCGSessionEventTap = 1
            kCGEventMouseMoved = 5
            kCGEventLeftMouseDown = 1
            kCGEventLeftMouseUp = 2
            kCGMouseButtonLeft = 0

            # 1. Move cursor to wake HUD
            ev_move = cg.CGEventCreateMouseEvent(None, kCGEventMouseMoved, pt_target, kCGMouseButtonLeft)
            if ev_move:
                cg.CGEventPost(kCGSessionEventTap, ev_move)
                cf.CFRelease(ev_move)
            time.sleep(0.06)

            # 2. Left click
            ev_down = cg.CGEventCreateMouseEvent(None, kCGEventLeftMouseDown, pt_target, kCGMouseButtonLeft)
            ev_up = cg.CGEventCreateMouseEvent(None, kCGEventLeftMouseUp, pt_target, kCGMouseButtonLeft)
            if ev_down and ev_up:
                cg.CGEventPost(kCGSessionEventTap, ev_down)
                cf.CFRelease(ev_down)
                time.sleep(0.04)
                cg.CGEventPost(kCGSessionEventTap, ev_up)
                cf.CFRelease(ev_up)
            time.sleep(0.02)

            # 3. Restore original cursor position
            ev_restore = cg.CGEventCreateMouseEvent(None, kCGEventMouseMoved, orig_pt, kCGMouseButtonLeft)
            if ev_restore:
                cg.CGEventPost(kCGSessionEventTap, ev_restore)
                cf.CFRelease(ev_restore)
            return True
        except Exception:
            return False

    if not IS_WINDOWS:
        return False

    try:
        import ctypes.wintypes
        user32 = ctypes.windll.user32

        rect = ctypes.wintypes.RECT()
        if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
            return False

        width = rect.right - rect.left
        height = rect.bottom - rect.top
        if width <= 0 or height <= 0:
            return False

        # In-game HUD Menu button is anchored in the bottom-left corner (~3.5% X, ~94.5% Y)
        client_x = max(32, int(width * 0.035))
        client_y = max(32, int(height * 0.945))

        point = ctypes.wintypes.POINT(client_x, client_y)
        user32.ClientToScreen(hwnd, ctypes.byref(point))

        orig_pos = ctypes.wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(orig_pos))

        # 1. Move cursor & trigger micro-movement to wake up auto-hidden HUD
        user32.SetCursorPos(point.x, point.y)
        user32.mouse_event(0x0001, 1, 0, 0, 0)  # MOUSEEVENTF_MOVE
        time.sleep(0.06)

        # 2. Click the Menu button
        user32.mouse_event(0x0002, 0, 0, 0, 0)  # MOUSEEVENTF_LEFTDOWN
        time.sleep(0.04)
        user32.mouse_event(0x0004, 0, 0, 0, 0)  # MOUSEEVENTF_LEFTUP
        time.sleep(0.02)

        # 3. Restore original cursor position
        user32.SetCursorPos(orig_pos.x, orig_pos.y)
        return True
    except Exception:
        return False


def trigger_mywhoosh_pause_or_menu(mode: str = "auto") -> bool:
    """
    Reliably triggers Menu / Pause in MyWhoosh:
    1. Focuses the MyWhoosh game window so it receives input.
    2. Sends hardware ESC + VK_ESCAPE (0x1B) via SendInput / Quartz CGEvent.
    3. On Windows: Posts WM_KEYDOWN / WM_KEYUP (VK_ESCAPE) directly to the window handle.
    4. In 'auto' or 'both' mode: also wakes HUD and clicks the bottom-left Menu button
       (since MyWhoosh Free Ride often ignores Esc and requires clicking the HUD Menu icon).
    5. In 'space' or 'both' mode: also sends Spacebar (which pauses MyWhoosh structured workouts).
    """
    hwnd = find_mywhoosh_window()
    if hwnd:
        focus_mywhoosh()

    # 1. Send ESC via SendInput / CGEvent (hardware scan code 0x01 + VK_ESCAPE 0x1B)
    send_hardware_key(SCANCODES["ESC"], duration=0.07, vk=VK_CODES.get("ESC", 0x1B))

    # 2. Direct PostMessage fallback to window handle (Windows only)
    if IS_WINDOWS and hwnd:
        try:
            user32 = ctypes.windll.user32
            WM_KEYDOWN = 0x0100
            WM_KEYUP = 0x0101
            VK_ESCAPE = 0x1B
            lparam_down = 1 | (0x01 << 16)
            lparam_up = 1 | (0x01 << 16) | (1 << 30) | (1 << 31)
            user32.PostMessageW(hwnd, WM_KEYDOWN, VK_ESCAPE, lparam_down)
            time.sleep(0.03)
            user32.PostMessageW(hwnd, WM_KEYUP, VK_ESCAPE, lparam_up)
        except Exception:
            pass

    # 3. Click bottom-left HUD Menu button if MyWhoosh window is active
    if mode in ("auto", "both", "click") and hwnd:
        click_mywhoosh_menu_button(hwnd)

    # 4. Send Spacebar for Workout Pause
    if mode in ("space", "both"):
        time.sleep(0.03)
        send_hardware_key(SCANCODES["SPACE"], duration=0.07, vk=VK_CODES.get("SPACE", 0x20))
        if IS_WINDOWS and hwnd:
            try:
                user32 = ctypes.windll.user32
                WM_KEYDOWN = 0x0100
                WM_KEYUP = 0x0101
                VK_SPACE = 0x20
                lparam_sp_down = 1 | (0x39 << 16)
                lparam_sp_up = 1 | (0x39 << 16) | (1 << 30) | (1 << 31)
                user32.PostMessageW(hwnd, WM_KEYDOWN, VK_SPACE, lparam_sp_down)
                time.sleep(0.03)
                user32.PostMessageW(hwnd, WM_KEYUP, VK_SPACE, lparam_sp_up)
            except Exception:
                pass

    return True


def detect_mywhoosh(custom_path: Optional[str] = None) -> Optional[Dict[str, str]]:
    """
    Automatically detects MyWhoosh installation across Windows and macOS:
    1. Custom path specified in configuration (.exe, .lnk, or macOS .app bundle)
    2. Currently running MyWhoosh process (excluding VeloBridge)
    3. macOS: /Applications/MyWhoosh.app, ~/Applications/MyWhoosh.app, Mac App Store / Spotlight (mdfind)
    4. Windows: Microsoft Store (UWP / MSIX / AppX), Program Files, Registry, Start Menu / Desktop (.lnk)
    """
    # 1. Custom configured path
    if custom_path and os.path.exists(custom_path):
        base_c = os.path.basename(custom_path.rstrip("/\\")).lower()
        if "velobridge" not in base_c:
            if base_c.endswith(".app"):
                ftype = "app"
            elif base_c.endswith(".exe"):
                ftype = "file"
            else:
                ftype = "shortcut"
            return {
                "type": ftype,
                "target": custom_path,
                "display": custom_path,
                "source": "custom"
            }

    # 2. macOS detection path
    if IS_MACOS:
        # 2a. Check running process on macOS
        pid = find_mywhoosh_window()
        if pid:
            return {
                "type": "app",
                "target": "MyWhoosh",
                "display": f"MyWhoosh (Aktywny proces PID: {pid})",
                "source": "running"
            }

        # 2b. Check standard macOS /Applications and ~/Applications bundles
        mac_app_dirs = ["/Applications", os.path.expanduser("~/Applications")]
        preferred_names = ["MyWhoosh.app", "MyWhoosh HD.app", "MyWhoosh Indoor Cycling.app"]
        for adir in mac_app_dirs:
            for pname in preferred_names:
                cand = os.path.join(adir, pname)
                if os.path.exists(cand):
                    return {
                        "type": "app",
                        "target": cand,
                        "display": f"{pname} ({adir})",
                        "source": "applications"
                    }
            if os.path.isdir(adir):
                for entry in os.listdir(adir):
                    elow = entry.lower()
                    if "whoosh" in elow and "velobridge" not in elow and elow.endswith(".app"):
                        cand = os.path.join(adir, entry)
                        return {
                            "type": "app",
                            "target": cand,
                            "display": f"{entry} ({adir})",
                            "source": "applications"
                        }

        # 2c. Spotlight mdfind fallback (Mac App Store or external volume)
        try:
            proc = subprocess.run(
                ["mdfind", "kMDItemFSName == '*MyWhoosh*.app' || kMDItemCFBundleIdentifier == '*mywhoosh*'"],
                capture_output=True, text=True, timeout=2.5
            )
            if proc.returncode == 0 and proc.stdout.strip():
                for line in proc.stdout.splitlines():
                    p = line.strip()
                    if p.lower().endswith(".app") and "velobridge" not in p.lower() and os.path.exists(p):
                        return {
                            "type": "app",
                            "target": p,
                            "display": f"{os.path.basename(p)} (Mac App Store / Spotlight)",
                            "source": "spotlight"
                        }
        except Exception:
            pass

        return None

    if not IS_WINDOWS:
        return None

    # 3. Windows: Check running process executable (strictly excluding VeloBridge itself)
    try:
        kernel32 = ctypes.windll.kernel32
        user32 = ctypes.windll.user32
        current_pid = os.getpid()
        hwnd = find_mywhoosh_window()
        if hwnd:
            pid = ctypes.c_ulong()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value > 0 and pid.value != current_pid:
                h_proc = kernel32.OpenProcess(0x1000, False, pid.value)
                if h_proc:
                    buf = ctypes.create_unicode_buffer(1024)
                    size = ctypes.c_ulong(1024)
                    if kernel32.QueryFullProcessImageNameW(h_proc, 0, buf, ctypes.byref(size)):
                        exe_path = buf.value
                        base = os.path.basename(exe_path).lower()
                        if "velobridge" not in base and ("mywhoosh" in base or "whoosh" in base) and os.path.exists(exe_path):
                            kernel32.CloseHandle(h_proc)
                            return {
                                "type": "file",
                                "target": exe_path,
                                "display": f"MyWhoosh (Aktywny proces: {os.path.basename(exe_path)})",
                                "source": "running"
                            }
                    kernel32.CloseHandle(h_proc)
    except Exception:
        pass

    # 4. Windows: Microsoft Store / AppX / StartApps via PowerShell (strictly excluding VeloBridge)
    try:
        ps_cmd = 'Get-StartApps | Where-Object { ($_.Name -like "*whoosh*" -or $_.AppID -like "*whoosh*") -and $_.Name -notlike "*velobridge*" -and $_.AppID -notlike "*velobridge*" } | Select-Object -Property AppID, Name | ConvertTo-Json -Compress'
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps_cmd],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0 and proc.stdout.strip():
            raw = json.loads(proc.stdout.strip())
            if isinstance(raw, dict):
                raw = [raw]
            for item in raw:
                appid = item.get("AppID", "")
                name = item.get("Name", "MyWhoosh")
                if "prereq" not in appid.lower() and "prereq" not in name.lower() and "velobridge" not in appid.lower() and "velobridge" not in name.lower():
                    return {
                        "type": "store",
                        "target": f"shell:AppsFolder\\{appid}",
                        "display": f"{name} (Microsoft Store)",
                        "source": "store"
                    }
    except Exception:
        pass

    # 5. Windows: Standard filesystem paths (Standalone Windows installer)
    drives = [f"{d}:\\" for d in "CDEFGHIJKLMNOPQRSTUVWXYZ" if os.path.exists(f"{d}:\\")]
    standard_patterns = [
        r"Program Files\MyWhoosh\MyWhoosh.exe",
        r"Program Files\MyWhoosh\MyWhoosh\Binaries\Win64\MyWhoosh.exe",
        r"Program Files (x86)\MyWhoosh\MyWhoosh.exe",
        r"MyWhoosh\MyWhoosh.exe",
        r"MyWhoosh\Binaries\Win64\MyWhoosh.exe",
        r"Games\MyWhoosh\MyWhoosh.exe",
        r"Gry\MyWhoosh\MyWhoosh.exe",
    ]
    for drive in drives:
        for pattern in standard_patterns:
            full_p = os.path.join(drive, pattern)
            if os.path.exists(full_p):
                return {
                    "type": "file",
                    "target": full_p,
                    "display": full_p,
                    "source": "standalone"
                }

    # User-level local appdata paths
    local_app_data = os.environ.get("LOCALAPPDATA", "")
    if local_app_data:
        candidates = [
            os.path.join(local_app_data, "Programs", "MyWhoosh", "MyWhoosh.exe"),
            os.path.join(local_app_data, "MyWhoosh", "MyWhoosh.exe"),
        ]
        for c in candidates:
            if os.path.exists(c):
                return {
                    "type": "file",
                    "target": c,
                    "display": c,
                    "source": "standalone"
                }

    # 6. Windows: Check Registry App Paths & Uninstall entries
    for root_key in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            with winreg.OpenKey(root_key, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\MyWhoosh.exe") as k:
                val, _ = winreg.QueryValueEx(k, "")
                if val and os.path.exists(val):
                    return {
                        "type": "file",
                        "target": val,
                        "display": val,
                        "source": "registry"
                    }
        except Exception:
            pass

        # Uninstall registry keys
        for uninst_path in (
            r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
            r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
        ):
            try:
                with winreg.OpenKey(root_key, uninst_path) as k:
                    i = 0
                    while True:
                        try:
                            subkey_name = winreg.EnumKey(k, i)
                            with winreg.OpenKey(k, subkey_name) as sk:
                                try:
                                    disp_name, _ = winreg.QueryValueEx(sk, "DisplayName")
                                    disp_str = str(disp_name).lower()
                                    if "whoosh" in disp_str and "velobridge" not in disp_str:
                                        for field in ("InstallLocation", "DisplayIcon"):
                                            try:
                                                loc, _ = winreg.QueryValueEx(sk, field)
                                                if loc and isinstance(loc, str):
                                                    loc = loc.strip(' "')
                                                    if loc.lower().endswith(".exe") and os.path.exists(loc):
                                                        return {"type": "file", "target": loc, "display": loc, "source": "registry"}
                                                    candidate_exe = os.path.join(loc, "MyWhoosh.exe")
                                                    if os.path.exists(candidate_exe):
                                                        return {"type": "file", "target": candidate_exe, "display": candidate_exe, "source": "registry"}
                                            except Exception:
                                                pass
                                except Exception:
                                    pass
                            i += 1
                        except OSError:
                            break
            except Exception:
                pass

    # 7. Windows: Shortcuts (.lnk) in Start Menu & Desktop (excluding VeloBridge)
    shortcut_dirs = [
        os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs"),
        os.path.expandvars(r"%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs"),
        os.path.expandvars(r"%USERPROFILE%\Desktop"),
        os.path.expandvars(r"%PUBLIC%\Desktop"),
    ]
    for sdir in shortcut_dirs:
        if os.path.isdir(sdir):
            for lnk in glob.glob(os.path.join(sdir, "**", "*whoosh*.lnk"), recursive=True):
                base_l = os.path.basename(lnk).lower()
                if "prereq" not in base_l and "velobridge" not in base_l:
                    return {
                        "type": "shortcut",
                        "target": lnk,
                        "display": os.path.basename(lnk),
                        "source": "shortcut"
                    }

    return None


def launch_or_focus_mywhoosh(custom_path: Optional[str] = None) -> bool:
    """Launches MyWhoosh (auto-detected or configured) or brings existing window to focus."""
    hwnd = find_mywhoosh_window()
    if hwnd:
        focus_mywhoosh()
        return True

    info = detect_mywhoosh(custom_path)
    if not info:
        return False

    target = info["target"]
    if "velobridge" in target.lower():
        return False

    if IS_MACOS:
        try:
            if os.path.exists(target):
                subprocess.Popen(["open", target])
            else:
                subprocess.Popen(["open", "-a", target])
            return True
        except Exception as e:
            print(f"[MyWhoosh macOS] Could not launch: {e}")
            return False

    try:
        # Use Windows native shell execution (handles shell:AppsFolder, .exe, .lnk)
        os.startfile(target)
        return True
    except Exception as e:
        try:
            # Fallback using cmd start
            subprocess.Popen(f'cmd.exe /c start "" "{target}"', shell=True)
            return True
        except Exception as e2:
            print(f"[MyWhoosh] Could not launch: {e} / {e2}")
            return False


class VirtualShifter:
    """Tracks and coordinates virtual gear state for MyWhoosh."""

    def __init__(self, min_gear: int = 1, max_gear: int = 30, initial_gear: int = 15):
        self.min_gear = min_gear
        self.max_gear = max_gear
        self.current_gear = initial_gear
        self.sound_enabled = True
        self.auto_focus = False
        self.on_gear_change_callback = None
        self._last_shift_up_time: float = 0.0
        self._last_shift_down_time: float = 0.0

    def shift_up(self, steps: int = 1) -> bool:
        now = time.monotonic()
        if steps == 1 and (now - self._last_shift_up_time < 0.10):
            return False
        if self.current_gear >= self.max_gear:
            return False

        self._last_shift_up_time = now
        old_gear = self.current_gear
        self.current_gear = min(self.max_gear, self.current_gear + steps)
        actual_steps = self.current_gear - old_gear

        if self.auto_focus:
            focus_mywhoosh()

        for _ in range(actual_steps):
            # In MyWhoosh, K = Gear Up
            send_hardware_key(SCANCODES["K"])
            time.sleep(0.02)

        if self.sound_enabled:
            play_shift_sound(shift_up=True)

        if self.on_gear_change_callback:
            self.on_gear_change_callback(self.current_gear)

        return True

    def shift_down(self, steps: int = 1) -> bool:
        now = time.monotonic()
        if steps == 1 and (now - self._last_shift_down_time < 0.10):
            return False
        if self.current_gear <= self.min_gear:
            return False

        self._last_shift_down_time = now
        old_gear = self.current_gear
        self.current_gear = max(self.min_gear, self.current_gear - steps)
        actual_steps = old_gear - self.current_gear

        if self.auto_focus:
            focus_mywhoosh()

        for _ in range(actual_steps):
            # In MyWhoosh, I = Gear Down
            send_hardware_key(SCANCODES["I"])
            time.sleep(0.02)

        if self.sound_enabled:
            play_shift_sound(shift_up=False)

        if self.on_gear_change_callback:
            self.on_gear_change_callback(self.current_gear)

        return True

    def reset_gear(self, target_gear: int = 15):
        self.current_gear = max(self.min_gear, min(self.max_gear, target_gear))
        if self.on_gear_change_callback:
            self.on_gear_change_callback(self.current_gear)
