"""
VeloBridge Package
"""
__version__ = "1.6.0"
APP_VERSION = "1.6"
APP_BADGE = f"PRO v{APP_VERSION}"
