"""
VeloBridge Package
"""
__version__ = "1.7.1"
APP_VERSION = "1.7.1"
APP_BADGE = f"PRO v{APP_VERSION}"
