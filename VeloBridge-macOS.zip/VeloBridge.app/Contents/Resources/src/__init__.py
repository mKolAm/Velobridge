"""
VeloBridge Package
"""
__version__ = "1.8.6"
APP_VERSION = "1.8.6"
APP_BADGE = f"PRO v{APP_VERSION}"
