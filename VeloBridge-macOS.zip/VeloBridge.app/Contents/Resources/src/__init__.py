"""
VeloBridge Package
"""
__version__ = "1.7.0"
APP_VERSION = "1.7.0"
APP_BADGE = f"PRO v{APP_VERSION}"
